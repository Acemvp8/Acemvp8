import { useState, type ReactNode } from "react";

export const fieldClass =
  "min-h-11 w-full rounded-lg border border-line bg-surface-2 px-3 py-2 text-base text-fg outline-none focus:border-orange";

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block font-display text-xs uppercase tracking-widest text-muted">{label}</span>
      {children}
    </label>
  );
}

export function Btn({
  children,
  onClick,
  tone = "primary",
  type = "button",
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  tone?: "primary" | "ghost" | "quiet";
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  const tones = {
    primary: "bg-orange text-ink",
    ghost: "border border-line bg-transparent text-fg",
    quiet: "border border-line bg-surface-2 text-muted",
  } as const;
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={`inline-flex min-h-11 items-center justify-center rounded-lg px-4 font-display text-lg tracking-wide disabled:opacity-40 ${tones[tone]}`}
    >
      {children}
    </button>
  );
}

export function ConfirmBtn({ label, onConfirm }: { label: string; onConfirm: () => void }) {
  const [armed, setArmed] = useState(false);
  return (
    <button
      type="button"
      className="inline-flex min-h-11 items-center justify-center rounded-lg border border-line px-3 font-display text-base tracking-wide text-muted"
      onClick={() => {
        if (!armed) {
          setArmed(true);
          return;
        }
        onConfirm();
        setArmed(false);
      }}
    >
      {armed ? "Confirm" : label}
    </button>
  );
}

export function Panel({
  kicker,
  title,
  action,
  children,
}: {
  kicker?: string;
  title: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="mb-4 rounded-lg border border-line bg-surface p-4 sm:p-5">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div className="min-w-0">
          {kicker ? <p className="font-display text-xs uppercase tracking-widest text-orange">{kicker}</p> : null}
          <h2 className="font-display text-2xl uppercase leading-none tracking-wide text-fg">{title}</h2>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Callout({ children }: { children: ReactNode }) {
  return <div className="mb-4 border-l-4 border-orange bg-orange-dim px-4 py-3 text-sm leading-relaxed text-fg">{children}</div>;
}

export function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-lg border border-line bg-surface-2 px-3 py-3">
      <p className="font-display text-xs uppercase tracking-widest text-muted">{label}</p>
      <p className="mt-1 font-display text-3xl leading-none tracking-wide text-fg tabular-nums">{value}</p>
      {hint ? <p className="mt-1 text-xs leading-snug text-muted">{hint}</p> : null}
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="text-sm text-muted">{children}</p>;
}
