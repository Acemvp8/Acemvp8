import { money, payroll } from "@/lib/franchise/selectors";
import { useActive } from "@/lib/franchise/store";
import { Callout, Panel, Stat, fieldClass } from "./ui";

export function LedgerDesk() {
  const { campaign: c, update } = useActive();
  const pay = payroll(c.players);
  const room = c.budget - pay;
  const rows = [...c.players].filter((p) => p.level === "MLB" || p.level === "IL").sort((a, b) => a.years - b.years || b.salary - a.salary);
  const extensions = c.players.filter((p) => p.age <= 26 && p.pot >= 80 && p.years <= 5 && p.years >= 2 && p.level !== "IL");
  const walk = rows.filter((p) => p.years <= 1);

  return (
    <div>
      <Callout>
        Lock the young stars before arbitration writes the check for you. A one-year rental is fine when you’re
        contending. It is a bad habit when you’re not.
      </Callout>
      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
        <Stat label="Payroll" value={money(pay)} hint="MLB and IL" />
        <Stat label="Budget" value={money(c.budget)} hint="Your number, not the game’s" />
        <Stat label="Room" value={money(room)} hint={room < 0 ? "You’re over the number you set." : "Left to spend"} />
      </div>
      <Panel kicker="Books" title="Set the number">
        <label className="text-sm text-muted">
          Budget in millions
          <input className={`${fieldClass} mt-1 max-w-40`} type="number" value={c.budget} onChange={(e) => update((x) => ({ ...x, budget: Number(e.target.value) || 0 }))} />
        </label>
      </Panel>
      <Panel kicker="Extend" title="Do it before the price jumps">
        {extensions.length === 0 ? <p className="text-sm text-muted">Nobody fits the window: 26 or younger, 80-plus potential, two to five years left.</p> : null}
        <ul>
          {extensions.map((p) => (
            <li key={p.id} className="border-t border-line py-2 text-sm">
              <span className="text-fg">{p.name}</span>
              <span className="text-muted">
                {" "}
                · {p.ovr}/{p.pot} · age {p.age} · {p.years} years · {money(p.salary)}
                {p.untouchable ? " · already untouchable" : ""}
              </span>
            </li>
          ))}
        </ul>
      </Panel>
      <Panel kicker="Walk year" title="Control runs out">
        {walk.length === 0 ? <p className="text-sm text-muted">Nobody is on a one-year deal.</p> : null}
        <ul>
          {walk.map((p) => (
            <li key={p.id} className="flex items-baseline justify-between gap-3 border-t border-line py-2 text-sm">
              <span className="text-fg">{p.name}</span>
              <span className="text-muted">
                {p.pos} · {money(p.salary)}
                {p.arb ? " · arb" : ""}
              </span>
            </li>
          ))}
        </ul>
      </Panel>
      <Panel kicker="Sheet" title="Everyone on the books">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="font-display text-xs uppercase tracking-widest text-muted">
                <th className="py-2 pr-2 font-medium">Player</th>
                <th className="py-2 pr-2 font-medium">Yrs</th>
                <th className="py-2 pr-2 font-medium">AAV</th>
                <th className="py-2 font-medium">Tag</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => (
                <tr key={p.id} className="border-t border-line">
                  <td className="py-2 pr-2 text-fg">
                    {p.name}
                    <span className="block text-xs text-muted">
                      {p.pos} · {p.level}
                    </span>
                  </td>
                  <td className="py-2 pr-2 tabular-nums">{p.years}</td>
                  <td className="py-2 pr-2 tabular-nums">{money(p.salary)}</td>
                  <td className="py-2 text-xs text-muted">{p.arb ? "Arb" : p.years <= 1 ? "Walk" : p.years >= 5 ? "Control" : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}
