import { useState } from "react";
import { applyTrade, tradeFit } from "@/lib/franchise/logic";
import { useActive } from "@/lib/franchise/store";
import { otherClubs } from "@/lib/franchise/teams";
import { uid, type Offer, type Strategy } from "@/lib/franchise/types";
import { Btn, Callout, ConfirmBtn, Empty, Field, Panel, fieldClass } from "./ui";

function emptyOffer(partner = ""): Offer {
  return {
    id: uid("o"),
    partner,
    status: "pending",
    ourIds: ["", "", "", ""],
    theirNames: ["", "", "", ""],
    theirControl: "mid",
    partnerStance: "contend",
    sameDivision: false,
    market: "mid",
    surplus: false,
    days: 0,
    note: "",
  };
}

function OfferForm({
  offer,
  onChange,
}: {
  offer: Offer;
  onChange: (o: Offer) => void;
}) {
  const { campaign: c } = useActive();
  const fit = tradeFit(c, { ...offer, ourIds: offer.ourIds.filter(Boolean) });
  return (
    <div>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Partner">
          <select className={fieldClass} value={offer.partner} onChange={(e) => onChange({ ...offer, partner: e.target.value })}>
            <option value="">Pick</option>
            {otherClubs(c.team).map((club) => (
              <option key={club.abbr}>{club.name}</option>
            ))}
          </select>
        </Field>
        <Field label="Status">
          <select className={fieldClass} value={offer.status} onChange={(e) => onChange({ ...offer, status: e.target.value as Offer["status"] })}>
            <option value="rumor">Rumor</option>
            <option value="pending">Pending</option>
            <option value="accepted">Accepted</option>
            <option value="rejected">Rejected</option>
            <option value="pulled">Pulled</option>
          </select>
        </Field>
        <Field label="Their stance">
          <select className={fieldClass} value={offer.partnerStance} onChange={(e) => onChange({ ...offer, partnerStance: e.target.value as Strategy })}>
            <option value="contend">Contending</option>
            <option value="retool">Retooling</option>
            <option value="rebuild">Rebuilding</option>
          </select>
        </Field>
        <Field label="Control you’re asking for">
          <select className={fieldClass} value={offer.theirControl} onChange={(e) => onChange({ ...offer, theirControl: e.target.value as Offer["theirControl"] })}>
            <option value="rental">Rental</option>
            <option value="mid">2–3 years</option>
            <option value="control">4+ years</option>
          </select>
        </Field>
        <Field label="Market">
          <select className={fieldClass} value={offer.market} onChange={(e) => onChange({ ...offer, market: e.target.value as Offer["market"] })}>
            <option value="small">Small</option>
            <option value="mid">Mid</option>
            <option value="large">Large</option>
          </select>
        </Field>
        <Field label="Days waiting">
          <input className={fieldClass} type="number" min={0} value={offer.days} onChange={(e) => onChange({ ...offer, days: Number(e.target.value) || 0 })} />
        </Field>
      </div>
      <div className="mt-3 flex flex-wrap gap-4">
        <label className="flex min-h-11 items-center gap-2 text-sm">
          <input type="checkbox" checked={offer.sameDivision} onChange={(e) => onChange({ ...offer, sameDivision: e.target.checked })} />
          Division rival
        </label>
        <label className="flex min-h-11 items-center gap-2 text-sm">
          <input type="checkbox" checked={offer.surplus} onChange={(e) => onChange({ ...offer, surplus: e.target.checked })} />
          They have a surplus there
        </label>
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <div>
          <p className="mb-1 font-display text-xs uppercase tracking-widest text-muted">We send (up to 4)</p>
          {offer.ourIds.map((id, i) => (
            <select
              key={i}
              className={`${fieldClass} mb-2`}
              value={id}
              onChange={(e) => onChange({ ...offer, ourIds: offer.ourIds.map((v, idx) => (idx === i ? e.target.value : v)) })}
            >
              <option value="">—</option>
              {c.players.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.untouchable ? "UNT · " : ""}
                  {p.name} · {p.ovr}/{p.pot}
                </option>
              ))}
            </select>
          ))}
        </div>
        <div>
          <p className="mb-1 font-display text-xs uppercase tracking-widest text-muted">We get (up to 4)</p>
          {offer.theirNames.map((name, i) => (
            <input
              key={i}
              className={`${fieldClass} mb-2`}
              value={name}
              placeholder="Their player"
              onChange={(e) => onChange({ ...offer, theirNames: offer.theirNames.map((v, idx) => (idx === i ? e.target.value : v)) })}
            />
          ))}
        </div>
      </div>
      <Field label="Your read">
        <textarea className={`${fieldClass} mt-3 min-h-16`} value={offer.note} onChange={(e) => onChange({ ...offer, note: e.target.value })} />
      </Field>
      <div className="mt-3 rounded-lg border border-orange bg-orange-dim p-3">
        <p className="font-display text-3xl uppercase leading-none text-orange">{fit.verdict}</p>
        <p className="mt-1 font-display text-xl tabular-nums text-fg">{fit.score} fit</p>
        <ul className="mt-2 list-disc pl-4 text-sm text-fg">
          {fit.reasons.map((r) => (
            <li key={r}>{r}</li>
          ))}
        </ul>
        <p className="mt-2 text-xs text-muted">Companion logic, not the SDS engine. It prices the factors The Show 26 actually uses.</p>
      </div>
    </div>
  );
}

export function TradeDesk() {
  const { campaign: c, update } = useActive();
  const [draft, setDraft] = useState<Offer>(() => emptyOffer());
  const [rumor, setRumor] = useState("");
  const [trust, setTrust] = useState<"smoke" | "likely" | "noise">("smoke");
  const blocks = c.players.filter((p) => p.untouchable);

  return (
    <div>
      <Callout>
        Trade Hub rules in The Show 26: no instant yes, up to four players a side, untouchables barely move, division
        rivals lowball you, small markets fade big salaries, and a contender will not hand you six years of a star for a
        rental. Rumors can be noise. File the offer, then advance the days.
      </Callout>
      <Panel kicker="Blocked" title="Untouchables">
        {blocks.length === 0 ? (
          <Empty>Nobody is blocked. Mark the two or three you will not move — a long list makes the tag meaningless.</Empty>
        ) : (
          <ul className="flex flex-wrap gap-2">
            {blocks.map((p) => (
              <li key={p.id}>
                <button
                  type="button"
                  className="min-h-11 rounded-lg border border-orange px-3 text-sm text-orange"
                  onClick={() => update((x) => ({ ...x, players: x.players.map((row) => (row.id === p.id ? { ...row, untouchable: false } : row)) }))}
                >
                  {p.name} · release
                </button>
              </li>
            ))}
          </ul>
        )}
      </Panel>
      <Panel kicker="New" title="Build an offer">
        <OfferForm offer={draft} onChange={setDraft} />
        <div className="mt-3">
          <Btn
            disabled={!draft.partner || !draft.ourIds.some(Boolean) || !draft.theirNames.some((n) => n.trim())}
            onClick={() => {
              update((x) => ({ ...x, offers: [{ ...draft, ourIds: draft.ourIds.filter(Boolean) }, ...x.offers] }));
              setDraft(emptyOffer());
            }}
          >
            File the offer
          </Btn>
        </div>
      </Panel>
      <Panel kicker="Wire" title="Rumors">
        <div className="grid gap-3 sm:grid-cols-[1fr_8rem]">
          <input className={fieldClass} value={rumor} placeholder="They’re listening on a starter" onChange={(e) => setRumor(e.target.value)} />
          <select className={fieldClass} value={trust} onChange={(e) => setTrust(e.target.value as typeof trust)}>
            <option value="smoke">Smoke</option>
            <option value="likely">Likely</option>
            <option value="noise">Noise</option>
          </select>
        </div>
        <div className="mt-3">
          <Btn
            disabled={!rumor.trim()}
            onClick={() => {
              update((x) => ({ ...x, rumors: [{ id: uid("r"), text: rumor.trim(), trust }, ...x.rumors] }));
              setRumor("");
            }}
          >
            Post rumor
          </Btn>
        </div>
        <ul className="mt-3">
          {c.rumors.map((r) => (
            <li key={r.id} className="flex items-start justify-between gap-3 border-t border-line py-2 text-sm">
              <p>
                <span className="font-display uppercase tracking-wide text-orange">{r.trust}</span> · {r.text}
              </p>
              <ConfirmBtn label="Drop" onConfirm={() => update((x) => ({ ...x, rumors: x.rumors.filter((row) => row.id !== r.id) }))} />
            </li>
          ))}
        </ul>
      </Panel>
      <Panel kicker="Book" title="Offers">
        {c.offers.length === 0 ? <Empty>Nothing filed. Build one above when you’re ready to wait on an answer.</Empty> : null}
        {c.offers.map((offer) => {
          const ours = offer.ourIds.map((id) => c.players.find((p) => p.id === id)?.name ?? "Gone").join(", ");
          const theirs = offer.theirNames.filter(Boolean).join(", ");
          return (
            <article key={offer.id} className="mb-4 border-t border-line pt-3">
              <p className="font-display text-xl uppercase text-fg">
                {offer.partner} · {offer.status} · day {offer.days}
              </p>
              <p className="text-sm text-muted">
                Send {ours || "—"} · get {theirs || "—"}
              </p>
              {offer.note ? <p className="mt-1 text-sm text-fg">{offer.note}</p> : null}
              <div className="mt-2 flex flex-wrap gap-2">
                <Btn tone="quiet" onClick={() => update((x) => ({ ...x, offers: x.offers.map((o) => (o.id === offer.id ? { ...o, days: o.days + 1 } : o)) }))}>
                  Advance a day
                </Btn>
                <Btn
                  tone="ghost"
                  onClick={() => update((x) => applyTrade(x, offer))}
                  disabled={!offer.theirNames.some((n) => n.trim()) || !offer.ourIds.length}
                >
                  They said yes — apply
                </Btn>
                <ConfirmBtn label="Pull" onConfirm={() => update((x) => ({ ...x, offers: x.offers.filter((o) => o.id !== offer.id) }))} />
              </div>
            </article>
          );
        })}
      </Panel>
    </div>
  );
}
