import { useState } from "react";
import { orderedGames } from "@/lib/franchise/selectors";
import { useActive } from "@/lib/franchise/store";
import { otherClubs } from "@/lib/franchise/teams";
import type { GameLog } from "@/lib/franchise/types";
import { uid } from "@/lib/franchise/types";
import { Btn, Callout, ConfirmBtn, Empty, Field, Panel, fieldClass } from "./ui";

function today() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

function blankGame(opponent = ""): GameLog {
  return {
    id: uid("g"),
    date: today(),
    opponent,
    home: true,
    result: "W",
    runsFor: 0,
    runsAgainst: 0,
    starter: "",
    oppStarter: "",
    innings: "",
    pitches: "",
    relievers: "",
    moment: "",
    notes: "",
    how: "played",
  };
}

export function LogDesk() {
  const { campaign: c, update } = useActive();
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState<GameLog>(() => blankGame(c.nextOpponent));
  const games = orderedGames(c.games).slice().reverse();
  const pitchers = c.players.filter((p) => p.pos === "SP" || p.pos === "RP" || p.role === "rotation" || p.role === "bullpen");
  const pen = c.pen
    .map((s) => c.players.find((p) => p.id === s.playerId))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  function save() {
    if (!draft.opponent.trim()) return;
    update((x) => {
      const exists = x.games.some((g) => g.id === draft.id);
      return { ...x, games: exists ? x.games.map((g) => (g.id === draft.id ? draft : g)) : [...x.games, draft] };
    });
    setEditing(null);
    setDraft(blankGame(c.nextOpponent));
  }

  return (
    <div>
      {c.participation === "Key moments" ? (
        <Callout>
          Worth taking the controller: a one-run game from the 7th on, an ace against an ace, a division rival, and any
          debut you actually care about. Sim the rest and log the line so the rotation still turns.
        </Callout>
      ) : (
        <Callout>Log the games you want the desk to remember. Rest, bullpen fatigue, pace, and recaps all read this list.</Callout>
      )}
      <Panel kicker="Box" title={editing ? "Edit the line" : "Log a game"}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Date">
            <input className={fieldClass} type="date" value={draft.date} onChange={(e) => setDraft({ ...draft, date: e.target.value })} />
          </Field>
          <Field label="Opponent">
            <select className={fieldClass} value={draft.opponent} onChange={(e) => setDraft({ ...draft, opponent: e.target.value })}>
              <option value="">Pick a club</option>
              {otherClubs(c.team).map((club) => (
                <option key={club.abbr}>{club.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Result">
            <select className={fieldClass} value={draft.result} onChange={(e) => setDraft({ ...draft, result: e.target.value as "W" | "L" })}>
              <option value="W">Win</option>
              <option value="L">Loss</option>
            </select>
          </Field>
          <Field label="Site">
            <select className={fieldClass} value={draft.home ? "home" : "away"} onChange={(e) => setDraft({ ...draft, home: e.target.value === "home" })}>
              <option value="home">Home</option>
              <option value="away">Away</option>
            </select>
          </Field>
          <Field label="Runs for">
            <input className={fieldClass} type="number" value={draft.runsFor} onChange={(e) => setDraft({ ...draft, runsFor: Number(e.target.value) || 0 })} />
          </Field>
          <Field label="Runs against">
            <input className={fieldClass} type="number" value={draft.runsAgainst} onChange={(e) => setDraft({ ...draft, runsAgainst: Number(e.target.value) || 0 })} />
          </Field>
          <Field label="Our starter">
            <select className={fieldClass} value={draft.starter} onChange={(e) => setDraft({ ...draft, starter: e.target.value })}>
              <option value="">—</option>
              {pitchers.map((p) => (
                <option key={p.id}>{p.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Their starter">
            <input className={fieldClass} value={draft.oppStarter} onChange={(e) => setDraft({ ...draft, oppStarter: e.target.value })} />
          </Field>
          <Field label="Innings">
            <input className={fieldClass} value={draft.innings} placeholder="6.0" onChange={(e) => setDraft({ ...draft, innings: e.target.value })} />
          </Field>
          <Field label="Pitches">
            <input className={fieldClass} value={draft.pitches} placeholder="94" onChange={(e) => setDraft({ ...draft, pitches: e.target.value })} />
          </Field>
          <Field label="How">
            <select className={fieldClass} value={draft.how} onChange={(e) => setDraft({ ...draft, how: e.target.value as GameLog["how"] })}>
              <option value="played">Played it</option>
              <option value="moment">Key moment</option>
              <option value="simmed">Simmed</option>
            </select>
          </Field>
        </div>
        <fieldset className="mt-3">
          <legend className="mb-1 font-display text-xs uppercase tracking-widest text-muted">Bullpen used</legend>
          <div className="flex flex-wrap gap-2">
            {pen.map((p) => {
              const names = draft.relievers.split(",").map((s) => s.trim()).filter(Boolean);
              const on = names.some((n) => n.toLowerCase() === p.name.toLowerCase());
              return (
                <button
                  key={p.id}
                  type="button"
                  className={`min-h-11 rounded-lg border px-3 text-sm ${on ? "border-orange bg-orange-dim text-orange" : "border-line text-muted"}`}
                  onClick={() => {
                    const next = on ? names.filter((n) => n.toLowerCase() !== p.name.toLowerCase()) : [...names, p.name];
                    setDraft({ ...draft, relievers: next.join(", ") });
                  }}
                >
                  {p.name}
                </button>
              );
            })}
          </div>
        </fieldset>
        <div className="mt-3 grid gap-3">
          <Field label="Key moment">
            <input className={fieldClass} value={draft.moment} placeholder="Rutschman, 3-run shot, 6th" onChange={(e) => setDraft({ ...draft, moment: e.target.value })} />
          </Field>
          <Field label="Notes">
            <textarea className={`${fieldClass} min-h-20`} value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} />
          </Field>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn onClick={save} disabled={!draft.opponent}>
            {editing ? "Save changes" : "Add to the log"}
          </Btn>
          {editing ? (
            <Btn
              tone="quiet"
              onClick={() => {
                setEditing(null);
                setDraft(blankGame(c.nextOpponent));
              }}
            >
              Cancel
            </Btn>
          ) : null}
        </div>
      </Panel>
      <Panel kicker="Book" title="Results">
        {games.length === 0 ? (
          <Empty>No games yet. The record on the scorebug stays 0–0 until you log one, unless you set it by hand on the season desk.</Empty>
        ) : (
          <ul>
            {games.map((g) => (
              <li key={g.id} className="border-t border-line py-3">
                <div className="flex items-start gap-3">
                  <span className={`flex size-8 shrink-0 items-center justify-center rounded-md font-display text-lg ${g.result === "W" ? "bg-orange-dim text-orange" : "bg-surface-2 text-muted"}`}>
                    {g.result}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-display text-xl uppercase leading-none tracking-wide text-fg">
                      {g.home ? "vs" : "at"} {g.opponent}
                      <span className="ml-2 font-sans text-xs normal-case tracking-normal text-muted">{g.date}</span>
                    </p>
                    <p className="mt-1 text-sm text-muted">
                      {g.runsFor}–{g.runsAgainst}
                      {g.starter ? ` · ${g.starter}` : ""}
                      {g.innings ? ` · ${g.innings} IP` : ""}
                      {g.how === "simmed" ? " · sim" : g.how === "moment" ? " · moment" : ""}
                    </p>
                    {g.moment ? <p className="mt-1 text-sm text-fg">{g.moment}</p> : null}
                    {g.notes ? <p className="mt-1 text-sm text-muted">{g.notes}</p> : null}
                  </div>
                  <div className="flex shrink-0 flex-col gap-1">
                    <button
                      type="button"
                      className="min-h-11 px-2 text-sm text-orange"
                      onClick={() => {
                        setEditing(g.id);
                        setDraft(g);
                      }}
                    >
                      Edit
                    </button>
                    <ConfirmBtn label="Delete" onConfirm={() => update((x) => ({ ...x, games: x.games.filter((row) => row.id !== g.id) }))} />
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
