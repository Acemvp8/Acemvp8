import { useState } from "react";
import { useActive } from "@/lib/franchise/store";
import { DEV_FOCUSES, uid, type Player } from "@/lib/franchise/types";
import { Btn, Callout, ConfirmBtn, Empty, Field, Panel, fieldClass } from "./ui";

export function PipelineDesk() {
  const { campaign: c, update } = useActive();
  const [note, setNote] = useState("");
  const [focus, setFocus] = useState<string>(DEV_FOCUSES[0]);
  const [who, setWho] = useState("");
  const [round, setRound] = useState("1");
  const [pickName, setPickName] = useState("");
  const [pickPos, setPickPos] = useState("SS");
  const [pickNote, setPickNote] = useState("");
  const kids = c.players
    .filter((p) => p.role === "prospect" || p.level === "AAA" || p.level === "AA" || p.pot - p.ovr >= 8)
    .sort((a, b) => b.pot - a.pot || a.age - b.age);

  return (
    <div>
      <Callout>
        Development is the quiet half of a franchise. Log what you’re training, not just the overall. The draft board is
        a scratch pad for the pool in your save — it does not sim the draft.
      </Callout>
      <Panel kicker="Farm" title="Who’s coming">
        {kids.length === 0 ? <Empty>No prospects tagged. Mark a player’s role as prospect, or give him a big gap between overall and potential.</Empty> : null}
        <ul>
          {kids.map((p) => (
            <li key={p.id} className="border-t border-line py-3">
              <div className="flex items-baseline justify-between gap-3">
                <p className="font-display text-xl uppercase leading-none text-fg">{p.name}</p>
                <p className="font-display text-xl text-orange tabular-nums">
                  {p.ovr}
                  <span className="text-muted">/{p.pot}</span>
                </p>
              </div>
              <p className="mt-1 text-xs text-muted">
                {p.pos} · age {p.age} · {p.level} · {p.years} years · focus {p.devFocus}
              </p>
              <label className="mt-2 block text-xs text-muted">
                Training focus
                <select
                  className={`${fieldClass} mt-1`}
                  value={p.devFocus}
                  onChange={(e) =>
                    update((x) => ({
                      ...x,
                      players: x.players.map((row) => (row.id === p.id ? { ...row, devFocus: e.target.value } : row)),
                    }))
                  }
                >
                  {DEV_FOCUSES.map((f) => (
                    <option key={f}>{f}</option>
                  ))}
                </select>
              </label>
              {p.notes ? <p className="mt-2 text-sm text-fg">{p.notes}</p> : null}
            </li>
          ))}
        </ul>
      </Panel>
      <Panel kicker="Notes" title="Development log">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Player">
            <select className={fieldClass} value={who} onChange={(e) => setWho(e.target.value)}>
              <option value="">Pick</option>
              {c.players.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Focus">
            <select className={fieldClass} value={focus} onChange={(e) => setFocus(e.target.value)}>
              {DEV_FOCUSES.map((f) => (
                <option key={f}>{f}</option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="What changed">
          <textarea className={`${fieldClass} mt-3 min-h-20`} value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>
        <div className="mt-3">
          <Btn
            disabled={!who || !note.trim()}
            onClick={() => {
              const player = c.players.find((p) => p.id === who) as Player | undefined;
              update((x) => ({
                ...x,
                devNotes: [{ id: uid("d"), playerId: who, date: new Date().toISOString().slice(0, 10), focus, note: note.trim() }, ...x.devNotes],
                players: player
                  ? x.players.map((p) => (p.id === who ? { ...p, devFocus: focus } : p))
                  : x.players,
              }));
              setNote("");
            }}
          >
            File the note
          </Btn>
        </div>
        <ul className="mt-4">
          {c.devNotes.length === 0 ? <Empty>No development notes yet.</Empty> : null}
          {c.devNotes.map((n) => {
            const p = c.players.find((row) => row.id === n.playerId);
            return (
              <li key={n.id} className="border-t border-line py-2 text-sm">
                <p className="text-fg">
                  {p?.name ?? "Released"} · {n.focus}
                  <span className="ml-2 text-xs text-muted">{n.date}</span>
                </p>
                <p className="text-muted">{n.note}</p>
              </li>
            );
          })}
        </ul>
      </Panel>
      <Panel kicker="July" title="Draft board">
        <div className="grid gap-3 sm:grid-cols-4">
          <Field label="Round">
            <input className={fieldClass} value={round} onChange={(e) => setRound(e.target.value)} />
          </Field>
          <Field label="Name">
            <input className={fieldClass} value={pickName} onChange={(e) => setPickName(e.target.value)} />
          </Field>
          <Field label="Pos">
            <input className={fieldClass} value={pickPos} onChange={(e) => setPickPos(e.target.value)} />
          </Field>
          <Field label="Note">
            <input className={fieldClass} value={pickNote} onChange={(e) => setPickNote(e.target.value)} />
          </Field>
        </div>
        <div className="mt-3">
          <Btn
            disabled={!pickName.trim()}
            onClick={() => {
              update((x) => ({
                ...x,
                draft: [...x.draft, { id: uid("dr"), round, name: pickName.trim(), pos: pickPos, note: pickNote.trim() }],
              }));
              setPickName("");
              setPickNote("");
            }}
          >
            Add to the board
          </Btn>
        </div>
        <ul className="mt-3">
          {c.draft.length === 0 ? <Empty>Board is empty. Park the names you’re circling before the draft opens.</Empty> : null}
          {c.draft.map((d) => (
            <li key={d.id} className="flex items-start justify-between gap-3 border-t border-line py-2 text-sm">
              <div>
                <p className="text-fg">
                  Rd {d.round} · {d.name} · {d.pos}
                </p>
                {d.note ? <p className="text-muted">{d.note}</p> : null}
              </div>
              <ConfirmBtn label="Cut" onConfirm={() => update((x) => ({ ...x, draft: x.draft.filter((row) => row.id !== d.id) }))} />
            </li>
          ))}
        </ul>
        <Field label="International note">
          <textarea className={`${fieldClass} mt-3 min-h-20`} value={c.intlNote} onChange={(e) => update((x) => ({ ...x, intlNote: e.target.value }))} />
        </Field>
      </Panel>
    </div>
  );
}
