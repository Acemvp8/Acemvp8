import { findPlayer, isPitcher, mlbHitters } from "@/lib/franchise/selectors";
import { useActive } from "@/lib/franchise/store";
import type { LineupSlot } from "@/lib/franchise/types";
import { Callout, Panel, fieldClass } from "./ui";

const SPOTS = ["C", "1B", "2B", "3B", "SS", "LF", "CF", "RF", "DH"];

function move(list: LineupSlot[], index: number, dir: number) {
  const next = list.map((s) => ({ ...s }));
  const j = index + dir;
  if (j < 0 || j >= next.length) return list;
  const tmp = next[index]!;
  next[index] = next[j]!;
  next[j] = tmp;
  return next;
}

function setHitter(list: LineupSlot[], index: number, playerId: string) {
  const next = list.map((s) => ({ ...s }));
  const other = next.findIndex((s, i) => s.playerId === playerId && i !== index);
  if (other >= 0) next[other]!.playerId = next[index]!.playerId;
  next[index]!.playerId = playerId;
  return next;
}

function Card({
  title,
  slots,
  onChange,
}: {
  title: string;
  slots: LineupSlot[];
  onChange: (next: LineupSlot[]) => void;
}) {
  const { campaign: c } = useActive();
  const pool = c.players.filter((p) => p.level === "MLB" && !isPitcher(p));
  return (
    <Panel kicker="Card" title={title}>
      <ol className="flex flex-col gap-2">
        {slots.map((slot, i) => {
          const p = findPlayer(c, slot.playerId);
          return (
            <li key={`${title}-${i}`} className="grid grid-cols-[2rem_1fr_5rem] items-center gap-2">
              <span className="font-display text-2xl text-orange tabular-nums">{i + 1}</span>
              <select
                className={fieldClass}
                value={slot.playerId}
                onChange={(e) => onChange(setHitter(slots, i, e.target.value))}
              >
                {pool.map((h) => (
                  <option key={h.id} value={h.id}>
                    {h.name} · {h.bats} · {h.ovr}
                  </option>
                ))}
                {p && !pool.some((h) => h.id === p.id) ? <option value={p.id}>{p.name}</option> : null}
              </select>
              <select className={fieldClass} value={slot.pos} onChange={(e) => onChange(slots.map((s, idx) => (idx === i ? { ...s, pos: e.target.value } : s)))}>
                {SPOTS.map((pos) => (
                  <option key={pos}>{pos}</option>
                ))}
              </select>
              <div className="col-span-3 flex gap-2 pl-8">
                <button type="button" className="min-h-11 px-2 text-sm text-muted" onClick={() => onChange(move(slots, i, -1))}>
                  Up
                </button>
                <button type="button" className="min-h-11 px-2 text-sm text-muted" onClick={() => onChange(move(slots, i, 1))}>
                  Down
                </button>
                <span className="self-center text-xs text-faint">{p ? `${p.pos}${p.secondary ? ` / ${p.secondary}` : ""}` : "Open spot"}</span>
              </div>
            </li>
          );
        })}
      </ol>
      {slots.length < 9 ? (
        <button
          type="button"
          className="mt-3 min-h-11 font-display text-lg text-orange"
          onClick={() => {
            const used = new Set(slots.map((s) => s.playerId));
            const next = mlbHitters(c).find((p) => !used.has(p.id));
            if (!next) return;
            onChange([...slots, { playerId: next.id, pos: SPOTS[slots.length] ?? "DH" }]);
          }}
        >
          Add a spot
        </button>
      ) : null}
    </Panel>
  );
}

export function LineupDesk() {
  const { campaign: c, update } = useActive();
  return (
    <div>
      <Callout>
        The Show 26 stopped auto-stacking pure speed in the 1-hole. The two-hole is a contact, on-base bat. Build two
        cards — right-handed pitching and left-handed pitching — and use the secondary positions so the bench isn’t
        decorative.
      </Callout>
      <div className="grid gap-0 lg:grid-cols-2 lg:gap-4">
        <Card title="Versus RHP" slots={c.lineupR} onChange={(lineupR) => update((x) => ({ ...x, lineupR }))} />
        <Card title="Versus LHP" slots={c.lineupL} onChange={(lineupL) => update((x) => ({ ...x, lineupL }))} />
      </div>
    </div>
  );
}
