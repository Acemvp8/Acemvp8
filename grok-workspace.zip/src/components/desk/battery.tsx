import { useState } from "react";
import { callPitch, type BatteryCall, type BatteryInput } from "@/lib/franchise/logic";
import { useActive } from "@/lib/franchise/store";
import { ARSENAL_TAGS } from "@/lib/franchise/types";
import { Btn, Callout, Panel, fieldClass } from "./ui";

const COUNTS = ["0-0", "1-0", "0-1", "2-0", "1-1", "0-2", "3-0", "2-1", "1-2", "3-1", "2-2", "3-2"];

function lit(zone: number, call: BatteryCall, bat: "L" | "R") {
  const t = call.zone;
  if (typeof t === "number") return zone === t;
  if (t === "down") return zone >= 7;
  if (t === "up") return zone <= 3;
  const away = bat === "R" ? [3, 6, 9] : [1, 4, 7];
  const inn = bat === "R" ? [1, 4, 7] : [3, 6, 9];
  if (t === "away") return away.includes(zone);
  return inn.includes(zone);
}

export function BatteryDesk() {
  const { campaign: c } = useActive();
  const arms = c.players.filter((p) => p.pos === "SP" || p.pos === "RP" || p.role === "rotation" || p.role === "bullpen");
  const [pitcherId, setPitcherId] = useState("");
  const [bats, setBats] = useState<BatteryInput["bats"]>("R");
  const [throws, setThrows] = useState<BatteryInput["throws"]>("R");
  const [count, setCount] = useState("1-1");
  const [profile, setProfile] = useState<BatteryInput["profile"]>("power");
  const [runners, setRunners] = useState<BatteryInput["runners"]>("empty");
  const [outs, setOuts] = useState<0 | 1 | 2>(0);
  const [leverage, setLeverage] = useState<BatteryInput["leverage"]>("mid");
  const [arsenal, setArsenal] = useState<string[]>(["FB", "SL", "CH"]);
  const [bearDown, setBearDown] = useState(false);
  const [call, setCall] = useState<BatteryCall | null>(null);
  const showBat = bats === "S" ? (throws === "R" ? "L" : "R") : bats;

  return (
    <div>
      <Callout>
        A three-pitch sequence for the count you’re in. Bear Down is the The Show 26 command boost — spend it on the
        putaway, not a 0-0 strike. Catcher’s view on the zone.
      </Callout>
      <Panel kicker="Signs" title="Call the pitch">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="block text-sm text-muted">
            Our pitcher
            <select
              className={`${fieldClass} mt-1`}
              value={pitcherId}
              onChange={(e) => {
                const id = e.target.value;
                setPitcherId(id);
                const p = arms.find((a) => a.id === id);
                if (!p) return;
                setThrows(p.throws === "L" ? "L" : "R");
                const tags = p.arsenal
                  .split(/[^A-Za-z]+/)
                  .map((s) => s.toUpperCase())
                  .filter((s) => (ARSENAL_TAGS as readonly string[]).includes(s));
                if (tags.length) setArsenal(tags);
              }}
            >
              <option value="">Generic mix</option>
              {arms.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} · {p.throws}HP
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm text-muted">
            Batter bats
            <select className={`${fieldClass} mt-1`} value={bats} onChange={(e) => setBats(e.target.value as BatteryInput["bats"])}>
              <option value="R">Right</option>
              <option value="L">Left</option>
              <option value="S">Switch</option>
            </select>
          </label>
          <label className="block text-sm text-muted">
            Count
            <select className={`${fieldClass} mt-1`} value={count} onChange={(e) => setCount(e.target.value)}>
              {COUNTS.map((n) => (
                <option key={n}>{n}</option>
              ))}
            </select>
          </label>
          <label className="block text-sm text-muted">
            Hitter
            <select className={`${fieldClass} mt-1`} value={profile} onChange={(e) => setProfile(e.target.value as BatteryInput["profile"])}>
              <option value="power">Power</option>
              <option value="contact">Contact</option>
              <option value="patient">Patient</option>
              <option value="chase">Free swinger</option>
              <option value="speed">Speed</option>
              <option value="cold">Cold</option>
            </select>
          </label>
          <label className="block text-sm text-muted">
            Runners
            <select className={`${fieldClass} mt-1`} value={runners} onChange={(e) => setRunners(e.target.value as BatteryInput["runners"])}>
              <option value="empty">Empty</option>
              <option value="first">First</option>
              <option value="scoring">Scoring position</option>
              <option value="loaded">Loaded</option>
            </select>
          </label>
          <label className="block text-sm text-muted">
            Leverage
            <select className={`${fieldClass} mt-1`} value={leverage} onChange={(e) => setLeverage(e.target.value as BatteryInput["leverage"])}>
              <option value="low">Low</option>
              <option value="mid">Medium</option>
              <option value="high">High</option>
            </select>
          </label>
        </div>
        <div className="mt-3 flex gap-2">
          {([0, 1, 2] as const).map((n) => (
            <button key={n} type="button" className={`min-h-11 rounded-lg px-3 font-display text-lg ${outs === n ? "bg-orange text-ink" : "border border-line text-muted"}`} onClick={() => setOuts(n)}>
              {n} out
            </button>
          ))}
        </div>
        <fieldset className="mt-3">
          <legend className="mb-1 font-display text-xs uppercase tracking-widest text-muted">Arsenal</legend>
          <div className="flex flex-wrap gap-2">
            {ARSENAL_TAGS.map((tag) => {
              const on = arsenal.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  className={`min-h-11 rounded-lg border px-3 font-display text-lg ${on ? "border-orange bg-orange-dim text-orange" : "border-line text-muted"}`}
                  onClick={() => setArsenal(on ? arsenal.filter((t) => t !== tag) : [...arsenal, tag])}
                >
                  {tag}
                </button>
              );
            })}
          </div>
        </fieldset>
        <label className="mt-3 flex min-h-11 items-center gap-2 text-sm text-fg">
          <input type="checkbox" checked={bearDown} onChange={(e) => setBearDown(e.target.checked)} />
          Bear Down is available
        </label>
        <div className="mt-3">
          <Btn
            onClick={() =>
              setCall(
                callPitch({
                  bats,
                  throws,
                  count,
                  profile,
                  runners,
                  outs,
                  leverage,
                  arsenal,
                  bearDown,
                }),
              )
            }
          >
            Call the pitch
          </Btn>
        </div>
        {call ? (
          <div className="mt-4 grid gap-4 sm:grid-cols-[12rem_1fr]">
            <div>
              <div className="grid grid-cols-3 gap-1">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((z) => (
                  <div key={z} className={`flex aspect-square items-center justify-center rounded-md border font-display text-lg ${lit(z, call, showBat) ? "border-orange bg-orange text-ink" : "border-line text-faint"}`}>
                    {z}
                  </div>
                ))}
              </div>
              <p className="mt-1 text-center text-xs text-muted">Catcher view · {showBat === "R" ? "RHB" : "LHB"}</p>
            </div>
            <div>
              <p className="font-display text-3xl uppercase leading-none text-orange">{call.pitch}</p>
              <p className="mt-1 text-sm text-fg">{call.loc}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted">{call.why}</p>
              <ol className="mt-3 list-decimal pl-4 text-sm text-fg">
                {call.sequence.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ol>
              <p className="mt-3 text-sm text-fg">{call.running}</p>
              <p className="mt-2 text-sm text-orange">{call.bear}</p>
            </div>
          </div>
        ) : null}
      </Panel>
    </div>
  );
}
