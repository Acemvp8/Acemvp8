import { useState } from "react";
import {
  ArrowLeftRight,
  Binoculars,
  CalendarRange,
  CircleDot,
  Crosshair,
  GitBranch,
  LayoutDashboard,
  Mic,
  NotebookPen,
  Rows3,
  Users,
  Wallet,
  type LucideIcon,
} from "lucide-react";
import { useFranchise } from "@/lib/franchise/store";
import { createCampaign, isCampaign, normalizeCampaign } from "@/lib/franchise/seed";
import { displayRecord } from "@/lib/franchise/selectors";
import { CLUBS } from "@/lib/franchise/teams";
import { DESKS, type DeskId, type Difficulty, type Participation, type Strategy } from "@/lib/franchise/types";
import { ArmsDesk } from "./arms";
import { BatteryDesk } from "./battery";
import { BreakdownDesk } from "./breakdown";
import { Clubhouse } from "./clubhouse";
import { LedgerDesk } from "./ledger";
import { LineupDesk } from "./lineups";
import { LogDesk } from "./log";
import { PipelineDesk } from "./pipeline";
import { RosterDesk } from "./roster";
import { ScoutDesk } from "./scout";
import { SeasonDesk } from "./season";
import { TradeDesk } from "./trades";
import { Btn, Field, fieldClass, Panel } from "./ui";

const ICONS: Record<DeskId, LucideIcon> = {
  clubhouse: LayoutDashboard,
  season: CalendarRange,
  log: NotebookPen,
  lineups: Rows3,
  arms: CircleDot,
  roster: Users,
  pipeline: GitBranch,
  trades: ArrowLeftRight,
  scout: Binoculars,
  battery: Crosshair,
  ledger: Wallet,
  breakdown: Mic,
};

export function Opening() {
  return (
    <main className="flex min-h-screen flex-col justify-between px-5 py-8">
      <div>
        <p className="font-display text-sm uppercase tracking-widest text-orange">ACE8 Sports · MLB The Show 26</p>
        <h1 className="mt-2 max-w-xs font-display text-5xl uppercase leading-none text-fg">Franchise Companion</h1>
        <p className="mt-3 text-muted">Opening the clubhouse…</p>
      </div>
      <p className="font-display text-6xl leading-none text-orange tabular-nums">0–0</p>
    </main>
  );
}

export function Shell() {
  const [desk, setDesk] = useState<DeskId>("clubhouse");
  const [openNew, setOpenNew] = useState(false);
  const campaigns = useFranchise((s) => s.campaigns);
  const activeId = useFranchise((s) => s.activeId);
  const setActive = useFranchise((s) => s.setActive);
  const campaign = campaigns.find((c) => c.id === activeId) ?? campaigns[0];
  const rec = campaign ? displayRecord(campaign) : { w: 0, l: 0 };

  return (
    <div className="min-h-screen md:flex">
      <aside className="sticky top-0 z-30 hidden h-screen w-52 shrink-0 flex-col overflow-y-auto border-r border-line bg-bg md:flex">
        <div className="px-4 py-5">
          <p className="font-display text-xs uppercase tracking-widest text-orange">ACE8 · The Show 26</p>
          <p className="font-display text-3xl uppercase leading-none text-fg">Franchise Companion</p>
        </div>
        <nav className="flex flex-col gap-0.5 px-2 pb-6">
          {DESKS.map((d) => (
            <NavBtn key={d.id} id={d.id} label={d.label} active={desk === d.id} onClick={() => setDesk(d.id)} />
          ))}
        </nav>
      </aside>
      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-20 border-b border-line bg-bg">
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="min-w-0 flex-1">
              <p className="font-display text-xs uppercase tracking-widest text-orange md:hidden">ACE8 · The Show 26</p>
              <div className="flex min-w-0 items-center gap-2">
                <label className="sr-only" htmlFor="camp">
                  Campaign
                </label>
                <select
                  id="camp"
                  className={`${fieldClass} min-w-0 flex-1`}
                  value={campaign?.id ?? ""}
                  onChange={(e) => setActive(e.target.value)}
                >
                  {campaigns.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  className="inline-flex min-h-11 shrink-0 items-center font-display text-lg tracking-wide text-orange"
                  onClick={() => setOpenNew((v) => !v)}
                >
                  {openNew ? "Close" : "New"}
                </button>
              </div>
              {campaign ? (
                <p className="mt-1 truncate text-sm text-muted">
                  {campaign.teamName} · {campaign.season} · {campaign.strategy}
                </p>
              ) : null}
            </div>
            <div className="shrink-0 rounded-lg border border-line bg-surface-2 px-3 py-1.5 text-center">
              <p className="font-display text-3xl leading-none tracking-wide text-orange tabular-nums">
                {rec.w}–{rec.l}
              </p>
              <p className="font-display text-xs uppercase tracking-widest text-muted">Record</p>
            </div>
          </div>
          <div className="flex gap-1 overflow-x-auto px-3 pb-2 md:hidden">
            {DESKS.map((d) => (
              <button
                key={d.id}
                type="button"
                onClick={() => setDesk(d.id)}
                className={`shrink-0 rounded-lg px-3 py-2 font-display text-lg tracking-wide ${desk === d.id ? "bg-orange text-ink" : "text-muted"}`}
              >
                {d.label}
              </button>
            ))}
          </div>
        </header>
        <main className="mx-auto max-w-3xl px-4 py-4">
          {openNew && campaign ? <NewCampaign onDone={() => setOpenNew(false)} /> : null}
          {desk === "clubhouse" ? <Clubhouse /> : null}
          {desk === "season" ? <SeasonDesk /> : null}
          {desk === "log" ? <LogDesk /> : null}
          {desk === "lineups" ? <LineupDesk /> : null}
          {desk === "arms" ? <ArmsDesk /> : null}
          {desk === "roster" ? <RosterDesk /> : null}
          {desk === "pipeline" ? <PipelineDesk /> : null}
          {desk === "trades" ? <TradeDesk /> : null}
          {desk === "scout" ? <ScoutDesk /> : null}
          {desk === "battery" ? <BatteryDesk /> : null}
          {desk === "ledger" ? <LedgerDesk /> : null}
          {desk === "breakdown" ? <BreakdownDesk /> : null}
          <p className="mt-6 border-t border-line pt-4 text-center font-display text-xs uppercase tracking-widest text-faint">
            ACE8 Franchise Companion · Single-player · Saved on this device
          </p>
        </main>
      </div>
    </div>
  );
}

function NavBtn({ id, label, active, onClick }: { id: DeskId; label: string; active: boolean; onClick: () => void }) {
  const Icon = ICONS[id];
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex min-h-11 items-center gap-2 rounded-lg px-3 text-left font-display text-lg tracking-wide ${active ? "bg-orange-dim text-orange" : "text-muted"}`}
    >
      <Icon className="size-4 shrink-0" aria-hidden />
      {label}
    </button>
  );
}

function NewCampaign({ onDone }: { onDone: () => void }) {
  const add = useFranchise((s) => s.addCampaign);
  const del = useFranchise((s) => s.deleteCampaign);
  const campaigns = useFranchise((s) => s.campaigns);
  const activeId = useFranchise((s) => s.activeId);
  const [name, setName] = useState("");
  const [team, setTeam] = useState("BAL");
  const [season, setSeason] = useState(2026);
  const [strategy, setStrategy] = useState<Strategy>("contend");
  const [difficulty, setDifficulty] = useState<Difficulty>("Veteran");
  const [participation, setParticipation] = useState<Participation>("Key moments");
  const [snap, setSnap] = useState(true);
  const [msg, setMsg] = useState("");

  return (
    <Panel kicker="Campaigns" title="Start another save">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Name">
          <input className={fieldClass} value={name} placeholder="Birdland '27" onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Club">
          <select className={fieldClass} value={team} onChange={(e) => setTeam(e.target.value)}>
            {CLUBS.map((c) => (
              <option key={c.abbr} value={c.abbr}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Season">
          <input className={fieldClass} type="number" value={season} onChange={(e) => setSeason(Number(e.target.value) || 2026)} />
        </Field>
        <Field label="Plan">
          <select className={fieldClass} value={strategy} onChange={(e) => setStrategy(e.target.value as Strategy)}>
            <option value="contend">Contend</option>
            <option value="retool">Retool</option>
            <option value="rebuild">Rebuild</option>
          </select>
        </Field>
        <Field label="Difficulty">
          <select className={fieldClass} value={difficulty} onChange={(e) => setDifficulty(e.target.value as Difficulty)}>
            {["Beginner", "Veteran", "All-Star", "Hall of Fame", "Legend"].map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </Field>
        <Field label="How you play">
          <select className={fieldClass} value={participation} onChange={(e) => setParticipation(e.target.value as Participation)}>
            <option>Play every game</option>
            <option>Key moments</option>
            <option>Sim the grind</option>
          </select>
        </Field>
      </div>
      {team === "BAL" ? (
        <label className="mt-3 flex min-h-11 items-center gap-2 text-sm text-fg">
          <input type="checkbox" checked={snap} onChange={(e) => setSnap(e.target.checked)} />
          Load the Orioles 2026 snapshot
        </label>
      ) : (
        <p className="mt-3 text-sm text-muted">Other clubs start as a blank 26-man. Rename every spot to match your save.</p>
      )}
      <div className="mt-3 flex flex-wrap gap-2">
        <Btn
          onClick={() => {
            add(createCampaign({ name, team, season, strategy, difficulty, participation, oriolesSnapshot: snap }));
            onDone();
          }}
        >
          Create campaign
        </Btn>
        <Btn
          tone="quiet"
          disabled={campaigns.length < 2}
          onClick={() => {
            del(activeId);
            onDone();
          }}
        >
          Delete current
        </Btn>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Btn
          tone="ghost"
          onClick={() => {
            const c = campaigns.find((x) => x.id === activeId);
            if (!c) return;
            const blob = new Blob([JSON.stringify({ kind: "ace8-campaign", campaign: c }, null, 2)], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `${c.name.replace(/\s+/g, "-").toLowerCase()}.json`;
            a.click();
            URL.revokeObjectURL(url);
          }}
        >
          Export save
        </Btn>
        <label className="inline-flex min-h-11 cursor-pointer items-center rounded-lg border border-line px-4 font-display text-lg tracking-wide text-fg">
          Import
          <input
            type="file"
            accept="application/json"
            className="sr-only"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (!file) return;
              try {
                const json = JSON.parse(await file.text()) as { campaign?: unknown };
                const raw = json.campaign ?? json;
                if (!isCampaign(raw)) {
                  setMsg("That file isn’t an ACE8 campaign.");
                  return;
                }
                add(normalizeCampaign(raw));
                setMsg("Imported.");
                onDone();
              } catch {
                setMsg("Couldn’t read that file.");
              }
            }}
          />
        </label>
        {msg ? <span className="text-sm text-muted">{msg}</span> : null}
      </div>
    </Panel>
  );
}
