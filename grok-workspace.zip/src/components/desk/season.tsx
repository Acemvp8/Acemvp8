import { displayRecord, loggedRecord, monthSplits } from "@/lib/franchise/selectors";
import { useActive } from "@/lib/franchise/store";
import { orderedGames } from "@/lib/franchise/selectors";
import { Callout, Panel } from "./ui";

export function SeasonDesk() {
  const { campaign: c, update } = useActive();
  const rec = displayRecord(c);
  const logged = loggedRecord(c);
  const rows = c.standings.map((s) => (s.abbr === c.team ? { ...s, w: rec.w, l: rec.l } : s));
  const sorted = [...rows].sort((a, b) => {
    const pa = a.w + a.l ? a.w / (a.w + a.l) : 0;
    const pb = b.w + b.l ? b.w / (b.w + b.l) : 0;
    return pb - pa || b.w - a.w;
  });
  const leader = sorted[0];
  const months = monthSplits(c);
  const max = Math.max(1, ...months.map((m) => Math.max(m.w, m.l)));
  const recent = orderedGames(c.games).slice(-8).reverse();

  return (
    <div>
      <Callout>
        Your row follows the game log unless you flip manual record — useful when you sim a month and only play the
        moments. Rival rows are yours to update from the standings screen in the game.
      </Callout>
      <Panel kicker={c.teamName} title="Division">
        <label className="mb-3 flex min-h-11 items-center gap-2 text-sm text-fg">
          <input
            type="checkbox"
            checked={c.manualRecord}
            onChange={(e) => update((x) => ({ ...x, manualRecord: e.target.checked, manualW: logged.w, manualL: logged.l }))}
          />
          I’m not logging every sim. Use a manual record.
        </label>
        {c.manualRecord ? (
          <div className="mb-3 flex gap-2">
            <label className="text-sm text-muted">
              Wins
              <input
                className="mt-1 block w-24 rounded-lg border border-line bg-surface-2 px-3 py-2 text-base text-fg"
                type="number"
                value={c.manualW}
                onChange={(e) => update((x) => ({ ...x, manualW: Number(e.target.value) || 0 }))}
              />
            </label>
            <label className="text-sm text-muted">
              Losses
              <input
                className="mt-1 block w-24 rounded-lg border border-line bg-surface-2 px-3 py-2 text-base text-fg"
                type="number"
                value={c.manualL}
                onChange={(e) => update((x) => ({ ...x, manualL: Number(e.target.value) || 0 }))}
              />
            </label>
          </div>
        ) : null}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="font-display text-xs uppercase tracking-widest text-muted">
                <th className="py-2 pr-2 font-medium">Club</th>
                <th className="py-2 pr-2 font-medium">W</th>
                <th className="py-2 pr-2 font-medium">L</th>
                <th className="py-2 font-medium">GB</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((row) => {
                const gb = leader ? (leader.w - row.w + row.l - leader.l) / 2 : 0;
                const mine = row.abbr === c.team;
                return (
                  <tr key={row.abbr} className="border-t border-line">
                    <td className={`py-2 pr-2 ${mine ? "text-orange" : "text-fg"}`}>{row.name}</td>
                    <td className="py-2 pr-2 tabular-nums">
                      {mine && !c.manualRecord ? (
                        row.w
                      ) : (
                        <input
                          className="w-16 rounded-md border border-line bg-surface-2 px-2 py-1 text-base text-fg"
                          type="number"
                          value={mine ? c.manualW : row.w}
                          onChange={(e) => {
                            const w = Number(e.target.value) || 0;
                            if (mine) update((x) => ({ ...x, manualW: w, manualRecord: true }));
                            else update((x) => ({ ...x, standings: x.standings.map((s) => (s.abbr === row.abbr ? { ...s, w } : s)) }));
                          }}
                        />
                      )}
                    </td>
                    <td className="py-2 pr-2 tabular-nums">
                      {mine && !c.manualRecord ? (
                        row.l
                      ) : (
                        <input
                          className="w-16 rounded-md border border-line bg-surface-2 px-2 py-1 text-base text-fg"
                          type="number"
                          value={mine ? c.manualL : row.l}
                          onChange={(e) => {
                            const l = Number(e.target.value) || 0;
                            if (mine) update((x) => ({ ...x, manualL: l, manualRecord: true }));
                            else update((x) => ({ ...x, standings: x.standings.map((s) => (s.abbr === row.abbr ? { ...s, l } : s)) }));
                          }}
                        />
                      )}
                    </td>
                    <td className="py-2 tabular-nums text-muted">{gb <= 0 ? "—" : gb.toFixed(1)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Panel>
      <Panel kicker="Logged" title="Month by month">
        {months.length === 0 ? (
          <p className="text-sm text-muted">No dated games yet. The bars show up once the log has dates on it.</p>
        ) : (
          <div className="flex h-36 items-end gap-2">
            {months.map((m) => (
              <div key={m.month} className="flex h-full min-w-0 flex-1 flex-col justify-end">
                <div className="flex h-full items-end gap-1">
                  <div className="w-1/2 rounded-sm bg-orange" style={{ height: `${(m.w / max) * 100}%` }} />
                  <div className="w-1/2 rounded-sm bg-line" style={{ height: `${Math.max(4, (m.l / max) * 100)}%` }} />
                </div>
                <p className="mt-1 truncate text-center text-xs text-muted">{m.month.slice(5) || m.month}</p>
                <p className="text-center text-xs tabular-nums text-fg">
                  {m.w}–{m.l}
                </p>
              </div>
            ))}
          </div>
        )}
        <p className="mt-2 text-xs text-muted">Orange is wins. The dull bar is losses.</p>
      </Panel>
      <Panel kicker="Recent" title="From the log">
        {recent.length === 0 ? (
          <p className="text-sm text-muted">Nothing logged. The game log is where results live.</p>
        ) : (
          <ul>
            {recent.map((g) => (
              <li key={g.id} className="flex items-baseline justify-between gap-3 border-t border-line py-2 text-sm">
                <span className={g.result === "W" ? "font-display text-lg text-orange" : "font-display text-lg text-muted"}>{g.result}</span>
                <span className="min-w-0 flex-1 truncate text-fg">
                  {g.home ? "vs" : "at"} {g.opponent}
                </span>
                <span className="tabular-nums text-muted">
                  {g.runsFor}–{g.runsAgainst}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
