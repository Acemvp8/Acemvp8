import { useMemo, useState } from "react";
import { money } from "@/lib/franchise/selectors";
import { useActive } from "@/lib/franchise/store";
import type { Hand, Level, Player, Role, Throw } from "@/lib/franchise/types";
import { uid } from "@/lib/franchise/types";
import { Btn, ConfirmBtn, Field, Panel, fieldClass } from "./ui";

const POS = ["C", "1B", "2B", "3B", "SS", "LF", "CF", "RF", "OF", "DH", "UTIL", "IF", "SP", "RP"];

function fresh(): Player {
  return {
    id: uid("p"),
    name: "New player",
    pos: "UTIL",
    secondary: "",
    bats: "R",
    throws: "R",
    age: 25,
    ovr: 70,
    pot: 75,
    level: "MLB",
    role: "bench",
    salary: 1,
    years: 3,
    arb: false,
    untouchable: false,
    devFocus: "Hold",
    arsenal: "",
    notes: "",
  };
}

export function RosterDesk() {
  const { campaign: c, update } = useActive();
  const [q, setQ] = useState("");
  const [band, setBand] = useState<"all" | "mlb" | "il" | "farm" | "arms">("all");
  const [sel, setSel] = useState<string | null>(c.players[0]?.id ?? null);
  const rows = useMemo(() => {
    return c.players
      .filter((p) => {
        if (band === "mlb") return p.level === "MLB";
        if (band === "il") return p.level === "IL";
        if (band === "farm") return p.level === "AAA" || p.level === "AA" || p.role === "prospect";
        if (band === "arms") return p.pos === "SP" || p.pos === "RP";
        return true;
      })
      .filter((p) => p.name.toLowerCase().includes(q.trim().toLowerCase()))
      .sort((a, b) => b.ovr - a.ovr);
  }, [c.players, q, band]);
  const player = c.players.find((p) => p.id === sel) ?? null;

  function patch(id: string, partial: Partial<Player>) {
    update((x) => ({ ...x, players: x.players.map((p) => (p.id === id ? { ...p, ...partial } : p)) }));
  }

  return (
    <div>
      <Panel
        kicker="26-man"
        title="Roster"
        action={
          <Btn
            onClick={() => {
              const p = fresh();
              update((x) => ({ ...x, players: [...x.players, p] }));
              setSel(p.id);
            }}
          >
            Add
          </Btn>
        }
      >
        <p className="mb-3 text-sm text-muted">
          Overalls are planning numbers for your save, not official SDS attributes. Edit them to what you see on the player card.
        </p>
        <input className={fieldClass} placeholder="Search the roster" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="mt-2 flex gap-2 overflow-x-auto">
          {(
            [
              ["all", "All"],
              ["mlb", "MLB"],
              ["il", "IL"],
              ["farm", "Farm"],
              ["arms", "Arms"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              className={`shrink-0 rounded-lg px-3 py-2 font-display text-lg ${band === id ? "bg-orange text-ink" : "text-muted"}`}
              onClick={() => setBand(id)}
            >
              {label}
            </button>
          ))}
        </div>
        <ul className="mt-3">
          {rows.map((p) => (
            <li key={p.id}>
              <button
                type="button"
                onClick={() => setSel(p.id)}
                className={`flex w-full min-h-11 items-center gap-3 border-t border-line py-2 text-left ${sel === p.id ? "text-orange" : "text-fg"}`}
              >
                <span className="w-10 font-display text-xl tabular-nums">{p.ovr}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate">{p.name}</span>
                  <span className="block text-xs text-muted">
                    {p.pos}
                    {p.secondary ? `/${p.secondary}` : ""} · {p.bats}/{p.throws} · {p.level}
                    {p.untouchable ? " · untouchable" : ""}
                  </span>
                </span>
                <span className="text-xs text-muted">{p.years}y</span>
              </button>
            </li>
          ))}
        </ul>
      </Panel>
      {player ? (
        <Panel kicker="Card" title={player.name}>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Name">
              <input className={fieldClass} value={player.name} onChange={(e) => patch(player.id, { name: e.target.value })} />
            </Field>
            <Field label="Position">
              <select className={fieldClass} value={player.pos} onChange={(e) => patch(player.id, { pos: e.target.value })}>
                {POS.map((pos) => (
                  <option key={pos}>{pos}</option>
                ))}
              </select>
            </Field>
            <Field label="Secondary">
              <input className={fieldClass} value={player.secondary} onChange={(e) => patch(player.id, { secondary: e.target.value })} />
            </Field>
            <Field label="Bats">
              <select className={fieldClass} value={player.bats} onChange={(e) => patch(player.id, { bats: e.target.value as Hand })}>
                <option value="L">Left</option>
                <option value="R">Right</option>
                <option value="S">Switch</option>
              </select>
            </Field>
            <Field label="Throws">
              <select className={fieldClass} value={player.throws} onChange={(e) => patch(player.id, { throws: e.target.value as Throw })}>
                <option value="L">Left</option>
                <option value="R">Right</option>
              </select>
            </Field>
            <Field label="Age">
              <input className={fieldClass} type="number" value={player.age} onChange={(e) => patch(player.id, { age: Number(e.target.value) || 0 })} />
            </Field>
            <Field label="Overall">
              <input className={fieldClass} type="number" value={player.ovr} onChange={(e) => patch(player.id, { ovr: Number(e.target.value) || 0 })} />
            </Field>
            <Field label="Potential">
              <input className={fieldClass} type="number" value={player.pot} onChange={(e) => patch(player.id, { pot: Number(e.target.value) || 0 })} />
            </Field>
            <Field label="Level">
              <select className={fieldClass} value={player.level} onChange={(e) => patch(player.id, { level: e.target.value as Level })}>
                {(["MLB", "IL", "AAA", "AA"] as Level[]).map((lv) => (
                  <option key={lv}>{lv}</option>
                ))}
              </select>
            </Field>
            <Field label="Role">
              <select className={fieldClass} value={player.role} onChange={(e) => patch(player.id, { role: e.target.value as Role })}>
                {(["lineup", "bench", "rotation", "bullpen", "prospect", "il"] as Role[]).map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </Field>
            <Field label="Salary ($M)">
              <input className={fieldClass} type="number" step="0.1" value={player.salary} onChange={(e) => patch(player.id, { salary: Number(e.target.value) || 0 })} />
            </Field>
            <Field label="Years of control">
              <input className={fieldClass} type="number" value={player.years} onChange={(e) => patch(player.id, { years: Number(e.target.value) || 0 })} />
            </Field>
            <Field label="Arsenal tags">
              <input className={fieldClass} value={player.arsenal} placeholder="FB, SL, CH" onChange={(e) => patch(player.id, { arsenal: e.target.value })} />
            </Field>
            <Field label="Dev focus">
              <input className={fieldClass} value={player.devFocus} onChange={(e) => patch(player.id, { devFocus: e.target.value })} />
            </Field>
          </div>
          <div className="mt-3 flex flex-wrap gap-4">
            <label className="flex min-h-11 items-center gap-2 text-sm text-fg">
              <input type="checkbox" checked={player.arb} onChange={(e) => patch(player.id, { arb: e.target.checked })} />
              Arbitration year
            </label>
            <label className="flex min-h-11 items-center gap-2 text-sm text-fg">
              <input type="checkbox" checked={player.untouchable} onChange={(e) => patch(player.id, { untouchable: e.target.checked })} />
              Untouchable
            </label>
          </div>
          <Field label="Notes">
            <textarea className={`${fieldClass} mt-3 min-h-24`} value={player.notes} onChange={(e) => patch(player.id, { notes: e.target.value })} />
          </Field>
          <p className="mt-2 text-xs text-muted">
            {money(player.salary)} · {player.years} year{player.years === 1 ? "" : "s"} of control
            {player.arb ? " · arb" : ""}
          </p>
          <div className="mt-3">
            <ConfirmBtn
              label="Remove player"
              onConfirm={() =>
                update((x) => ({
                  ...x,
                  players: x.players.filter((p) => p.id !== player.id),
                  lineupR: x.lineupR.filter((s) => s.playerId !== player.id),
                  lineupL: x.lineupL.filter((s) => s.playerId !== player.id),
                  rotation: x.rotation.filter((id) => id !== player.id),
                  pen: x.pen.filter((s) => s.playerId !== player.id),
                }))
              }
            />
          </div>
        </Panel>
      ) : null}
    </div>
  );
}
