import { penBoard, starterBoard } from "@/lib/franchise/logic";
import { useActive } from "@/lib/franchise/store";
import type { PenRole } from "@/lib/franchise/types";
import { Callout, Panel, fieldClass } from "./ui";

const ROLES: PenRole[] = ["CL", "SU", "MR", "LVL", "LR", "OPN"];

export function ArmsDesk() {
  const { campaign: c, update } = useActive();
  const board = starterBoard(c);
  const next = [...board].sort((a, b) => (b.rest ?? 99) - (a.rest ?? 99))[0];
  const pens = penBoard(c);
  const starters = c.players.filter((p) => p.role === "rotation" || p.pos === "SP");
  const relievers = c.players.filter((p) => p.role === "bullpen" || p.pos === "RP");

  function moveRot(index: number, dir: number) {
    update((x) => {
      const rotation = [...x.rotation];
      const j = index + dir;
      if (j < 0 || j >= rotation.length) return x;
      const tmp = rotation[index]!;
      rotation[index] = rotation[j]!;
      rotation[j] = tmp;
      return { ...x, rotation };
    });
  }

  return (
    <div>
      <Callout>
        Rotations got longer and bullpen games are real. A sixth starter is a plan, not a failure. Opener lives in the
        pen roles. Rest is measured against the last dated game in your log — log the starter’s name exactly from the
        roster or the turn won’t see him.
      </Callout>
      <Panel kicker="Turn" title={next ? `Give the ball to ${next.player.name}` : "No rotation set"}>
        <ol className="flex flex-col gap-2">
          {board.map((row, i) => (
            <li key={row.player.id} className="flex items-center gap-3 rounded-lg border border-line bg-surface-2 px-3 py-2">
              <span className="font-display text-2xl text-orange tabular-nums">{i + 1}</span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-xl uppercase leading-none text-fg">{row.player.name}</p>
                <p className="text-xs text-muted">
                  {row.player.throws}HP · {row.player.ovr} OVR · {row.starts} logged start{row.starts === 1 ? "" : "s"}
                  {row.rest == null ? " · hasn’t started in the log" : ` · ${row.rest} days since last start`}
                </p>
                {row.player.arsenal ? <p className="text-xs text-faint">{row.player.arsenal}</p> : null}
              </div>
              <div className="flex flex-col">
                <button type="button" className="min-h-11 px-2 text-sm text-muted" onClick={() => moveRot(i, -1)}>
                  Up
                </button>
                <button type="button" className="min-h-11 px-2 text-sm text-muted" onClick={() => moveRot(i, 1)}>
                  Down
                </button>
              </div>
            </li>
          ))}
        </ol>
        <label className="mt-3 block text-sm text-muted">
          Add to the turn
          <select
            className={`${fieldClass} mt-1`}
            value=""
            onChange={(e) => {
              const id = e.target.value;
              if (!id) return;
              update((x) => (x.rotation.includes(id) ? x : { ...x, rotation: [...x.rotation, id] }));
            }}
          >
            <option value="">Pick an arm</option>
            {starters
              .filter((p) => !c.rotation.includes(p.id))
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
          </select>
        </label>
      </Panel>
      <Panel kicker="Pen" title="Who’s fresh">
        <ul className="flex flex-col gap-2">
          {pens.map(({ slot, player, apps }) => (
            <li key={slot.playerId} className="grid grid-cols-[1fr_6rem] items-center gap-2 rounded-lg border border-line px-3 py-2">
              <div className="min-w-0">
                <p className="truncate text-fg">{player?.name ?? "Missing arm"}</p>
                <p className={`text-xs ${apps >= 2 ? "text-orange" : "text-muted"}`}>
                  {apps} appearance{apps === 1 ? "" : "s"} in the last 3 logged games
                  {apps >= 2 ? " — sit him" : ""}
                </p>
              </div>
              <select
                className={fieldClass}
                value={slot.role}
                onChange={(e) =>
                  update((x) => ({
                    ...x,
                    pen: x.pen.map((p) => (p.playerId === slot.playerId ? { ...p, role: e.target.value as PenRole } : p)),
                  }))
                }
              >
                {ROLES.map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </li>
          ))}
        </ul>
        <label className="mt-3 block text-sm text-muted">
          Add a reliever
          <select
            className={`${fieldClass} mt-1`}
            value=""
            onChange={(e) => {
              const id = e.target.value;
              if (!id) return;
              update((x) => (x.pen.some((p) => p.playerId === id) ? x : { ...x, pen: [...x.pen, { playerId: id, role: "MR" }] }));
            }}
          >
            <option value="">Pick an arm</option>
            {relievers
              .filter((p) => !c.pen.some((s) => s.playerId === p.id))
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
          </select>
        </label>
        <p className="mt-2 text-xs text-faint">CL closer · SU setup · MR middle · LVL lefty · LR long · OPN opener</p>
      </Panel>
    </div>
  );
}
