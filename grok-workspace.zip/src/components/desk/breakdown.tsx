import { useState } from "react";
import { writeRecap } from "@/lib/franchise/logic";
import { orderedGames } from "@/lib/franchise/selectors";
import { useActive } from "@/lib/franchise/store";
import { uid } from "@/lib/franchise/types";
import { Btn, Callout, ConfirmBtn, Empty, Field, Panel, fieldClass } from "./ui";

export function BreakdownDesk() {
  const { campaign: c, update } = useActive();
  const last = orderedGames(c.games).slice(-1)[0];
  const [opponent, setOpponent] = useState(last?.opponent || c.nextOpponent || "");
  const [rf, setRf] = useState(last?.runsFor ?? 0);
  const [ra, setRa] = useState(last?.runsAgainst ?? 0);
  const [result, setResult] = useState<"W" | "L">(last?.result ?? "W");
  const [starter, setStarter] = useState(last?.starter ?? "");
  const [innings, setInnings] = useState(last?.innings ?? "");
  const [moment, setMoment] = useState(last?.moment ?? "");
  const [how, setHow] = useState(last?.how ?? "played");
  const [preview, setPreview] = useState<{ title: string; body: string } | null>(null);

  return (
    <div>
      <Callout>
        {c.team === "BAL"
          ? "Birdland Breakdown. Punchy, three or four beats, no headline voiceover. It writes from the facts you give it — your words, not a robot box score."
          : "A short recap in the same voice. It writes from the facts you type. Save the ones worth keeping."}
      </Callout>
      <Panel kicker="Copy" title="Write the night">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Opponent">
            <input className={fieldClass} value={opponent} onChange={(e) => setOpponent(e.target.value)} />
          </Field>
          <Field label="Result">
            <select className={fieldClass} value={result} onChange={(e) => setResult(e.target.value as "W" | "L")}>
              <option value="W">Win</option>
              <option value="L">Loss</option>
            </select>
          </Field>
          <Field label="Runs for">
            <input className={fieldClass} type="number" value={rf} onChange={(e) => setRf(Number(e.target.value) || 0)} />
          </Field>
          <Field label="Runs against">
            <input className={fieldClass} type="number" value={ra} onChange={(e) => setRa(Number(e.target.value) || 0)} />
          </Field>
          <Field label="Starter">
            <input className={fieldClass} value={starter} onChange={(e) => setStarter(e.target.value)} />
          </Field>
          <Field label="Innings">
            <input className={fieldClass} value={innings} onChange={(e) => setInnings(e.target.value)} />
          </Field>
        </div>
        <Field label="Key moment">
          <textarea className={`${fieldClass} mt-3 min-h-20`} value={moment} onChange={(e) => setMoment(e.target.value)} />
        </Field>
        <Field label="How it was played">
          <select className={`${fieldClass} mt-3`} value={how} onChange={(e) => setHow(e.target.value as typeof how)}>
            <option value="played">Played it</option>
            <option value="moment">Key moment</option>
            <option value="simmed">Simmed</option>
          </select>
        </Field>
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn
            disabled={!opponent.trim()}
            onClick={() =>
              setPreview(
                writeRecap({
                  team: c.team,
                  teamName: c.teamName,
                  opponent: opponent.trim(),
                  runsFor: rf,
                  runsAgainst: ra,
                  result,
                  starter,
                  innings,
                  moment,
                  how,
                }),
              )
            }
          >
            Generate recap
          </Btn>
          {last ? (
            <Btn
              tone="quiet"
              onClick={() => {
                setOpponent(last.opponent);
                setRf(last.runsFor);
                setRa(last.runsAgainst);
                setResult(last.result);
                setStarter(last.starter);
                setInnings(last.innings);
                setMoment(last.moment);
                setHow(last.how);
              }}
            >
              Use last game
            </Btn>
          ) : null}
        </div>
        {preview ? (
          <div className="mt-4 rounded-lg border border-line bg-surface-2 p-4">
            <p className="font-display text-xl uppercase tracking-wide text-orange">{preview.title}</p>
            <p className="mt-2 text-sm leading-relaxed text-fg">{preview.body}</p>
            <div className="mt-3">
              <Btn
                tone="ghost"
                onClick={() =>
                  update((x) => ({
                    ...x,
                    recaps: [{ id: uid("rc"), created: new Date().toISOString().slice(0, 10), title: preview.title, body: preview.body }, ...x.recaps],
                  }))
                }
              >
                Save recap
              </Btn>
            </div>
          </div>
        ) : null}
      </Panel>
      <Panel kicker="Tape" title="Saved">
        {c.recaps.length === 0 ? <Empty>Nothing saved. Generate one after a night worth remembering.</Empty> : null}
        {c.recaps.map((r) => (
          <article key={r.id} className="border-t border-line py-3">
            <p className="font-display text-lg uppercase text-fg">
              {r.title}
              <span className="ml-2 font-sans text-xs normal-case text-muted">{r.created}</span>
            </p>
            <p className="mt-1 text-sm leading-relaxed text-muted">{r.body}</p>
            <ConfirmBtn label="Delete" onConfirm={() => update((x) => ({ ...x, recaps: x.recaps.filter((row) => row.id !== r.id) }))} />
          </article>
        ))}
      </Panel>
    </div>
  );
}
