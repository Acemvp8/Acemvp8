import { useState } from "react";
import { useActive } from "@/lib/franchise/store";
import { uid, type ScoutReport } from "@/lib/franchise/types";
import { Btn, Callout, ConfirmBtn, Field, Panel, fieldClass } from "./ui";

const blank = (): ScoutReport => ({
  id: uid("s"),
  team: "",
  starter: "",
  threats: "",
  weak: "",
  bullpen: "",
  attack: "",
});

export function ScoutDesk() {
  const { campaign: c, update } = useActive();
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState<ScoutReport>(blank);

  function patch(id: string, partial: Partial<ScoutReport>) {
    update((x) => ({ ...x, reports: x.reports.map((r) => (r.id === id ? { ...r, ...partial } : r)) }));
  }

  return (
    <div>
      <Callout>
        These are attack cards, not a stats dump. Write what the pitcher actually throws, who beats you, and which
        inning the bullpen gets thin. The Yankees, Rays, and Red Sox cards came in from the ACE8 scouting notes — edit
        them if your save has moved on.
      </Callout>
      {c.reports.map((r) => (
        <Panel key={r.id} kicker="Report" title={r.team || "Untitled"}>
          <div className="grid gap-3">
            <Field label="Club">
              <input className={fieldClass} value={r.team} onChange={(e) => patch(r.id, { team: e.target.value })} />
            </Field>
            <Field label="Starter">
              <textarea className={`${fieldClass} min-h-20`} value={r.starter} onChange={(e) => patch(r.id, { starter: e.target.value })} />
            </Field>
            <Field label="Top threats">
              <textarea className={`${fieldClass} min-h-20`} value={r.threats} onChange={(e) => patch(r.id, { threats: e.target.value })} />
            </Field>
            <Field label="Where they’re soft">
              <textarea className={`${fieldClass} min-h-20`} value={r.weak} onChange={(e) => patch(r.id, { weak: e.target.value })} />
            </Field>
            <Field label="Bullpen">
              <textarea className={`${fieldClass} min-h-20`} value={r.bullpen} onChange={(e) => patch(r.id, { bullpen: e.target.value })} />
            </Field>
            <Field label="Attack plan">
              <textarea className={`${fieldClass} min-h-20`} value={r.attack} onChange={(e) => patch(r.id, { attack: e.target.value })} />
            </Field>
          </div>
          <div className="mt-3">
            <ConfirmBtn label="Delete report" onConfirm={() => update((x) => ({ ...x, reports: x.reports.filter((row) => row.id !== r.id) }))} />
          </div>
        </Panel>
      ))}
      {adding ? (
        <Panel kicker="New" title="Blank card">
          <Field label="Club">
            <input className={fieldClass} value={draft.team} onChange={(e) => setDraft({ ...draft, team: e.target.value })} />
          </Field>
          <div className="mt-3 flex gap-2">
            <Btn
              disabled={!draft.team.trim()}
              onClick={() => {
                update((x) => ({ ...x, reports: [...x.reports, draft] }));
                setDraft(blank());
                setAdding(false);
              }}
            >
              Save card
            </Btn>
            <Btn tone="quiet" onClick={() => setAdding(false)}>
              Cancel
            </Btn>
          </div>
        </Panel>
      ) : (
        <Btn onClick={() => setAdding(true)}>New scouting card</Btn>
      )}
    </div>
  );
}
