import { penBoard, starterBoard } from "@/lib/franchise/logic";
import {
  displayRecord,
  last10,
  money,
  paceWins,
  payroll,
  pythagWins,
  runTotals,
  streakLabel,
} from "@/lib/franchise/selectors";
import { useActive } from "@/lib/franchise/store";
import type { Strategy } from "@/lib/franchise/types";
import { Callout, Field, Panel, Stat, fieldClass } from "./ui";

export function Clubhouse() {
  const { campaign: c, update } = useActive();
  const rec = displayRecord(c);
  const runs = runTotals(c);
  const pace = paceWins(rec.w, rec.gp);
  const py = pythagWins(runs.rf, runs.ra, rec.gp || c.games.length);
  const l10 = last10(c);
  const pay = payroll(c.players);
  const room = c.budget - pay;
  const arms = starterBoard(c);
  const nextArm = [...arms].sort((a, b) => (b.rest ?? 99) - (a.rest ?? 99))[0];
  const tired = penBoard(c).filter((p) => p.apps >= 2 && p.player);
  const pending = c.offers.filter((o) => o.status === "pending" || o.status === "rumor");

  return (
    <div>
      <Callout>
        The Show 26 franchise desk. Trades are not instant — offers sit, rumors lie, division rivals don’t help you, and
        contenders buy now while rebuilders buy years. Ratings here are your planning numbers. Match them to the attribute
        screen.
      </Callout>
      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
        <Stat label="Pace" value={pace == null ? "—" : String(pace)} hint={rec.gp ? `${rec.gp} games counted` : "Log a game or set a manual record"} />
        <Stat label="Streak" value={streakLabel(c)} hint="From the game log" />
        <Stat label="Last 10" value={l10.n ? `${l10.w}–${l10.l}` : "—"} />
        <Stat label="Run diff" value={c.games.length ? `${runs.rf - runs.ra > 0 ? "+" : ""}${runs.rf - runs.ra}` : "—"} hint={c.games.length ? `${runs.rf} scored, ${runs.ra} allowed in the log` : "Logged games only"} />
        <Stat label="Pythag" value={py == null ? "—" : String(py)} hint="162-game pace from logged runs" />
        <Stat label="Room" value={money(room)} hint={`${money(pay)} on the books of ${money(c.budget)}`} />
      </div>

      <Panel kicker="Front office" title={c.strategy === "rebuild" ? "Tear it down clean" : c.strategy === "retool" ? "Win without emptying the farm" : "October is the job"}>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Plan">
            <select className={fieldClass} value={c.strategy} onChange={(e) => update((x) => ({ ...x, strategy: e.target.value as Strategy }))}>
              <option value="contend">Contend</option>
              <option value="retool">Retool</option>
              <option value="rebuild">Rebuild</option>
            </select>
          </Field>
          <Field label="Difficulty">
            <select className={fieldClass} value={c.difficulty} onChange={(e) => update((x) => ({ ...x, difficulty: e.target.value as typeof x.difficulty }))}>
              {["Beginner", "Veteran", "All-Star", "Hall of Fame", "Legend"].map((d) => (
                <option key={d}>{d}</option>
              ))}
            </select>
          </Field>
          <Field label="How you play">
            <select className={fieldClass} value={c.participation} onChange={(e) => update((x) => ({ ...x, participation: e.target.value as typeof x.participation }))}>
              <option>Play every game</option>
              <option>Key moments</option>
              <option>Sim the grind</option>
            </select>
          </Field>
        </div>
        <Field label="Memo">
          <textarea className={`${fieldClass} mt-3 min-h-24`} value={c.memo} onChange={(e) => update((x) => ({ ...x, memo: e.target.value }))} />
        </Field>
      </Panel>

      <Panel kicker="Next" title={c.nextOpponent ? `vs ${c.nextOpponent}` : "No series set"}>
        <p className="mb-3 text-sm text-muted">
          {c.nextWhere === "home" ? "Home" : "Away"}
          {c.nextGames ? ` · ${c.nextGames} games` : ""}
          {nextArm ? ` · Ball to ${nextArm.player.name}` : ""}
          {nextArm?.rest != null ? ` (${nextArm.rest} days off the last logged start)` : ""}
        </p>
        {c.nextNote ? <p className="mb-3 text-sm text-fg">{c.nextNote}</p> : null}
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Opponent">
            <input className={fieldClass} value={c.nextOpponent} onChange={(e) => update((x) => ({ ...x, nextOpponent: e.target.value }))} />
          </Field>
          <Field label="Site">
            <select className={fieldClass} value={c.nextWhere} onChange={(e) => update((x) => ({ ...x, nextWhere: e.target.value as "home" | "away" }))}>
              <option value="home">Home</option>
              <option value="away">Away</option>
            </select>
          </Field>
          <Field label="Games">
            <input className={fieldClass} type="number" min={1} max={7} value={c.nextGames} onChange={(e) => update((x) => ({ ...x, nextGames: Number(e.target.value) || 1 }))} />
          </Field>
          <Field label="Series note">
            <input className={fieldClass} value={c.nextNote} onChange={(e) => update((x) => ({ ...x, nextNote: e.target.value }))} />
          </Field>
        </div>
        {tired.length ? (
          <p className="mt-3 text-sm text-orange">
            Tired arms in the last three logged games: {tired.map((t) => t.player!.name).join(", ")}. Give them the night.
          </p>
        ) : null}
        {pending.length ? (
          <p className="mt-2 text-sm text-muted">{pending.length} offer{pending.length === 1 ? "" : "s"} still sitting in the trade hub. Don’t let them rot.</p>
        ) : null}
      </Panel>

      <Panel kicker="Owner sheet" title="Goals">
        <ul className="flex flex-col gap-2">
          {c.goals.map((g) => (
            <li key={g.id}>
              <label className="flex min-h-11 items-center gap-3 text-sm text-fg">
                <input
                  type="checkbox"
                  checked={g.done}
                  onChange={() => update((x) => ({ ...x, goals: x.goals.map((item) => (item.id === g.id ? { ...item, done: !item.done } : item)) }))}
                />
                <span className={g.done ? "text-muted line-through" : ""}>{g.label}</span>
              </label>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
