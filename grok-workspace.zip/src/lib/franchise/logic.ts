import type { Campaign, Offer } from "./types";
import { findPlayer } from "./selectors";

export type BatteryInput = {
  bats: "L" | "R" | "S";
  throws: "L" | "R";
  count: string;
  profile: "power" | "contact" | "speed" | "patient" | "chase" | "cold";
  runners: "empty" | "first" | "scoring" | "loaded";
  outs: 0 | 1 | 2;
  leverage: "low" | "mid" | "high";
  arsenal: string[];
  bearDown: boolean;
};

export type BatteryCall = {
  pitch: string;
  loc: string;
  zone: number | "up" | "away" | "in" | "down";
  why: string;
  backup: string;
  putaway: string;
  sequence: string[];
  running: string;
  bear: string;
};

const PITCH_NAME: Record<string, string> = {
  FB: "Four-seam",
  SNK: "Sinker",
  CUT: "Cutter",
  SL: "Slider",
  SW: "Sweeper",
  CB: "Curve",
  CH: "Changeup",
  SPL: "Splitter",
};

function pick(arsenal: string[], prefs: string[], fallback: string) {
  const hit = prefs.find((p) => arsenal.includes(p));
  return PITCH_NAME[hit ?? ""] ?? fallback;
}

function effectiveBat(bats: BatteryInput["bats"], throws: BatteryInput["throws"]): "L" | "R" {
  if (bats === "S") return throws === "R" ? "L" : "R";
  return bats;
}

export function callPitch(input: BatteryInput): BatteryCall {
  const bat = effectiveBat(input.bats, input.throws);
  const sameSide = input.throws === bat;
  const twoStrike = ["0-2", "1-2", "2-2", "3-2"].includes(input.count);
  const hitterCount = ["2-0", "3-0", "3-1"].includes(input.count);
  const arsenal = input.arsenal.length ? input.arsenal : ["FB", "SL", "CH"];
  const awayZone = bat === "R" ? 9 : 7;
  const inZone = bat === "R" ? 7 : 9;
  const hard = pick(arsenal, ["FB", "SNK", "CUT"], "Fastball");
  const soft = pick(arsenal, ["CH", "SPL", "CB", "SL", "SW"], "Changeup");
  const breaker = pick(arsenal, ["SL", "SW", "CB", "CUT"], "Breaking ball");

  let pitch = hard;
  let loc = sameSide ? "Arm-side edge, letter" : "Away edge, down";
  let zone: BatteryCall["zone"] = sameSide ? inZone : awayZone;
  let why = "Even count. Work the edge that matches the platoon, and don’t repeat the same window twice.";

  if (input.profile === "cold") {
    pitch = hard;
    loc = "Attack the middle third — not a cookie, a strike";
    zone = 5;
    why = "He’s cold. Don’t nibble yourself into a walk. Make him beat your best fastball in the zone.";
  } else if (input.runners === "loaded" && !twoStrike) {
    pitch = hard;
    loc = "Strike one, down in the zone";
    zone = 8;
    why = "Bases loaded. A walk is a run. Get a strike before you get cute.";
  } else if (twoStrike) {
    pitch = input.profile === "contact" ? soft : breaker;
    loc = "Below the zone — chase, not a strike";
    zone = "down";
    why = "Two strikes. Expand. The out is under the zone, not over the heart.";
  } else if (hitterCount) {
    pitch = hard;
    loc = sameSide ? "In, on the black" : "Away, on the black";
    zone = sameSide ? inZone : awayZone;
    why = "Hitter’s count. You need a strike, but it still has to be on the black. A get-me-over middle-middle is how innings die.";
  } else if (input.profile === "power") {
    pitch = soft;
    loc = "Away, off the plate";
    zone = "away";
    why = "Power bat. Stay off the inner half early. Let him pull a pitch that isn’t a strike.";
  } else if (input.profile === "patient") {
    pitch = hard;
    loc = "Edge of the zone, first pitch";
    zone = sameSide ? 6 : 4;
    why = "He won’t chase until you earn two strikes. Steal strike one on the corner, then expand.";
  } else if (input.profile === "chase") {
    pitch = breaker;
    loc = "Start it on the plate, finish off it";
    zone = "down";
    why = "Free swinger. You can expand earlier than the book says. Still start the at-bat with a strike so he has to respect it.";
  } else if (input.profile === "speed" || input.runners === "first") {
    pitch = hard;
    loc = "Middle-away, quick to the plate";
    zone = bat === "R" ? 6 : 4;
    why = "Speed in the at-bat or on the bases. Priority is a quick pitch and a strike, not a pretty sequence.";
  } else if (input.profile === "contact") {
    pitch = soft;
    loc = "Change the eye level. Down, then up.";
    zone = 8;
    why = "Contact bat. He barrels strikes. Change speeds and heights so he never sees the same one twice.";
  }

  if (input.leverage === "high" && input.profile !== "cold" && !hitterCount) {
    why += " Leverage is high — miss off the plate, not over it.";
  }
  if (input.runners === "scoring" && !twoStrike) {
    why += " Runner on third: a ball in the dirt scores. Keep the breaking ball a strike or don’t throw it.";
  }

  const running =
    input.runners === "empty"
      ? "Nobody on. Attack the hitter. The running game is not in this at-bat."
      : input.runners === "first"
        ? "Man on first. Slide-step if he can actually run. Hold him once, then pitch. A pickoff is a gift, not a plan."
        : input.runners === "scoring"
          ? "Runner in scoring position. First-pitch strike. No chase pitches that bounce."
          : "Bases loaded. Strike one. The walk is the same as a double.";

  const bear = !input.bearDown
    ? "Bear Down is in your pocket. Don’t spend it on a 0-0 strike. Save the extra command for the putaway or a one-run 8th."
    : twoStrike || input.leverage === "high"
      ? "Bear Down here. The Show 26 gives you more command on the pitch you choose — use it on the putaway, not a waste pitch."
      : "You can Bear Down, but this count doesn’t need it. Hold it for two strikes.";

  const putaway = `${input.profile === "contact" ? soft : breaker}, below the zone`;
  const backup = hitterCount ? `${hard} on the black if he takes` : `${breaker} to the opposite window`;

  const sequence = [
    `${input.count} — ${pitch}, ${loc}`,
    `If he takes: ${backup}`,
    `Putaway: ${putaway}`,
  ];

  return { pitch, loc, zone, why, backup, putaway, sequence, running, bear };
}

export function tradeFit(c: Campaign, offer: Offer) {
  const reasons: string[] = [];
  let score = 64;
  const ours = offer.ourIds
    .map((id) => findPlayer(c, id))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));
  const theirCount = offer.theirNames.map((n) => n.trim()).filter(Boolean).length;

  if (ours.some((p) => p.untouchable)) {
    return {
      score: 6,
      verdict: "Dead on arrival",
      reasons: [
        "An untouchable is in the deal. In The Show 26 that player is nearly impossible to move — pull him or expect a no.",
      ],
    };
  }
  if (!ours.length || !theirCount) {
    return {
      score: 0,
      verdict: "Incomplete",
      reasons: ["Name players on both sides. Empty offers don’t test the logic."],
    };
  }
  if (offer.sameDivision) {
    score -= 16;
    reasons.push("Same division. Clubs are less willing to arm a rival, even when the baseball is fair.");
  }
  const aav = ours.reduce((s, p) => s + (Number(p.salary) || 0), 0);
  if (offer.market === "small" && aav >= 18) {
    score -= 18;
    reasons.push(`About ${aav.toFixed(0)} million coming at a small-market club. They fade big money.`);
  } else if (offer.market === "small") {
    reasons.push("Small market, but the salary in your package is something they can carry.");
  }
  if (offer.partnerStance === "contend") {
    if (offer.theirControl === "control") {
      score -= 8;
      reasons.push("They’re in it. Contenders keep young control and buy the missing piece.");
    } else {
      score += 8;
      reasons.push("Contender shopping a rental or short control. That’s the player they’ll actually discuss.");
    }
  }
  if (offer.partnerStance === "rebuild") {
    if (offer.theirControl === "rental") {
      score -= 14;
      reasons.push("A rebuilder will not pay a prospect price for a rental. They want years.");
    } else {
      score += 10;
      reasons.push("Rebuild logic favors the years you’re asking for. This is the buy window.");
    }
  }
  if (offer.partnerStance === "retool") {
    reasons.push("Retooling clubs are picky. They’ll move a surplus bat and keep the one building block.");
  }
  if (offer.surplus) {
    score += 8;
    reasons.push("They have a crowd at the position. Surplus lowers the price — use it.");
  }
  if (ours.length + theirCount >= 6) {
    score -= 6;
    reasons.push("Big package. Four-for-four is legal now, but messy deals die while you wait.");
  }
  if (offer.days >= 4 && (offer.status === "pending" || offer.status === "rumor")) {
    score -= 10;
    reasons.push(`${offer.days} days on the table. Instant trades are gone. Wait much longer and they deal with someone else.`);
  }
  if (ours.some((p) => p.pot >= 84 && p.years >= 4 && p.age <= 25)) {
    score -= 6;
    reasons.push("You’re offering a young, high-upside player with control. The return has to be loud.");
  }
  score = Math.max(3, Math.min(96, score));
  const verdict = score >= 75 ? "They should listen" : score >= 55 ? "It’s a conversation" : score >= 38 ? "Long shot" : "They hang up";
  if (!reasons.length) reasons.push("Clean baseball deal. No extra tax from division, market, or control.");
  return { score, verdict, reasons };
}

function variant(seed: string, options: string[]) {
  let h = 0;
  for (const ch of seed) h = (h * 33 + ch.charCodeAt(0)) >>> 0;
  return options[h % options.length] ?? options[0]!;
}

export function writeRecap(input: {
  team: string;
  teamName: string;
  opponent: string;
  runsFor: number;
  runsAgainst: number;
  result: "W" | "L";
  starter: string;
  innings: string;
  moment: string;
  how: string;
}) {
  const voice = input.team === "BAL" ? "Birdland" : input.teamName;
  const score = `${input.teamName} ${input.runsFor}, ${input.opponent} ${input.runsAgainst}`;
  const seed = `${input.opponent}|${input.runsFor}|${input.runsAgainst}|${input.moment}|${input.starter}`;
  const win = input.result === "W";
  const open = variant(seed, win
    ? [`${voice} had an answer.`, `${input.teamName} took care of business.`, `Put this one on the right side of the ledger.`]
    : [`${voice} came up short.`, `Not the night ${input.teamName} drew up.`, `File it. The series isn’t over because of one night.`]);
  const starterBit = input.starter
    ? input.innings
      ? `${input.starter} gave them ${input.innings} innings and set the tone.`
      : `${input.starter} took the ball.`
    : "The starter’s line is still blank — fill it in if you want the recap to carry the arm.";
  const momentBit = input.moment
    ? `The inning everybody will remember: ${input.moment}.`
    : win
      ? "No single swing is in the notes, so the story is the crooked number and a staff that didn’t blink."
      : "The key miss isn’t written down yet. Add it if you want the recap to sting in the right place.";
  const close = variant(seed + "c", win
    ? [
        `${score}. That’s a night you build a month on.`,
        `${score}. Bank it and get the starter his rest.`,
        `${score}. ${voice} sounds better at this hour.`,
      ]
    : [
        `${score}. Don’t let one loss rewrite the plan.`,
        `${score}. The turn comes back around.`,
        `${score}. Shake the at-bat, not the season.`,
      ]);
  const howBit =
    input.how === "simmed"
      ? "Simmed night — trust the result, check the box, move the rotation."
      : input.how === "moment"
        ? "Played the moment that mattered and let the CPU have the rest."
        : "";
  const body = [open, starterBit, momentBit, howBit, close].filter(Boolean).join(" ");
  const title = input.team === "BAL" ? `Birdland Breakdown · ${input.opponent}` : `${input.teamName} · ${input.opponent}`;
  return { title, body };
}

export function applyTrade(c: Campaign, offer: Offer): Campaign {
  const remove = new Set(offer.ourIds);
  const additions = offer.theirNames
    .map((n) => n.trim())
    .filter(Boolean)
    .map((name) => ({
      id: `p_${Math.random().toString(36).slice(2, 10)}`,
      name,
      pos: "UTIL",
      secondary: "",
      bats: "R" as const,
      throws: "R" as const,
      age: 27,
      ovr: 74,
      pot: 76,
      level: "MLB" as const,
      role: "bench" as const,
      salary: 4,
      years: offer.theirControl === "rental" ? 1 : offer.theirControl === "mid" ? 3 : 5,
      arb: false,
      untouchable: false,
      devFocus: "Hold",
      arsenal: "",
      notes: `Came back from ${offer.partner}. Edit the attributes to match what you see in The Show.`,
    }));
  const players = [...c.players.filter((p) => !remove.has(p.id)), ...additions];
  const keep = (id: string) => !remove.has(id);
  return {
    ...c,
    players,
    lineupR: c.lineupR.filter((s) => keep(s.playerId)),
    lineupL: c.lineupL.filter((s) => keep(s.playerId)),
    rotation: c.rotation.filter(keep),
    pen: c.pen.filter((s) => keep(s.playerId)),
    offers: c.offers.map((o) => (o.id === offer.id ? { ...o, status: "accepted" as const } : o)),
  };
}

export function starterBoard(c: Campaign) {
  const games = [...(c.games ?? [])].filter((g) => g.date).sort((a, b) => a.date.localeCompare(b.date));
  const anchor = games.length ? games[games.length - 1]!.date : "";
  return c.rotation
    .map((id) => findPlayer(c, id))
    .filter((p): p is NonNullable<typeof p> => Boolean(p))
    .map((player) => {
      const starts = games.filter((g) => g.starter.trim().toLowerCase() === player.name.trim().toLowerCase());
      const last = starts.length ? starts[starts.length - 1]!.date : "";
      let rest: number | null = null;
      if (last && anchor) {
        rest = Math.round((Date.parse(anchor) - Date.parse(last)) / 86400000);
      }
      return { player, starts: starts.length, last, rest };
    });
}

export function penBoard(c: Campaign) {
  const recent = [...(c.games ?? [])]
    .filter((g) => g.date)
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 3);
  return c.pen.map((slot) => {
    const player = findPlayer(c, slot.playerId);
    const name = player?.name.toLowerCase() ?? "";
    const apps = name
      ? recent.filter((g) => g.relievers.toLowerCase().split(",").map((s) => s.trim()).includes(name)).length
      : 0;
    return { slot, player, apps, recent: recent.length };
  });
}
