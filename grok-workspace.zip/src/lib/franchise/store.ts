import { create } from "zustand";
import { persist } from "zustand/middleware";
import { createOriolesCampaign, normalizeCampaign } from "./seed";
import type { Campaign } from "./types";

type State = {
  campaigns: Campaign[];
  activeId: string;
  setActive: (id: string) => void;
  updateActive: (recipe: (c: Campaign) => Campaign) => void;
  addCampaign: (c: Campaign) => void;
  deleteCampaign: (id: string) => void;
};

const seed = createOriolesCampaign();

export const useFranchise = create<State>()(
  persist(
    (set, get) => ({
      campaigns: [seed],
      activeId: seed.id,
      setActive: (id) => set({ activeId: id }),
      updateActive: (recipe) => {
        const { campaigns, activeId } = get();
        set({
          campaigns: campaigns.map((c) => (c.id === activeId ? recipe(normalizeCampaign(c)) : c)),
        });
      },
      addCampaign: (c) => set({ campaigns: [...get().campaigns, normalizeCampaign(c)], activeId: c.id }),
      deleteCampaign: (id) => {
        const next = get().campaigns.filter((c) => c.id !== id);
        if (!next.length) {
          const fresh = createOriolesCampaign();
          set({ campaigns: [fresh], activeId: fresh.id });
          return;
        }
        set({ campaigns: next, activeId: get().activeId === id ? next[0]!.id : get().activeId });
      },
    }),
    {
      name: "ace8-franchise-v1",
      skipHydration: true,
      version: 1,
      merge: (persisted, current) => {
        const p = persisted as Partial<State> | undefined;
        if (!p?.campaigns?.length) return current;
        const campaigns = p.campaigns.map((c) => normalizeCampaign(c));
        const activeId = campaigns.some((c) => c.id === p.activeId) ? (p.activeId as string) : campaigns[0]!.id;
        return { ...current, campaigns, activeId };
      },
    },
  ),
);

export function useActive() {
  const campaigns = useFranchise((s) => s.campaigns);
  const activeId = useFranchise((s) => s.activeId);
  const updateActive = useFranchise((s) => s.updateActive);
  const campaign = campaigns.find((c) => c.id === activeId) ?? campaigns[0] ?? seed;
  return { campaign, update: updateActive };
}
