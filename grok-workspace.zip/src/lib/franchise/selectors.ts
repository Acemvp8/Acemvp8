import type { Campaign, GameLog, Player } from "./types";

export function orderedGames(games: GameLog[]) {
  return games
    .map((g, i) => ({ g, i }))
    .sort((a, b) => {
      const da = a.g.date || "9999-99-99";
      const db = b.g.date || "9999-99-99";
      if (da !== db) return da < db ? -1 : 1;
      return a.i - b.i;
    })
    .map((x) => x.g);
}

export function loggedRecord(c: Campaign) {
  const games = c.games ?? [];
  const w = games.filter((g) => g.result === "W").length;
  const l = games.filter((g) => g.result === "L").length;
  return { w, l, gp: w + l };
}

export function displayRecord(c: Campaign) {
  if (c.manualRecord) return { w: c.manualW || 0, l: c.manualL || 0, gp: (c.manualW || 0) + (c.manualL || 0) };
  return loggedRecord(c);
}

export function runTotals(c: Campaign) {
  return (c.games ?? []).reduce(
    (acc, g) => {
      acc.rf += Number(g.runsFor) || 0;
      acc.ra += Number(g.runsAgainst) || 0;
      return acc;
    },
    { rf: 0, ra: 0 },
  );
}

export function pythagWins(rf: number, ra: number, gp: number) {
  if (rf + ra === 0 || gp === 0) return null;
  const exp = 1.83;
  const pct = Math.pow(rf, exp) / (Math.pow(rf, exp) + Math.pow(ra, exp));
  return Math.round(pct * (gp >= 162 ? 162 : gp > 0 ? 162 : 0));
}

export function paceWins(w: number, gp: number) {
  if (!gp) return null;
  return Math.round((w / gp) * 162);
}

export function streakLabel(c: Campaign) {
  const games = orderedGames(c.games ?? []);
  if (!games.length) return "—";
  const last = games[games.length - 1]!.result;
  let n = 0;
  for (let i = games.length - 1; i >= 0; i--) {
    if (games[i]!.result !== last) break;
    n++;
  }
  return `${last}${n}`;
}

export function last10(c: Campaign) {
  const games = orderedGames(c.games ?? []).slice(-10);
  const w = games.filter((g) => g.result === "W").length;
  return { w, l: games.length - w, n: games.length };
}

export function payroll(players: Player[]) {
  return (players ?? [])
    .filter((p) => p.level === "MLB" || p.level === "IL")
    .reduce((s, p) => s + (Number(p.salary) || 0), 0);
}

export function monthSplits(c: Campaign) {
  const map = new Map<string, { month: string; w: number; l: number }>();
  for (const g of c.games ?? []) {
    const key = g.date ? g.date.slice(0, 7) : "Undated";
    const row = map.get(key) ?? { month: key, w: 0, l: 0 };
    if (g.result === "W") row.w += 1;
    else row.l += 1;
    map.set(key, row);
  }
  return [...map.values()].sort((a, b) => a.month.localeCompare(b.month));
}

export function findPlayer(c: Campaign, id: string) {
  return c.players.find((p) => p.id === id);
}

export function money(n: number) {
  const v = Number(n) || 0;
  return `$${v.toFixed(v % 1 ? 1 : 0)}M`;
}

export function mlbHitters(c: Campaign) {
  return c.players.filter((p) => p.level === "MLB" && p.role !== "rotation" && p.role !== "bullpen");
}

export function isPitcher(p: Player) {
  return p.pos === "SP" || p.pos === "RP" || p.role === "rotation" || p.role === "bullpen";
}
