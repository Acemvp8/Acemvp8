export type Club = { abbr: string; name: string; league: "AL" | "NL"; division: "East" | "Central" | "West" };

export const CLUBS: Club[] = [
  { abbr: "BAL", name: "Baltimore Orioles", league: "AL", division: "East" },
  { abbr: "BOS", name: "Boston Red Sox", league: "AL", division: "East" },
  { abbr: "NYY", name: "New York Yankees", league: "AL", division: "East" },
  { abbr: "TB", name: "Tampa Bay Rays", league: "AL", division: "East" },
  { abbr: "TOR", name: "Toronto Blue Jays", league: "AL", division: "East" },
  { abbr: "CLE", name: "Cleveland Guardians", league: "AL", division: "Central" },
  { abbr: "CWS", name: "Chicago White Sox", league: "AL", division: "Central" },
  { abbr: "DET", name: "Detroit Tigers", league: "AL", division: "Central" },
  { abbr: "KC", name: "Kansas City Royals", league: "AL", division: "Central" },
  { abbr: "MIN", name: "Minnesota Twins", league: "AL", division: "Central" },
  { abbr: "ATH", name: "Athletics", league: "AL", division: "West" },
  { abbr: "HOU", name: "Houston Astros", league: "AL", division: "West" },
  { abbr: "LAA", name: "Los Angeles Angels", league: "AL", division: "West" },
  { abbr: "SEA", name: "Seattle Mariners", league: "AL", division: "West" },
  { abbr: "TEX", name: "Texas Rangers", league: "AL", division: "West" },
  { abbr: "ATL", name: "Atlanta Braves", league: "NL", division: "East" },
  { abbr: "MIA", name: "Miami Marlins", league: "NL", division: "East" },
  { abbr: "NYM", name: "New York Mets", league: "NL", division: "East" },
  { abbr: "PHI", name: "Philadelphia Phillies", league: "NL", division: "East" },
  { abbr: "WSH", name: "Washington Nationals", league: "NL", division: "East" },
  { abbr: "CHC", name: "Chicago Cubs", league: "NL", division: "Central" },
  { abbr: "CIN", name: "Cincinnati Reds", league: "NL", division: "Central" },
  { abbr: "MIL", name: "Milwaukee Brewers", league: "NL", division: "Central" },
  { abbr: "PIT", name: "Pittsburgh Pirates", league: "NL", division: "Central" },
  { abbr: "STL", name: "St. Louis Cardinals", league: "NL", division: "Central" },
  { abbr: "ARI", name: "Arizona Diamondbacks", league: "NL", division: "West" },
  { abbr: "COL", name: "Colorado Rockies", league: "NL", division: "West" },
  { abbr: "LAD", name: "Los Angeles Dodgers", league: "NL", division: "West" },
  { abbr: "SD", name: "San Diego Padres", league: "NL", division: "West" },
  { abbr: "SF", name: "San Francisco Giants", league: "NL", division: "West" },
];

export function clubByAbbr(abbr: string) {
  return CLUBS.find((c) => c.abbr === abbr);
}

export function divisionMates(abbr: string) {
  const me = clubByAbbr(abbr);
  if (!me) return CLUBS.slice(0, 5);
  return CLUBS.filter((c) => c.league === me.league && c.division === me.division);
}

export function otherClubs(abbr: string) {
  return CLUBS.filter((c) => c.abbr !== abbr);
}
