export type Hand = "L" | "R" | "S";
export type Throw = "L" | "R";
export type Strategy = "contend" | "retool" | "rebuild";
export type Difficulty = "Beginner" | "Veteran" | "All-Star" | "Hall of Fame" | "Legend";
export type Participation = "Play every game" | "Key moments" | "Sim the grind";
export type Level = "MLB" | "IL" | "AAA" | "AA";
export type Role = "lineup" | "bench" | "rotation" | "bullpen" | "prospect" | "il";
export type PenRole = "CL" | "SU" | "MR" | "LVL" | "LR" | "OPN";
export type DeskId =
  | "clubhouse"
  | "season"
  | "log"
  | "lineups"
  | "arms"
  | "roster"
  | "pipeline"
  | "trades"
  | "scout"
  | "battery"
  | "ledger"
  | "breakdown";

export type Player = {
  id: string;
  name: string;
  pos: string;
  secondary: string;
  bats: Hand;
  throws: Throw;
  age: number;
  ovr: number;
  pot: number;
  level: Level;
  role: Role;
  salary: number;
  years: number;
  arb: boolean;
  untouchable: boolean;
  devFocus: string;
  arsenal: string;
  notes: string;
};

export type GameLog = {
  id: string;
  date: string;
  opponent: string;
  home: boolean;
  result: "W" | "L";
  runsFor: number;
  runsAgainst: number;
  starter: string;
  oppStarter: string;
  innings: string;
  pitches: string;
  relievers: string;
  moment: string;
  notes: string;
  how: "played" | "simmed" | "moment";
};

export type Standing = { abbr: string; name: string; w: number; l: number };

export type Offer = {
  id: string;
  partner: string;
  status: "rumor" | "pending" | "accepted" | "rejected" | "pulled";
  ourIds: string[];
  theirNames: string[];
  theirControl: "rental" | "mid" | "control";
  partnerStance: Strategy;
  sameDivision: boolean;
  market: "small" | "mid" | "large";
  surplus: boolean;
  days: number;
  note: string;
};

export type Rumor = { id: string; text: string; trust: "smoke" | "likely" | "noise" };

export type ScoutReport = {
  id: string;
  team: string;
  starter: string;
  threats: string;
  weak: string;
  bullpen: string;
  attack: string;
};

export type Recap = { id: string; created: string; title: string; body: string };

export type DevNote = { id: string; playerId: string; date: string; focus: string; note: string };

export type DraftPick = { id: string; round: string; name: string; pos: string; note: string };

export type Goal = { id: string; label: string; done: boolean };

export type LineupSlot = { playerId: string; pos: string };

export type PenSlot = { playerId: string; role: PenRole };

export type Campaign = {
  id: string;
  name: string;
  team: string;
  teamName: string;
  season: number;
  strategy: Strategy;
  difficulty: Difficulty;
  participation: Participation;
  budget: number;
  manualRecord: boolean;
  manualW: number;
  manualL: number;
  memo: string;
  goals: Goal[];
  players: Player[];
  lineupR: LineupSlot[];
  lineupL: LineupSlot[];
  rotation: string[];
  pen: PenSlot[];
  games: GameLog[];
  standings: Standing[];
  nextOpponent: string;
  nextWhere: "home" | "away";
  nextGames: number;
  nextNote: string;
  offers: Offer[];
  rumors: Rumor[];
  reports: ScoutReport[];
  recaps: Recap[];
  devNotes: DevNote[];
  draft: DraftPick[];
  intlNote: string;
};

export const DESKS: { id: DeskId; label: string; hint: string }[] = [
  { id: "clubhouse", label: "Clubhouse", hint: "The night’s board" },
  { id: "season", label: "Season", hint: "Standings and pace" },
  { id: "log", label: "Game log", hint: "What actually happened" },
  { id: "lineups", label: "Lineups", hint: "Vs right and vs left" },
  { id: "arms", label: "Arms", hint: "Turn and bullpen" },
  { id: "roster", label: "Roster", hint: "26-man and the IL" },
  { id: "pipeline", label: "Pipeline", hint: "Farm and the draft" },
  { id: "trades", label: "Trade hub", hint: "Offers, rumors, fit" },
  { id: "scout", label: "Scouting", hint: "How to attack them" },
  { id: "battery", label: "Battery", hint: "Call the pitch" },
  { id: "ledger", label: "Ledger", hint: "Control and money" },
  { id: "breakdown", label: "Breakdown", hint: "Write the recap" },
];

export const DEV_FOCUSES = [
  "Contact",
  "Power",
  "Vision",
  "Speed",
  "Defense",
  "Velocity",
  "Command",
  "Break",
  "Stamina",
  "Hold",
] as const;

export const ARSENAL_TAGS = ["FB", "SNK", "CUT", "SL", "SW", "CB", "CH", "SPL"] as const;

export function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}
