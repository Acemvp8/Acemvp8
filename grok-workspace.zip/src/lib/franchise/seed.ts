import { divisionMates, clubByAbbr } from "./teams";
import type {
  Campaign,
  Difficulty,
  Participation,
  Player,
  Strategy,
} from "./types";
import { uid } from "./types";

function player(p: Partial<Player> & Pick<Player, "id" | "name" | "pos">): Player {
  return {
    secondary: "",
    bats: "R",
    throws: "R",
    age: 26,
    ovr: 72,
    pot: 74,
    level: "MLB",
    role: "lineup",
    salary: 1,
    years: 3,
    arb: false,
    untouchable: false,
    devFocus: "Hold",
    arsenal: "",
    notes: "",
    ...p,
  };
}

function slot(playerId: string, pos: string) {
  return { playerId, pos };
}

export function blankRoster(): Player[] {
  const hitters: { pos: string; role: Player["role"] }[] = [
    { pos: "C", role: "lineup" },
    { pos: "1B", role: "lineup" },
    { pos: "2B", role: "lineup" },
    { pos: "3B", role: "lineup" },
    { pos: "SS", role: "lineup" },
    { pos: "LF", role: "lineup" },
    { pos: "CF", role: "lineup" },
    { pos: "RF", role: "lineup" },
    { pos: "DH", role: "lineup" },
    { pos: "C", role: "bench" },
    { pos: "UTIL", role: "bench" },
    { pos: "OF", role: "bench" },
    { pos: "IF", role: "bench" },
  ];
  const arms: { pos: "SP" | "RP"; role: Player["role"]; n: number }[] = [
    { pos: "SP", role: "rotation", n: 1 },
    { pos: "SP", role: "rotation", n: 2 },
    { pos: "SP", role: "rotation", n: 3 },
    { pos: "SP", role: "rotation", n: 4 },
    { pos: "SP", role: "rotation", n: 5 },
    { pos: "RP", role: "bullpen", n: 1 },
    { pos: "RP", role: "bullpen", n: 2 },
    { pos: "RP", role: "bullpen", n: 3 },
    { pos: "RP", role: "bullpen", n: 4 },
    { pos: "RP", role: "bullpen", n: 5 },
    { pos: "RP", role: "bullpen", n: 6 },
    { pos: "RP", role: "bullpen", n: 7 },
  ];
  const rows: Player[] = hitters.map((h, i) =>
    player({
      id: `h${i}`,
      name: h.role === "bench" ? `Bench ${h.pos}` : h.pos,
      pos: h.pos === "UTIL" || h.pos === "OF" || h.pos === "IF" ? "UTIL" : h.pos,
      role: h.role,
      ovr: 70,
      pot: 74,
      notes: "Rename this to the player on your The Show roster and set the overall you see.",
    }),
  );
  arms.forEach((a) => {
    rows.push(
      player({
        id: `${a.pos}${a.n}`,
        name: `${a.pos}${a.n}`,
        pos: a.pos,
        role: a.role,
        bats: "R",
        throws: "R",
        arsenal: "FB, SL, CH",
        devFocus: a.pos === "SP" ? "Command" : "Hold",
        notes: "Rename to match your save.",
      }),
    );
  });
  rows.push(
    player({
      id: "farm1",
      name: "Farm bat",
      pos: "OF",
      level: "AA",
      role: "prospect",
      age: 21,
      ovr: 62,
      pot: 80,
      salary: 0,
      years: 6,
      devFocus: "Power",
      notes: "Rename to a prospect in your system.",
    }),
    player({
      id: "farm2",
      name: "Farm arm",
      pos: "SP",
      level: "AA",
      role: "prospect",
      age: 21,
      ovr: 60,
      pot: 82,
      salary: 0,
      years: 6,
      arsenal: "FB, SL, CH",
      devFocus: "Velocity",
      notes: "Rename to a prospect in your system.",
    }),
  );
  return rows;
}

function shell(partial: {
  id: string;
  name: string;
  team: string;
  season: number;
  strategy: Strategy;
  difficulty: Difficulty;
  participation: Participation;
  players: Player[];
  lineupR: Campaign["lineupR"];
  lineupL: Campaign["lineupL"];
  rotation: string[];
  pen: Campaign["pen"];
  reports?: Campaign["reports"];
  goals?: Campaign["goals"];
  memo?: string;
  nextOpponent?: string;
  nextNote?: string;
}): Campaign {
  const meta = clubByAbbr(partial.team);
  return {
    id: partial.id,
    name: partial.name,
    team: partial.team,
    teamName: meta?.name ?? partial.team,
    season: partial.season,
    strategy: partial.strategy,
    difficulty: partial.difficulty,
    participation: partial.participation,
    budget: 175,
    manualRecord: false,
    manualW: 0,
    manualL: 0,
    memo: partial.memo ?? "Set the plan and stick to it. Contenders buy the missing piece. Rebuilders buy years.",
    goals: partial.goals ?? [
      { id: "g1", label: "Reach October", done: false },
      { id: "g2", label: "Win the division", done: false },
      { id: "g3", label: "Lock up one pre-arb star before the price jumps", done: false },
      { id: "g4", label: "Keep the untouchable list short", done: false },
    ],
    players: partial.players,
    lineupR: partial.lineupR,
    lineupL: partial.lineupL,
    rotation: partial.rotation,
    pen: partial.pen,
    games: [],
    standings: divisionMates(partial.team).map((c) => ({ abbr: c.abbr, name: c.name, w: 0, l: 0 })),
    nextOpponent: partial.nextOpponent ?? "",
    nextWhere: "home",
    nextGames: 3,
    nextNote: partial.nextNote ?? "",
    offers: [],
    rumors: [],
    reports: partial.reports ?? [],
    recaps: [],
    devNotes: [],
    draft: [],
    intlNote: "",
  };
}

const SCOUT: Campaign["reports"] = [
  {
    id: "s_nyy",
    team: "New York Yankees",
    starter: "Gerrit Cole — command is at a peak, but the long ball leaks (about 1.47 HR/9). Grind him into deep counts. Do not hand him first-pitch outs.",
    threats: "Ben Rice is the engine: 31 homers and a .927 OPS. He does damage on mistakes middle-in. Do not let him see the same fastball twice.",
    weak: "Anthony Volpe has one homer on the year. Austin Wells is in a career-worst season. Attack both early. The names around them are louder than the bats.",
    bullpen: "David Bednar is a real closer. Camilo Doval’s inconsistency is where a comeback lives. Get the game out of the starter and into the middle before Bednar.",
    attack: "Work deep counts on Cole. Expand away from Rice once you’re ahead. Sit fastball on Volpe. Win the game before the 9th.",
  },
  {
    id: "s_tb",
    team: "Tampa Bay Rays",
    starter: "Drew Rasmussen — sinker, sweeper, and four-seam are the real pitches. The cutter and the curve are the ones to hunt. Don’t swing at the sinker below the zone early.",
    threats: "Junior Caminero is the highest-rated bat in the room. Pitch him backwards and never give him the same look twice. Chandler Simpson is a 99-speed problem who will not chase. Strike one, then control the running game.",
    weak: "The bottom of the order is where the inning should end. Don’t extend at-bats against Caminero by missing over the plate.",
    bullpen: "Cleavinger and Uceta are real. The middle relief is replacement-level — that’s the inning you steal.",
    attack: "Division rival. The Show 26 also makes them stingier in trade talks, so don’t expect a discount if you’re shopping here too. On the field: strikes to Simpson, soft stuff away to Caminero, hunt Rasmussen’s cutter and curve.",
  },
  {
    id: "s_bos",
    team: "Boston Red Sox",
    starter: "Crochet’s name travels. The 2026 results (ERA north of 6, an injury-wrecked year) do not. Tolle and Gray have been the steadier arms. Plan for the pitcher on the mound, not the reputation.",
    threats: "Willson Contreras is the engine: .275/.386/.516, 27 homers, 81 RBI. Pitch him like he’s the only one who can beat you, because most nights he is.",
    weak: "Jarren Duran has been lost at the plate (.207, .627 OPS). Triston Casas has not played. Don’t fear a lineup card full of old names.",
    bullpen: "Aroldis Chapman, even at 38, has been elite late (1.95 ERA, 34 saves). Win it in the middle innings. If Chapman is in, the at-bat is a survival drill.",
    attack: "Get to the starter early. Attack Duran. Don’t give Contreras a fastball he can extend on. Be done scoring before the closer’s song.",
  },
];

export function createOriolesCampaign(id = "c_birdland"): Campaign {
  const players: Player[] = [
    player({ id: "gunnar", name: "Gunnar Henderson", pos: "SS", secondary: "3B", bats: "L", age: 25, ovr: 91, pot: 94, salary: 14.1, years: 3, arb: true, untouchable: true, devFocus: "Hold", notes: "Best player in the building. Two-hole bat in a modern order, not a vanity leadoff. Untouchable unless the return is a franchise." }),
    player({ id: "adley", name: "Adley Rutschman", pos: "C", secondary: "DH", bats: "S", age: 28, ovr: 86, pot: 88, salary: 9.5, years: 3, arb: true, devFocus: "Hold", notes: "Switch-hitting catcher. Handles the staff and hits in the middle. If your save already moved him, delete the card and scout the new catcher." }),
    player({ id: "alonso", name: "Pete Alonso", pos: "1B", bats: "R", age: 31, ovr: 84, pot: 84, salary: 31, years: 5, devFocus: "Hold", notes: "The middle of the order. Huge AAV — small-market clubs in The Show 26 will not take this contract clean. You’re paying him to hit." }),
    player({ id: "holiday", name: "Jackson Holliday", pos: "2B", secondary: "SS", bats: "L", age: 22, ovr: 82, pot: 92, salary: 0.8, years: 6, untouchable: true, devFocus: "Power", notes: "Pre-arb second baseman with years. Lock him up before arbitration makes the number stupid. On-base threat at the top." }),
    player({ id: "mayo", name: "Coby Mayo", pos: "3B", secondary: "1B", bats: "R", age: 24, ovr: 76, pot: 86, salary: 0.8, years: 6, devFocus: "Contact", notes: "Right-handed power, still finishing the hit tool. Everyday third until Westburg is actually on the field." }),
    player({ id: "cowser", name: "Colton Cowser", pos: "CF", secondary: "LF", bats: "L", throws: "L", age: 26, ovr: 79, pot: 84, salary: 0.8, years: 5, devFocus: "Power", notes: "Athletic center fielder. Gets on base and can play every day. Versus lefties, slide him down, don’t bench the glove unless the matchup is ugly." }),
    player({ id: "ward", name: "Taylor Ward", pos: "RF", secondary: "LF", bats: "R", age: 32, ovr: 78, pot: 78, salary: 8, years: 2, devFocus: "Hold", notes: "Right-handed corner bat brought in to balance the lefty core. Not a long-term piece. Play him against lefties." }),
    player({ id: "beavers", name: "Dylan Beavers", pos: "LF", secondary: "RF", bats: "L", age: 25, ovr: 74, pot: 83, salary: 0.8, years: 6, devFocus: "Contact", notes: "Corner bat with years. Everyday against righties. Development matters more than a two-week slump." }),
    player({ id: "mount", name: "Ryan Mountcastle", pos: "DH", secondary: "1B", bats: "R", age: 29, ovr: 74, pot: 75, salary: 6, years: 2, arb: true, devFocus: "Hold", notes: "Right-handed DH. Useful versus lefties. The contract is not long — don’t force him into a bad glove spot." }),
    player({ id: "oneill", name: "Tyler O'Neill", pos: "OF", secondary: "LF", bats: "R", age: 31, ovr: 76, pot: 76, salary: 8, years: 1, devFocus: "Hold", notes: "Power versus lefties, health is the whole question. Platoon weapon, not an everyday assumption." }),
    player({ id: "basallo", name: "Samuel Basallo", pos: "C", secondary: "1B", bats: "L", age: 22, ovr: 74, pot: 88, level: "MLB", role: "bench", salary: 0.8, years: 6, devFocus: "Defense", notes: "The catcher of the next window. Get him at-bats at DH. Don’t block him behind a veteran forever." }),
    player({ id: "narvaez", name: "Carlos Narvaez", pos: "C", bats: "R", age: 27, ovr: 70, pot: 72, role: "bench", salary: 1.2, years: 3, devFocus: "Hold", notes: "Backup catcher. Defense and a rest day for Adley. Not a trade chip that brings back a starter." }),
    player({ id: "blaze", name: "Blaze Alexander", pos: "UTIL", secondary: "3B", bats: "R", age: 27, ovr: 68, pot: 70, role: "bench", salary: 0.8, years: 4, devFocus: "Hold", notes: "Utility glove. Plays when somebody sits. Don’t let him hit in the top six unless the roster is wrecked." }),
    player({ id: "westburg", name: "Jordan Westburg", pos: "3B", secondary: "2B", bats: "R", age: 27, ovr: 80, pot: 84, level: "IL", role: "il", salary: 2, years: 4, arb: true, devFocus: "Hold", notes: "Missed a full real-world season hurt. In your save, flip him to MLB the day he’s active and put him back at third." }),
    player({ id: "kjerstad", name: "Heston Kjerstad", pos: "OF", secondary: "LF", bats: "L", age: 27, ovr: 73, pot: 80, level: "AAA", role: "prospect", salary: 0.8, years: 5, devFocus: "Contact", notes: "Corner bat one phone call away. Promote him if a lefty corner goes cold for a month, not for a weekend." }),
    player({ id: "rogers", name: "Trevor Rogers", pos: "SP", bats: "L", throws: "L", age: 28, ovr: 80, pot: 82, role: "rotation", salary: 6, years: 2, arb: true, arsenal: "FB, SL, CH", devFocus: "Command", notes: "Lefty who can take a series opener. Five or six innings and get out. Don’t let a good start become a 110-pitch hero outing." }),
    player({ id: "bradish", name: "Kyle Bradish", pos: "SP", bats: "R", throws: "R", age: 30, ovr: 82, pot: 84, role: "rotation", salary: 4, years: 3, arb: true, arsenal: "FB, SL, CB, CH", devFocus: "Stamina", notes: "Best pure stuff in the rotation when he’s right. Health is the season. Build his pitch count, don’t skip a turn to ‘save him’ unless the elbow says so." }),
    player({ id: "baz", name: "Shane Baz", pos: "SP", bats: "R", throws: "R", age: 27, ovr: 79, pot: 84, role: "rotation", salary: 3, years: 4, arb: true, arsenal: "FB, SL, CH, CB", devFocus: "Command", notes: "Power arm with years. A building block, not a rental. Secondary is slider and change — Battery desk knows the mix." }),
    player({ id: "eflin", name: "Zach Eflin", pos: "SP", bats: "R", throws: "R", age: 32, ovr: 77, pot: 77, role: "rotation", salary: 12, years: 1, arsenal: "FB, CUT, CB, CH", devFocus: "Hold", notes: "One-year strike thrower. Curve and cutter. He’s here to take the ball every fifth day, then walk." }),
    player({ id: "bassitt", name: "Chris Bassitt", pos: "SP", bats: "R", throws: "R", age: 37, ovr: 76, pot: 76, role: "rotation", salary: 15, years: 1, arsenal: "SNK, CUT, CB, CH, SPL", devFocus: "Hold", notes: "Kitchen-sink veteran. Sinker, cutter, curve, change, splitter. Pitch to weak contact. Short lease." }),
    player({ id: "povich", name: "Cade Povich", pos: "SP", bats: "L", throws: "L", age: 26, ovr: 72, pot: 78, role: "rotation", salary: 0.8, years: 5, arsenal: "FB, CB, CH, SL", devFocus: "Command", notes: "Sixth starter / spot lefty. Use him in a six-man turn or as the bullpen-game opener. Years of control, so don’t DFA him over three bad starts." }),
    player({ id: "helsley", name: "Ryan Helsley", pos: "RP", bats: "R", throws: "R", age: 32, ovr: 86, pot: 86, role: "bullpen", salary: 14, years: 2, arsenal: "FB, SL", devFocus: "Hold", notes: "The closer you paid for. Ninth inning, one-run and two-run games. Don’t bury the contract in the sixth." }),
    player({ id: "felix", name: "Felix Bautista", pos: "RP", bats: "R", throws: "R", age: 31, ovr: 84, pot: 85, role: "bullpen", salary: 2.4, years: 3, arb: true, arsenal: "FB, SPL", devFocus: "Stamina", notes: "Fastball-splitter monster on a friendly number. Setup, or closer if Helsley is down. Watch the workload coming off the long layoff." }),
    player({ id: "kitt", name: "Andrew Kittredge", pos: "RP", bats: "R", throws: "R", age: 36, ovr: 73, pot: 73, role: "bullpen", salary: 3, years: 1, arsenal: "SNK, SL", devFocus: "Hold", notes: "Sinker-slider setup. Seventh and eighth when the starter is out. Short lease." }),
    player({ id: "cano", name: "Yennier Cano", pos: "RP", bats: "R", throws: "R", age: 32, ovr: 74, pot: 74, role: "bullpen", salary: 2, years: 2, arb: true, arsenal: "SNK, SL, CH", devFocus: "Hold", notes: "Middle relief. Use him when the inning needs a ground ball, not when you need a strikeout with the bases loaded." }),
    player({ id: "akin", name: "Keegan Akin", pos: "RP", bats: "L", throws: "L", age: 31, ovr: 71, pot: 71, role: "bullpen", salary: 1.5, years: 1, arsenal: "FB, SL, CH", devFocus: "Hold", notes: "Lefty matchup and a full inning if the starter is a righty who just faced a lefty pocket." }),
    player({ id: "wolf", name: "Grant Wolfram", pos: "RP", bats: "L", throws: "L", age: 29, ovr: 69, pot: 72, role: "bullpen", salary: 0.8, years: 3, arsenal: "FB, SL, CH", devFocus: "Command", notes: "Second lefty. Don’t use both lefties in the same inning unless the lineup is stacked that way." }),
    player({ id: "young", name: "Brandon Young", pos: "RP", bats: "R", throws: "R", age: 27, ovr: 70, pot: 74, role: "bullpen", salary: 0.8, years: 5, arsenal: "FB, SL, CH", devFocus: "Stamina", notes: "Long man. He eats the blowup start. Multiple innings, low leverage, then a reset." }),
    player({ id: "farmof", name: "Farm corner bat", pos: "OF", bats: "L", age: 21, ovr: 64, pot: 82, level: "AA", role: "prospect", salary: 0, years: 6, devFocus: "Contact", notes: "Placeholder. Open the farm in The Show and rename this to the bat you actually believe in." }),
    player({ id: "farmsp", name: "Farm starter", pos: "SP", bats: "R", throws: "R", age: 21, ovr: 63, pot: 84, level: "AA", role: "prospect", salary: 0, years: 6, arsenal: "FB, SL, CH", devFocus: "Command", notes: "Placeholder arm. Put your real prospect’s name, overall, and potential here." }),
  ];

  const lineupR = [
    slot("holiday", "2B"),
    slot("gunnar", "SS"),
    slot("alonso", "1B"),
    slot("adley", "C"),
    slot("ward", "RF"),
    slot("cowser", "CF"),
    slot("mayo", "3B"),
    slot("beavers", "LF"),
    slot("mount", "DH"),
  ];
  const lineupL = [
    slot("gunnar", "SS"),
    slot("adley", "C"),
    slot("alonso", "1B"),
    slot("ward", "RF"),
    slot("mayo", "3B"),
    slot("oneill", "LF"),
    slot("mount", "DH"),
    slot("holiday", "2B"),
    slot("cowser", "CF"),
  ];

  return shell({
    id,
    name: "Birdland '26",
    team: "BAL",
    season: 2026,
    strategy: "contend",
    difficulty: "Veteran",
    participation: "Key moments",
    players,
    lineupR,
    lineupL,
    rotation: ["rogers", "bradish", "baz", "eflin", "bassitt", "povich"],
    pen: [
      { playerId: "helsley", role: "CL" },
      { playerId: "felix", role: "SU" },
      { playerId: "kitt", role: "SU" },
      { playerId: "cano", role: "MR" },
      { playerId: "akin", role: "LVL" },
      { playerId: "wolf", role: "LVL" },
      { playerId: "young", role: "LR" },
    ],
    reports: SCOUT,
    memo: "Contend. Alonso is the bat you bought. Henderson and Holliday do not move. Basallo gets at-bats. The rotation is Rogers, Bradish, Baz, Eflin, Bassitt — Povich is the sixth man, not a disposable.",
    nextOpponent: "Minnesota Twins",
    nextNote: "Opener. Rogers takes the ball at home. Play it.",
    goals: [
      { id: "g1", label: "Win the AL East", done: false },
      { id: "g2", label: "Play October baseball", done: false },
      { id: "g3", label: "Extend or commit to Holliday before arb explodes", done: false },
      { id: "g4", label: "Keep Henderson and Holliday untouchable", done: false },
      { id: "g5", label: "Get Basallo 200 plate appearances", done: false },
    ],
  });
}

export function createCampaign(opts: {
  name: string;
  team: string;
  season: number;
  strategy: Strategy;
  difficulty: Difficulty;
  participation: Participation;
  oriolesSnapshot: boolean;
}): Campaign {
  if (opts.oriolesSnapshot && opts.team === "BAL") {
    const c = createOriolesCampaign(uid("c"));
    return {
      ...c,
      name: opts.name || c.name,
      season: opts.season,
      strategy: opts.strategy,
      difficulty: opts.difficulty,
      participation: opts.participation,
    };
  }
  const players = blankRoster();
  const hitters = players.filter((p) => p.role === "lineup");
  const starters = players.filter((p) => p.role === "rotation").map((p) => p.id);
  const penPlayers = players.filter((p) => p.role === "bullpen");
  const roles: Campaign["pen"][number]["role"][] = ["CL", "SU", "SU", "MR", "MR", "LVL", "LR"];
  return shell({
    id: uid("c"),
    name: opts.name || `${opts.team} ${opts.season}`,
    team: opts.team,
    season: opts.season,
    strategy: opts.strategy,
    difficulty: opts.difficulty,
    participation: opts.participation,
    players,
    lineupR: hitters.slice(0, 9).map((p) => slot(p.id, p.pos)),
    lineupL: hitters.slice(0, 9).map((p) => slot(p.id, p.pos)),
    rotation: starters,
    pen: penPlayers.map((p, i) => ({ playerId: p.id, role: roles[i] ?? "MR" })),
    memo: "Rename every placeholder to the player in your save. Overalls here are planning numbers — match them to The Show.",
  });
}

export function normalizeCampaign(raw: Campaign): Campaign {
  const base = createCampaign({
    name: raw?.name || "Campaign",
    team: raw?.team || "BAL",
    season: raw?.season || 2026,
    strategy: raw?.strategy || "contend",
    difficulty: raw?.difficulty || "Veteran",
    participation: raw?.participation || "Key moments",
    oriolesSnapshot: false,
  });
  return {
    ...base,
    ...raw,
    players: raw.players?.length ? raw.players : base.players,
    lineupR: raw.lineupR ?? [],
    lineupL: raw.lineupL ?? [],
    rotation: raw.rotation ?? [],
    pen: raw.pen ?? [],
    games: raw.games ?? [],
    standings: raw.standings?.length ? raw.standings : base.standings,
    goals: raw.goals?.length ? raw.goals : base.goals,
    offers: raw.offers ?? [],
    rumors: raw.rumors ?? [],
    reports: raw.reports ?? [],
    recaps: raw.recaps ?? [],
    devNotes: raw.devNotes ?? [],
    draft: raw.draft ?? [],
    intlNote: raw.intlNote ?? "",
    manualRecord: Boolean(raw.manualRecord),
    manualW: raw.manualW ?? 0,
    manualL: raw.manualL ?? 0,
    budget: raw.budget ?? 175,
  };
}

export function isCampaign(x: unknown): x is Campaign {
  if (!x || typeof x !== "object") return false;
  const o = x as Campaign;
  return typeof o.id === "string" && typeof o.team === "string" && Array.isArray(o.players);
}
