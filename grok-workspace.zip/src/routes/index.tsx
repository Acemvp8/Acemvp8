import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Opening, Shell } from "@/components/desk/shell";
import { useFranchise } from "@/lib/franchise/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const finish = () => setReady(true);
    const unsub = useFranchise.persist.onFinishHydration(finish);
    if (useFranchise.persist.hasHydrated()) finish();
    else void useFranchise.persist.rehydrate();
    return () => {
      unsub();
    };
  }, []);
  if (!ready) return <Opening />;
  return <Shell />;
}
