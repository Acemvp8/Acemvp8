import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as NotebookPen, c as GitBranch, d as CalendarRange, f as Binoculars, i as Rows3, l as Crosshair, n as Users, o as Mic, p as ArrowLeftRight, s as LayoutDashboard, t as Wallet, u as CircleDot } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DHr3r6zC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CLUBS = [
	{
		abbr: "BAL",
		name: "Baltimore Orioles",
		league: "AL",
		division: "East"
	},
	{
		abbr: "BOS",
		name: "Boston Red Sox",
		league: "AL",
		division: "East"
	},
	{
		abbr: "NYY",
		name: "New York Yankees",
		league: "AL",
		division: "East"
	},
	{
		abbr: "TB",
		name: "Tampa Bay Rays",
		league: "AL",
		division: "East"
	},
	{
		abbr: "TOR",
		name: "Toronto Blue Jays",
		league: "AL",
		division: "East"
	},
	{
		abbr: "CLE",
		name: "Cleveland Guardians",
		league: "AL",
		division: "Central"
	},
	{
		abbr: "CWS",
		name: "Chicago White Sox",
		league: "AL",
		division: "Central"
	},
	{
		abbr: "DET",
		name: "Detroit Tigers",
		league: "AL",
		division: "Central"
	},
	{
		abbr: "KC",
		name: "Kansas City Royals",
		league: "AL",
		division: "Central"
	},
	{
		abbr: "MIN",
		name: "Minnesota Twins",
		league: "AL",
		division: "Central"
	},
	{
		abbr: "ATH",
		name: "Athletics",
		league: "AL",
		division: "West"
	},
	{
		abbr: "HOU",
		name: "Houston Astros",
		league: "AL",
		division: "West"
	},
	{
		abbr: "LAA",
		name: "Los Angeles Angels",
		league: "AL",
		division: "West"
	},
	{
		abbr: "SEA",
		name: "Seattle Mariners",
		league: "AL",
		division: "West"
	},
	{
		abbr: "TEX",
		name: "Texas Rangers",
		league: "AL",
		division: "West"
	},
	{
		abbr: "ATL",
		name: "Atlanta Braves",
		league: "NL",
		division: "East"
	},
	{
		abbr: "MIA",
		name: "Miami Marlins",
		league: "NL",
		division: "East"
	},
	{
		abbr: "NYM",
		name: "New York Mets",
		league: "NL",
		division: "East"
	},
	{
		abbr: "PHI",
		name: "Philadelphia Phillies",
		league: "NL",
		division: "East"
	},
	{
		abbr: "WSH",
		name: "Washington Nationals",
		league: "NL",
		division: "East"
	},
	{
		abbr: "CHC",
		name: "Chicago Cubs",
		league: "NL",
		division: "Central"
	},
	{
		abbr: "CIN",
		name: "Cincinnati Reds",
		league: "NL",
		division: "Central"
	},
	{
		abbr: "MIL",
		name: "Milwaukee Brewers",
		league: "NL",
		division: "Central"
	},
	{
		abbr: "PIT",
		name: "Pittsburgh Pirates",
		league: "NL",
		division: "Central"
	},
	{
		abbr: "STL",
		name: "St. Louis Cardinals",
		league: "NL",
		division: "Central"
	},
	{
		abbr: "ARI",
		name: "Arizona Diamondbacks",
		league: "NL",
		division: "West"
	},
	{
		abbr: "COL",
		name: "Colorado Rockies",
		league: "NL",
		division: "West"
	},
	{
		abbr: "LAD",
		name: "Los Angeles Dodgers",
		league: "NL",
		division: "West"
	},
	{
		abbr: "SD",
		name: "San Diego Padres",
		league: "NL",
		division: "West"
	},
	{
		abbr: "SF",
		name: "San Francisco Giants",
		league: "NL",
		division: "West"
	}
];
function clubByAbbr(abbr) {
	return CLUBS.find((c) => c.abbr === abbr);
}
function divisionMates(abbr) {
	const me = clubByAbbr(abbr);
	if (!me) return CLUBS.slice(0, 5);
	return CLUBS.filter((c) => c.league === me.league && c.division === me.division);
}
function otherClubs(abbr) {
	return CLUBS.filter((c) => c.abbr !== abbr);
}
var DESKS = [
	{
		id: "clubhouse",
		label: "Clubhouse",
		hint: "The night’s board"
	},
	{
		id: "season",
		label: "Season",
		hint: "Standings and pace"
	},
	{
		id: "log",
		label: "Game log",
		hint: "What actually happened"
	},
	{
		id: "lineups",
		label: "Lineups",
		hint: "Vs right and vs left"
	},
	{
		id: "arms",
		label: "Arms",
		hint: "Turn and bullpen"
	},
	{
		id: "roster",
		label: "Roster",
		hint: "26-man and the IL"
	},
	{
		id: "pipeline",
		label: "Pipeline",
		hint: "Farm and the draft"
	},
	{
		id: "trades",
		label: "Trade hub",
		hint: "Offers, rumors, fit"
	},
	{
		id: "scout",
		label: "Scouting",
		hint: "How to attack them"
	},
	{
		id: "battery",
		label: "Battery",
		hint: "Call the pitch"
	},
	{
		id: "ledger",
		label: "Ledger",
		hint: "Control and money"
	},
	{
		id: "breakdown",
		label: "Breakdown",
		hint: "Write the recap"
	}
];
var DEV_FOCUSES = [
	"Contact",
	"Power",
	"Vision",
	"Speed",
	"Defense",
	"Velocity",
	"Command",
	"Break",
	"Stamina",
	"Hold"
];
var ARSENAL_TAGS = [
	"FB",
	"SNK",
	"CUT",
	"SL",
	"SW",
	"CB",
	"CH",
	"SPL"
];
function uid(prefix) {
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}
function player(p) {
	return {
		secondary: "",
		bats: "R",
		throws: "R",
		age: 26,
		ovr: 72,
		pot: 74,
		level: "MLB",
		role: "lineup",
		salary: 1,
		years: 3,
		arb: false,
		untouchable: false,
		devFocus: "Hold",
		arsenal: "",
		notes: "",
		...p
	};
}
function slot(playerId, pos) {
	return {
		playerId,
		pos
	};
}
function blankRoster() {
	const hitters = [
		{
			pos: "C",
			role: "lineup"
		},
		{
			pos: "1B",
			role: "lineup"
		},
		{
			pos: "2B",
			role: "lineup"
		},
		{
			pos: "3B",
			role: "lineup"
		},
		{
			pos: "SS",
			role: "lineup"
		},
		{
			pos: "LF",
			role: "lineup"
		},
		{
			pos: "CF",
			role: "lineup"
		},
		{
			pos: "RF",
			role: "lineup"
		},
		{
			pos: "DH",
			role: "lineup"
		},
		{
			pos: "C",
			role: "bench"
		},
		{
			pos: "UTIL",
			role: "bench"
		},
		{
			pos: "OF",
			role: "bench"
		},
		{
			pos: "IF",
			role: "bench"
		}
	];
	const arms = [
		{
			pos: "SP",
			role: "rotation",
			n: 1
		},
		{
			pos: "SP",
			role: "rotation",
			n: 2
		},
		{
			pos: "SP",
			role: "rotation",
			n: 3
		},
		{
			pos: "SP",
			role: "rotation",
			n: 4
		},
		{
			pos: "SP",
			role: "rotation",
			n: 5
		},
		{
			pos: "RP",
			role: "bullpen",
			n: 1
		},
		{
			pos: "RP",
			role: "bullpen",
			n: 2
		},
		{
			pos: "RP",
			role: "bullpen",
			n: 3
		},
		{
			pos: "RP",
			role: "bullpen",
			n: 4
		},
		{
			pos: "RP",
			role: "bullpen",
			n: 5
		},
		{
			pos: "RP",
			role: "bullpen",
			n: 6
		},
		{
			pos: "RP",
			role: "bullpen",
			n: 7
		}
	];
	const rows = hitters.map((h, i) => player({
		id: `h${i}`,
		name: h.role === "bench" ? `Bench ${h.pos}` : h.pos,
		pos: h.pos === "UTIL" || h.pos === "OF" || h.pos === "IF" ? "UTIL" : h.pos,
		role: h.role,
		ovr: 70,
		pot: 74,
		notes: "Rename this to the player on your The Show roster and set the overall you see."
	}));
	arms.forEach((a) => {
		rows.push(player({
			id: `${a.pos}${a.n}`,
			name: `${a.pos}${a.n}`,
			pos: a.pos,
			role: a.role,
			bats: "R",
			throws: "R",
			arsenal: "FB, SL, CH",
			devFocus: a.pos === "SP" ? "Command" : "Hold",
			notes: "Rename to match your save."
		}));
	});
	rows.push(player({
		id: "farm1",
		name: "Farm bat",
		pos: "OF",
		level: "AA",
		role: "prospect",
		age: 21,
		ovr: 62,
		pot: 80,
		salary: 0,
		years: 6,
		devFocus: "Power",
		notes: "Rename to a prospect in your system."
	}), player({
		id: "farm2",
		name: "Farm arm",
		pos: "SP",
		level: "AA",
		role: "prospect",
		age: 21,
		ovr: 60,
		pot: 82,
		salary: 0,
		years: 6,
		arsenal: "FB, SL, CH",
		devFocus: "Velocity",
		notes: "Rename to a prospect in your system."
	}));
	return rows;
}
function shell(partial) {
	const meta = clubByAbbr(partial.team);
	return {
		id: partial.id,
		name: partial.name,
		team: partial.team,
		teamName: meta?.name ?? partial.team,
		season: partial.season,
		strategy: partial.strategy,
		difficulty: partial.difficulty,
		participation: partial.participation,
		budget: 175,
		manualRecord: false,
		manualW: 0,
		manualL: 0,
		memo: partial.memo ?? "Set the plan and stick to it. Contenders buy the missing piece. Rebuilders buy years.",
		goals: partial.goals ?? [
			{
				id: "g1",
				label: "Reach October",
				done: false
			},
			{
				id: "g2",
				label: "Win the division",
				done: false
			},
			{
				id: "g3",
				label: "Lock up one pre-arb star before the price jumps",
				done: false
			},
			{
				id: "g4",
				label: "Keep the untouchable list short",
				done: false
			}
		],
		players: partial.players,
		lineupR: partial.lineupR,
		lineupL: partial.lineupL,
		rotation: partial.rotation,
		pen: partial.pen,
		games: [],
		standings: divisionMates(partial.team).map((c) => ({
			abbr: c.abbr,
			name: c.name,
			w: 0,
			l: 0
		})),
		nextOpponent: partial.nextOpponent ?? "",
		nextWhere: "home",
		nextGames: 3,
		nextNote: partial.nextNote ?? "",
		offers: [],
		rumors: [],
		reports: partial.reports ?? [],
		recaps: [],
		devNotes: [],
		draft: [],
		intlNote: ""
	};
}
var SCOUT = [
	{
		id: "s_nyy",
		team: "New York Yankees",
		starter: "Gerrit Cole — command is at a peak, but the long ball leaks (about 1.47 HR/9). Grind him into deep counts. Do not hand him first-pitch outs.",
		threats: "Ben Rice is the engine: 31 homers and a .927 OPS. He does damage on mistakes middle-in. Do not let him see the same fastball twice.",
		weak: "Anthony Volpe has one homer on the year. Austin Wells is in a career-worst season. Attack both early. The names around them are louder than the bats.",
		bullpen: "David Bednar is a real closer. Camilo Doval’s inconsistency is where a comeback lives. Get the game out of the starter and into the middle before Bednar.",
		attack: "Work deep counts on Cole. Expand away from Rice once you’re ahead. Sit fastball on Volpe. Win the game before the 9th."
	},
	{
		id: "s_tb",
		team: "Tampa Bay Rays",
		starter: "Drew Rasmussen — sinker, sweeper, and four-seam are the real pitches. The cutter and the curve are the ones to hunt. Don’t swing at the sinker below the zone early.",
		threats: "Junior Caminero is the highest-rated bat in the room. Pitch him backwards and never give him the same look twice. Chandler Simpson is a 99-speed problem who will not chase. Strike one, then control the running game.",
		weak: "The bottom of the order is where the inning should end. Don’t extend at-bats against Caminero by missing over the plate.",
		bullpen: "Cleavinger and Uceta are real. The middle relief is replacement-level — that’s the inning you steal.",
		attack: "Division rival. The Show 26 also makes them stingier in trade talks, so don’t expect a discount if you’re shopping here too. On the field: strikes to Simpson, soft stuff away to Caminero, hunt Rasmussen’s cutter and curve."
	},
	{
		id: "s_bos",
		team: "Boston Red Sox",
		starter: "Crochet’s name travels. The 2026 results (ERA north of 6, an injury-wrecked year) do not. Tolle and Gray have been the steadier arms. Plan for the pitcher on the mound, not the reputation.",
		threats: "Willson Contreras is the engine: .275/.386/.516, 27 homers, 81 RBI. Pitch him like he’s the only one who can beat you, because most nights he is.",
		weak: "Jarren Duran has been lost at the plate (.207, .627 OPS). Triston Casas has not played. Don’t fear a lineup card full of old names.",
		bullpen: "Aroldis Chapman, even at 38, has been elite late (1.95 ERA, 34 saves). Win it in the middle innings. If Chapman is in, the at-bat is a survival drill.",
		attack: "Get to the starter early. Attack Duran. Don’t give Contreras a fastball he can extend on. Be done scoring before the closer’s song."
	}
];
function createOriolesCampaign(id = "c_birdland") {
	return shell({
		id,
		name: "Birdland '26",
		team: "BAL",
		season: 2026,
		strategy: "contend",
		difficulty: "Veteran",
		participation: "Key moments",
		players: [
			player({
				id: "gunnar",
				name: "Gunnar Henderson",
				pos: "SS",
				secondary: "3B",
				bats: "L",
				age: 25,
				ovr: 91,
				pot: 94,
				salary: 14.1,
				years: 3,
				arb: true,
				untouchable: true,
				devFocus: "Hold",
				notes: "Best player in the building. Two-hole bat in a modern order, not a vanity leadoff. Untouchable unless the return is a franchise."
			}),
			player({
				id: "adley",
				name: "Adley Rutschman",
				pos: "C",
				secondary: "DH",
				bats: "S",
				age: 28,
				ovr: 86,
				pot: 88,
				salary: 9.5,
				years: 3,
				arb: true,
				devFocus: "Hold",
				notes: "Switch-hitting catcher. Handles the staff and hits in the middle. If your save already moved him, delete the card and scout the new catcher."
			}),
			player({
				id: "alonso",
				name: "Pete Alonso",
				pos: "1B",
				bats: "R",
				age: 31,
				ovr: 84,
				pot: 84,
				salary: 31,
				years: 5,
				devFocus: "Hold",
				notes: "The middle of the order. Huge AAV — small-market clubs in The Show 26 will not take this contract clean. You’re paying him to hit."
			}),
			player({
				id: "holiday",
				name: "Jackson Holliday",
				pos: "2B",
				secondary: "SS",
				bats: "L",
				age: 22,
				ovr: 82,
				pot: 92,
				salary: .8,
				years: 6,
				untouchable: true,
				devFocus: "Power",
				notes: "Pre-arb second baseman with years. Lock him up before arbitration makes the number stupid. On-base threat at the top."
			}),
			player({
				id: "mayo",
				name: "Coby Mayo",
				pos: "3B",
				secondary: "1B",
				bats: "R",
				age: 24,
				ovr: 76,
				pot: 86,
				salary: .8,
				years: 6,
				devFocus: "Contact",
				notes: "Right-handed power, still finishing the hit tool. Everyday third until Westburg is actually on the field."
			}),
			player({
				id: "cowser",
				name: "Colton Cowser",
				pos: "CF",
				secondary: "LF",
				bats: "L",
				throws: "L",
				age: 26,
				ovr: 79,
				pot: 84,
				salary: .8,
				years: 5,
				devFocus: "Power",
				notes: "Athletic center fielder. Gets on base and can play every day. Versus lefties, slide him down, don’t bench the glove unless the matchup is ugly."
			}),
			player({
				id: "ward",
				name: "Taylor Ward",
				pos: "RF",
				secondary: "LF",
				bats: "R",
				age: 32,
				ovr: 78,
				pot: 78,
				salary: 8,
				years: 2,
				devFocus: "Hold",
				notes: "Right-handed corner bat brought in to balance the lefty core. Not a long-term piece. Play him against lefties."
			}),
			player({
				id: "beavers",
				name: "Dylan Beavers",
				pos: "LF",
				secondary: "RF",
				bats: "L",
				age: 25,
				ovr: 74,
				pot: 83,
				salary: .8,
				years: 6,
				devFocus: "Contact",
				notes: "Corner bat with years. Everyday against righties. Development matters more than a two-week slump."
			}),
			player({
				id: "mount",
				name: "Ryan Mountcastle",
				pos: "DH",
				secondary: "1B",
				bats: "R",
				age: 29,
				ovr: 74,
				pot: 75,
				salary: 6,
				years: 2,
				arb: true,
				devFocus: "Hold",
				notes: "Right-handed DH. Useful versus lefties. The contract is not long — don’t force him into a bad glove spot."
			}),
			player({
				id: "oneill",
				name: "Tyler O'Neill",
				pos: "OF",
				secondary: "LF",
				bats: "R",
				age: 31,
				ovr: 76,
				pot: 76,
				salary: 8,
				years: 1,
				devFocus: "Hold",
				notes: "Power versus lefties, health is the whole question. Platoon weapon, not an everyday assumption."
			}),
			player({
				id: "basallo",
				name: "Samuel Basallo",
				pos: "C",
				secondary: "1B",
				bats: "L",
				age: 22,
				ovr: 74,
				pot: 88,
				level: "MLB",
				role: "bench",
				salary: .8,
				years: 6,
				devFocus: "Defense",
				notes: "The catcher of the next window. Get him at-bats at DH. Don’t block him behind a veteran forever."
			}),
			player({
				id: "narvaez",
				name: "Carlos Narvaez",
				pos: "C",
				bats: "R",
				age: 27,
				ovr: 70,
				pot: 72,
				role: "bench",
				salary: 1.2,
				years: 3,
				devFocus: "Hold",
				notes: "Backup catcher. Defense and a rest day for Adley. Not a trade chip that brings back a starter."
			}),
			player({
				id: "blaze",
				name: "Blaze Alexander",
				pos: "UTIL",
				secondary: "3B",
				bats: "R",
				age: 27,
				ovr: 68,
				pot: 70,
				role: "bench",
				salary: .8,
				years: 4,
				devFocus: "Hold",
				notes: "Utility glove. Plays when somebody sits. Don’t let him hit in the top six unless the roster is wrecked."
			}),
			player({
				id: "westburg",
				name: "Jordan Westburg",
				pos: "3B",
				secondary: "2B",
				bats: "R",
				age: 27,
				ovr: 80,
				pot: 84,
				level: "IL",
				role: "il",
				salary: 2,
				years: 4,
				arb: true,
				devFocus: "Hold",
				notes: "Missed a full real-world season hurt. In your save, flip him to MLB the day he’s active and put him back at third."
			}),
			player({
				id: "kjerstad",
				name: "Heston Kjerstad",
				pos: "OF",
				secondary: "LF",
				bats: "L",
				age: 27,
				ovr: 73,
				pot: 80,
				level: "AAA",
				role: "prospect",
				salary: .8,
				years: 5,
				devFocus: "Contact",
				notes: "Corner bat one phone call away. Promote him if a lefty corner goes cold for a month, not for a weekend."
			}),
			player({
				id: "rogers",
				name: "Trevor Rogers",
				pos: "SP",
				bats: "L",
				throws: "L",
				age: 28,
				ovr: 80,
				pot: 82,
				role: "rotation",
				salary: 6,
				years: 2,
				arb: true,
				arsenal: "FB, SL, CH",
				devFocus: "Command",
				notes: "Lefty who can take a series opener. Five or six innings and get out. Don’t let a good start become a 110-pitch hero outing."
			}),
			player({
				id: "bradish",
				name: "Kyle Bradish",
				pos: "SP",
				bats: "R",
				throws: "R",
				age: 30,
				ovr: 82,
				pot: 84,
				role: "rotation",
				salary: 4,
				years: 3,
				arb: true,
				arsenal: "FB, SL, CB, CH",
				devFocus: "Stamina",
				notes: "Best pure stuff in the rotation when he’s right. Health is the season. Build his pitch count, don’t skip a turn to ‘save him’ unless the elbow says so."
			}),
			player({
				id: "baz",
				name: "Shane Baz",
				pos: "SP",
				bats: "R",
				throws: "R",
				age: 27,
				ovr: 79,
				pot: 84,
				role: "rotation",
				salary: 3,
				years: 4,
				arb: true,
				arsenal: "FB, SL, CH, CB",
				devFocus: "Command",
				notes: "Power arm with years. A building block, not a rental. Secondary is slider and change — Battery desk knows the mix."
			}),
			player({
				id: "eflin",
				name: "Zach Eflin",
				pos: "SP",
				bats: "R",
				throws: "R",
				age: 32,
				ovr: 77,
				pot: 77,
				role: "rotation",
				salary: 12,
				years: 1,
				arsenal: "FB, CUT, CB, CH",
				devFocus: "Hold",
				notes: "One-year strike thrower. Curve and cutter. He’s here to take the ball every fifth day, then walk."
			}),
			player({
				id: "bassitt",
				name: "Chris Bassitt",
				pos: "SP",
				bats: "R",
				throws: "R",
				age: 37,
				ovr: 76,
				pot: 76,
				role: "rotation",
				salary: 15,
				years: 1,
				arsenal: "SNK, CUT, CB, CH, SPL",
				devFocus: "Hold",
				notes: "Kitchen-sink veteran. Sinker, cutter, curve, change, splitter. Pitch to weak contact. Short lease."
			}),
			player({
				id: "povich",
				name: "Cade Povich",
				pos: "SP",
				bats: "L",
				throws: "L",
				age: 26,
				ovr: 72,
				pot: 78,
				role: "rotation",
				salary: .8,
				years: 5,
				arsenal: "FB, CB, CH, SL",
				devFocus: "Command",
				notes: "Sixth starter / spot lefty. Use him in a six-man turn or as the bullpen-game opener. Years of control, so don’t DFA him over three bad starts."
			}),
			player({
				id: "helsley",
				name: "Ryan Helsley",
				pos: "RP",
				bats: "R",
				throws: "R",
				age: 32,
				ovr: 86,
				pot: 86,
				role: "bullpen",
				salary: 14,
				years: 2,
				arsenal: "FB, SL",
				devFocus: "Hold",
				notes: "The closer you paid for. Ninth inning, one-run and two-run games. Don’t bury the contract in the sixth."
			}),
			player({
				id: "felix",
				name: "Felix Bautista",
				pos: "RP",
				bats: "R",
				throws: "R",
				age: 31,
				ovr: 84,
				pot: 85,
				role: "bullpen",
				salary: 2.4,
				years: 3,
				arb: true,
				arsenal: "FB, SPL",
				devFocus: "Stamina",
				notes: "Fastball-splitter monster on a friendly number. Setup, or closer if Helsley is down. Watch the workload coming off the long layoff."
			}),
			player({
				id: "kitt",
				name: "Andrew Kittredge",
				pos: "RP",
				bats: "R",
				throws: "R",
				age: 36,
				ovr: 73,
				pot: 73,
				role: "bullpen",
				salary: 3,
				years: 1,
				arsenal: "SNK, SL",
				devFocus: "Hold",
				notes: "Sinker-slider setup. Seventh and eighth when the starter is out. Short lease."
			}),
			player({
				id: "cano",
				name: "Yennier Cano",
				pos: "RP",
				bats: "R",
				throws: "R",
				age: 32,
				ovr: 74,
				pot: 74,
				role: "bullpen",
				salary: 2,
				years: 2,
				arb: true,
				arsenal: "SNK, SL, CH",
				devFocus: "Hold",
				notes: "Middle relief. Use him when the inning needs a ground ball, not when you need a strikeout with the bases loaded."
			}),
			player({
				id: "akin",
				name: "Keegan Akin",
				pos: "RP",
				bats: "L",
				throws: "L",
				age: 31,
				ovr: 71,
				pot: 71,
				role: "bullpen",
				salary: 1.5,
				years: 1,
				arsenal: "FB, SL, CH",
				devFocus: "Hold",
				notes: "Lefty matchup and a full inning if the starter is a righty who just faced a lefty pocket."
			}),
			player({
				id: "wolf",
				name: "Grant Wolfram",
				pos: "RP",
				bats: "L",
				throws: "L",
				age: 29,
				ovr: 69,
				pot: 72,
				role: "bullpen",
				salary: .8,
				years: 3,
				arsenal: "FB, SL, CH",
				devFocus: "Command",
				notes: "Second lefty. Don’t use both lefties in the same inning unless the lineup is stacked that way."
			}),
			player({
				id: "young",
				name: "Brandon Young",
				pos: "RP",
				bats: "R",
				throws: "R",
				age: 27,
				ovr: 70,
				pot: 74,
				role: "bullpen",
				salary: .8,
				years: 5,
				arsenal: "FB, SL, CH",
				devFocus: "Stamina",
				notes: "Long man. He eats the blowup start. Multiple innings, low leverage, then a reset."
			}),
			player({
				id: "farmof",
				name: "Farm corner bat",
				pos: "OF",
				bats: "L",
				age: 21,
				ovr: 64,
				pot: 82,
				level: "AA",
				role: "prospect",
				salary: 0,
				years: 6,
				devFocus: "Contact",
				notes: "Placeholder. Open the farm in The Show and rename this to the bat you actually believe in."
			}),
			player({
				id: "farmsp",
				name: "Farm starter",
				pos: "SP",
				bats: "R",
				throws: "R",
				age: 21,
				ovr: 63,
				pot: 84,
				level: "AA",
				role: "prospect",
				salary: 0,
				years: 6,
				arsenal: "FB, SL, CH",
				devFocus: "Command",
				notes: "Placeholder arm. Put your real prospect’s name, overall, and potential here."
			})
		],
		lineupR: [
			slot("holiday", "2B"),
			slot("gunnar", "SS"),
			slot("alonso", "1B"),
			slot("adley", "C"),
			slot("ward", "RF"),
			slot("cowser", "CF"),
			slot("mayo", "3B"),
			slot("beavers", "LF"),
			slot("mount", "DH")
		],
		lineupL: [
			slot("gunnar", "SS"),
			slot("adley", "C"),
			slot("alonso", "1B"),
			slot("ward", "RF"),
			slot("mayo", "3B"),
			slot("oneill", "LF"),
			slot("mount", "DH"),
			slot("holiday", "2B"),
			slot("cowser", "CF")
		],
		rotation: [
			"rogers",
			"bradish",
			"baz",
			"eflin",
			"bassitt",
			"povich"
		],
		pen: [
			{
				playerId: "helsley",
				role: "CL"
			},
			{
				playerId: "felix",
				role: "SU"
			},
			{
				playerId: "kitt",
				role: "SU"
			},
			{
				playerId: "cano",
				role: "MR"
			},
			{
				playerId: "akin",
				role: "LVL"
			},
			{
				playerId: "wolf",
				role: "LVL"
			},
			{
				playerId: "young",
				role: "LR"
			}
		],
		reports: SCOUT,
		memo: "Contend. Alonso is the bat you bought. Henderson and Holliday do not move. Basallo gets at-bats. The rotation is Rogers, Bradish, Baz, Eflin, Bassitt — Povich is the sixth man, not a disposable.",
		nextOpponent: "Minnesota Twins",
		nextNote: "Opener. Rogers takes the ball at home. Play it.",
		goals: [
			{
				id: "g1",
				label: "Win the AL East",
				done: false
			},
			{
				id: "g2",
				label: "Play October baseball",
				done: false
			},
			{
				id: "g3",
				label: "Extend or commit to Holliday before arb explodes",
				done: false
			},
			{
				id: "g4",
				label: "Keep Henderson and Holliday untouchable",
				done: false
			},
			{
				id: "g5",
				label: "Get Basallo 200 plate appearances",
				done: false
			}
		]
	});
}
function createCampaign(opts) {
	if (opts.oriolesSnapshot && opts.team === "BAL") {
		const c = createOriolesCampaign(uid("c"));
		return {
			...c,
			name: opts.name || c.name,
			season: opts.season,
			strategy: opts.strategy,
			difficulty: opts.difficulty,
			participation: opts.participation
		};
	}
	const players = blankRoster();
	const hitters = players.filter((p) => p.role === "lineup");
	const starters = players.filter((p) => p.role === "rotation").map((p) => p.id);
	const penPlayers = players.filter((p) => p.role === "bullpen");
	const roles = [
		"CL",
		"SU",
		"SU",
		"MR",
		"MR",
		"LVL",
		"LR"
	];
	return shell({
		id: uid("c"),
		name: opts.name || `${opts.team} ${opts.season}`,
		team: opts.team,
		season: opts.season,
		strategy: opts.strategy,
		difficulty: opts.difficulty,
		participation: opts.participation,
		players,
		lineupR: hitters.slice(0, 9).map((p) => slot(p.id, p.pos)),
		lineupL: hitters.slice(0, 9).map((p) => slot(p.id, p.pos)),
		rotation: starters,
		pen: penPlayers.map((p, i) => ({
			playerId: p.id,
			role: roles[i] ?? "MR"
		})),
		memo: "Rename every placeholder to the player in your save. Overalls here are planning numbers — match them to The Show."
	});
}
function normalizeCampaign(raw) {
	const base = createCampaign({
		name: raw?.name || "Campaign",
		team: raw?.team || "BAL",
		season: raw?.season || 2026,
		strategy: raw?.strategy || "contend",
		difficulty: raw?.difficulty || "Veteran",
		participation: raw?.participation || "Key moments",
		oriolesSnapshot: false
	});
	return {
		...base,
		...raw,
		players: raw.players?.length ? raw.players : base.players,
		lineupR: raw.lineupR ?? [],
		lineupL: raw.lineupL ?? [],
		rotation: raw.rotation ?? [],
		pen: raw.pen ?? [],
		games: raw.games ?? [],
		standings: raw.standings?.length ? raw.standings : base.standings,
		goals: raw.goals?.length ? raw.goals : base.goals,
		offers: raw.offers ?? [],
		rumors: raw.rumors ?? [],
		reports: raw.reports ?? [],
		recaps: raw.recaps ?? [],
		devNotes: raw.devNotes ?? [],
		draft: raw.draft ?? [],
		intlNote: raw.intlNote ?? "",
		manualRecord: Boolean(raw.manualRecord),
		manualW: raw.manualW ?? 0,
		manualL: raw.manualL ?? 0,
		budget: raw.budget ?? 175
	};
}
function isCampaign(x) {
	if (!x || typeof x !== "object") return false;
	const o = x;
	return typeof o.id === "string" && typeof o.team === "string" && Array.isArray(o.players);
}
var seed = createOriolesCampaign();
var useFranchise = create()(persist((set, get) => ({
	campaigns: [seed],
	activeId: seed.id,
	setActive: (id) => set({ activeId: id }),
	updateActive: (recipe) => {
		const { campaigns, activeId } = get();
		set({ campaigns: campaigns.map((c) => c.id === activeId ? recipe(normalizeCampaign(c)) : c) });
	},
	addCampaign: (c) => set({
		campaigns: [...get().campaigns, normalizeCampaign(c)],
		activeId: c.id
	}),
	deleteCampaign: (id) => {
		const next = get().campaigns.filter((c) => c.id !== id);
		if (!next.length) {
			const fresh = createOriolesCampaign();
			set({
				campaigns: [fresh],
				activeId: fresh.id
			});
			return;
		}
		set({
			campaigns: next,
			activeId: get().activeId === id ? next[0].id : get().activeId
		});
	}
}), {
	name: "ace8-franchise-v1",
	skipHydration: true,
	version: 1,
	merge: (persisted, current) => {
		const p = persisted;
		if (!p?.campaigns?.length) return current;
		const campaigns = p.campaigns.map((c) => normalizeCampaign(c));
		const activeId = campaigns.some((c) => c.id === p.activeId) ? p.activeId : campaigns[0].id;
		return {
			...current,
			campaigns,
			activeId
		};
	}
}));
function useActive() {
	const campaigns = useFranchise((s) => s.campaigns);
	const activeId = useFranchise((s) => s.activeId);
	const updateActive = useFranchise((s) => s.updateActive);
	return {
		campaign: campaigns.find((c) => c.id === activeId) ?? campaigns[0] ?? seed,
		update: updateActive
	};
}
function orderedGames(games) {
	return games.map((g, i) => ({
		g,
		i
	})).sort((a, b) => {
		const da = a.g.date || "9999-99-99";
		const db = b.g.date || "9999-99-99";
		if (da !== db) return da < db ? -1 : 1;
		return a.i - b.i;
	}).map((x) => x.g);
}
function loggedRecord(c) {
	const games = c.games ?? [];
	const w = games.filter((g) => g.result === "W").length;
	const l = games.filter((g) => g.result === "L").length;
	return {
		w,
		l,
		gp: w + l
	};
}
function displayRecord(c) {
	if (c.manualRecord) return {
		w: c.manualW || 0,
		l: c.manualL || 0,
		gp: (c.manualW || 0) + (c.manualL || 0)
	};
	return loggedRecord(c);
}
function runTotals(c) {
	return (c.games ?? []).reduce((acc, g) => {
		acc.rf += Number(g.runsFor) || 0;
		acc.ra += Number(g.runsAgainst) || 0;
		return acc;
	}, {
		rf: 0,
		ra: 0
	});
}
function pythagWins(rf, ra, gp) {
	if (rf + ra === 0 || gp === 0) return null;
	const exp = 1.83;
	const pct = Math.pow(rf, exp) / (Math.pow(rf, exp) + Math.pow(ra, exp));
	return Math.round(pct * (gp >= 162 ? 162 : gp > 0 ? 162 : 0));
}
function paceWins(w, gp) {
	if (!gp) return null;
	return Math.round(w / gp * 162);
}
function streakLabel(c) {
	const games = orderedGames(c.games ?? []);
	if (!games.length) return "—";
	const last = games[games.length - 1].result;
	let n = 0;
	for (let i = games.length - 1; i >= 0; i--) {
		if (games[i].result !== last) break;
		n++;
	}
	return `${last}${n}`;
}
function last10(c) {
	const games = orderedGames(c.games ?? []).slice(-10);
	const w = games.filter((g) => g.result === "W").length;
	return {
		w,
		l: games.length - w,
		n: games.length
	};
}
function payroll(players) {
	return (players ?? []).filter((p) => p.level === "MLB" || p.level === "IL").reduce((s, p) => s + (Number(p.salary) || 0), 0);
}
function monthSplits(c) {
	const map = /* @__PURE__ */ new Map();
	for (const g of c.games ?? []) {
		const key = g.date ? g.date.slice(0, 7) : "Undated";
		const row = map.get(key) ?? {
			month: key,
			w: 0,
			l: 0
		};
		if (g.result === "W") row.w += 1;
		else row.l += 1;
		map.set(key, row);
	}
	return [...map.values()].sort((a, b) => a.month.localeCompare(b.month));
}
function findPlayer(c, id) {
	return c.players.find((p) => p.id === id);
}
function money(n) {
	const v = Number(n) || 0;
	return `$${v.toFixed(v % 1 ? 1 : 0)}M`;
}
function mlbHitters(c) {
	return c.players.filter((p) => p.level === "MLB" && p.role !== "rotation" && p.role !== "bullpen");
}
function isPitcher(p) {
	return p.pos === "SP" || p.pos === "RP" || p.role === "rotation" || p.role === "bullpen";
}
var PITCH_NAME = {
	FB: "Four-seam",
	SNK: "Sinker",
	CUT: "Cutter",
	SL: "Slider",
	SW: "Sweeper",
	CB: "Curve",
	CH: "Changeup",
	SPL: "Splitter"
};
function pick(arsenal, prefs, fallback) {
	return PITCH_NAME[prefs.find((p) => arsenal.includes(p)) ?? ""] ?? fallback;
}
function effectiveBat(bats, throws) {
	if (bats === "S") return throws === "R" ? "L" : "R";
	return bats;
}
function callPitch(input) {
	const bat = effectiveBat(input.bats, input.throws);
	const sameSide = input.throws === bat;
	const twoStrike = [
		"0-2",
		"1-2",
		"2-2",
		"3-2"
	].includes(input.count);
	const hitterCount = [
		"2-0",
		"3-0",
		"3-1"
	].includes(input.count);
	const arsenal = input.arsenal.length ? input.arsenal : [
		"FB",
		"SL",
		"CH"
	];
	const awayZone = bat === "R" ? 9 : 7;
	const inZone = bat === "R" ? 7 : 9;
	const hard = pick(arsenal, [
		"FB",
		"SNK",
		"CUT"
	], "Fastball");
	const soft = pick(arsenal, [
		"CH",
		"SPL",
		"CB",
		"SL",
		"SW"
	], "Changeup");
	const breaker = pick(arsenal, [
		"SL",
		"SW",
		"CB",
		"CUT"
	], "Breaking ball");
	let pitch = hard;
	let loc = sameSide ? "Arm-side edge, letter" : "Away edge, down";
	let zone = sameSide ? inZone : awayZone;
	let why = "Even count. Work the edge that matches the platoon, and don’t repeat the same window twice.";
	if (input.profile === "cold") {
		pitch = hard;
		loc = "Attack the middle third — not a cookie, a strike";
		zone = 5;
		why = "He’s cold. Don’t nibble yourself into a walk. Make him beat your best fastball in the zone.";
	} else if (input.runners === "loaded" && !twoStrike) {
		pitch = hard;
		loc = "Strike one, down in the zone";
		zone = 8;
		why = "Bases loaded. A walk is a run. Get a strike before you get cute.";
	} else if (twoStrike) {
		pitch = input.profile === "contact" ? soft : breaker;
		loc = "Below the zone — chase, not a strike";
		zone = "down";
		why = "Two strikes. Expand. The out is under the zone, not over the heart.";
	} else if (hitterCount) {
		pitch = hard;
		loc = sameSide ? "In, on the black" : "Away, on the black";
		zone = sameSide ? inZone : awayZone;
		why = "Hitter’s count. You need a strike, but it still has to be on the black. A get-me-over middle-middle is how innings die.";
	} else if (input.profile === "power") {
		pitch = soft;
		loc = "Away, off the plate";
		zone = "away";
		why = "Power bat. Stay off the inner half early. Let him pull a pitch that isn’t a strike.";
	} else if (input.profile === "patient") {
		pitch = hard;
		loc = "Edge of the zone, first pitch";
		zone = sameSide ? 6 : 4;
		why = "He won’t chase until you earn two strikes. Steal strike one on the corner, then expand.";
	} else if (input.profile === "chase") {
		pitch = breaker;
		loc = "Start it on the plate, finish off it";
		zone = "down";
		why = "Free swinger. You can expand earlier than the book says. Still start the at-bat with a strike so he has to respect it.";
	} else if (input.profile === "speed" || input.runners === "first") {
		pitch = hard;
		loc = "Middle-away, quick to the plate";
		zone = bat === "R" ? 6 : 4;
		why = "Speed in the at-bat or on the bases. Priority is a quick pitch and a strike, not a pretty sequence.";
	} else if (input.profile === "contact") {
		pitch = soft;
		loc = "Change the eye level. Down, then up.";
		zone = 8;
		why = "Contact bat. He barrels strikes. Change speeds and heights so he never sees the same one twice.";
	}
	if (input.leverage === "high" && input.profile !== "cold" && !hitterCount) why += " Leverage is high — miss off the plate, not over it.";
	if (input.runners === "scoring" && !twoStrike) why += " Runner on third: a ball in the dirt scores. Keep the breaking ball a strike or don’t throw it.";
	const running = input.runners === "empty" ? "Nobody on. Attack the hitter. The running game is not in this at-bat." : input.runners === "first" ? "Man on first. Slide-step if he can actually run. Hold him once, then pitch. A pickoff is a gift, not a plan." : input.runners === "scoring" ? "Runner in scoring position. First-pitch strike. No chase pitches that bounce." : "Bases loaded. Strike one. The walk is the same as a double.";
	const bear = !input.bearDown ? "Bear Down is in your pocket. Don’t spend it on a 0-0 strike. Save the extra command for the putaway or a one-run 8th." : twoStrike || input.leverage === "high" ? "Bear Down here. The Show 26 gives you more command on the pitch you choose — use it on the putaway, not a waste pitch." : "You can Bear Down, but this count doesn’t need it. Hold it for two strikes.";
	const putaway = `${input.profile === "contact" ? soft : breaker}, below the zone`;
	const backup = hitterCount ? `${hard} on the black if he takes` : `${breaker} to the opposite window`;
	const sequence = [
		`${input.count} — ${pitch}, ${loc}`,
		`If he takes: ${backup}`,
		`Putaway: ${putaway}`
	];
	return {
		pitch,
		loc,
		zone,
		why,
		backup,
		putaway,
		sequence,
		running,
		bear
	};
}
function tradeFit(c, offer) {
	const reasons = [];
	let score = 64;
	const ours = offer.ourIds.map((id) => findPlayer(c, id)).filter((p) => Boolean(p));
	const theirCount = offer.theirNames.map((n) => n.trim()).filter(Boolean).length;
	if (ours.some((p) => p.untouchable)) return {
		score: 6,
		verdict: "Dead on arrival",
		reasons: ["An untouchable is in the deal. In The Show 26 that player is nearly impossible to move — pull him or expect a no."]
	};
	if (!ours.length || !theirCount) return {
		score: 0,
		verdict: "Incomplete",
		reasons: ["Name players on both sides. Empty offers don’t test the logic."]
	};
	if (offer.sameDivision) {
		score -= 16;
		reasons.push("Same division. Clubs are less willing to arm a rival, even when the baseball is fair.");
	}
	const aav = ours.reduce((s, p) => s + (Number(p.salary) || 0), 0);
	if (offer.market === "small" && aav >= 18) {
		score -= 18;
		reasons.push(`About ${aav.toFixed(0)} million coming at a small-market club. They fade big money.`);
	} else if (offer.market === "small") reasons.push("Small market, but the salary in your package is something they can carry.");
	if (offer.partnerStance === "contend") {
		if (offer.theirControl === "control") {
			score -= 8;
			reasons.push("They’re in it. Contenders keep young control and buy the missing piece.");
		} else {
			score += 8;
			reasons.push("Contender shopping a rental or short control. That’s the player they’ll actually discuss.");
		}
	}
	if (offer.partnerStance === "rebuild") {
		if (offer.theirControl === "rental") {
			score -= 14;
			reasons.push("A rebuilder will not pay a prospect price for a rental. They want years.");
		} else {
			score += 10;
			reasons.push("Rebuild logic favors the years you’re asking for. This is the buy window.");
		}
	}
	if (offer.partnerStance === "retool") reasons.push("Retooling clubs are picky. They’ll move a surplus bat and keep the one building block.");
	if (offer.surplus) {
		score += 8;
		reasons.push("They have a crowd at the position. Surplus lowers the price — use it.");
	}
	if (ours.length + theirCount >= 6) {
		score -= 6;
		reasons.push("Big package. Four-for-four is legal now, but messy deals die while you wait.");
	}
	if (offer.days >= 4 && (offer.status === "pending" || offer.status === "rumor")) {
		score -= 10;
		reasons.push(`${offer.days} days on the table. Instant trades are gone. Wait much longer and they deal with someone else.`);
	}
	if (ours.some((p) => p.pot >= 84 && p.years >= 4 && p.age <= 25)) {
		score -= 6;
		reasons.push("You’re offering a young, high-upside player with control. The return has to be loud.");
	}
	score = Math.max(3, Math.min(96, score));
	const verdict = score >= 75 ? "They should listen" : score >= 55 ? "It’s a conversation" : score >= 38 ? "Long shot" : "They hang up";
	if (!reasons.length) reasons.push("Clean baseball deal. No extra tax from division, market, or control.");
	return {
		score,
		verdict,
		reasons
	};
}
function variant(seed, options) {
	let h = 0;
	for (const ch of seed) h = h * 33 + ch.charCodeAt(0) >>> 0;
	return options[h % options.length] ?? options[0];
}
function writeRecap(input) {
	const voice = input.team === "BAL" ? "Birdland" : input.teamName;
	const score = `${input.teamName} ${input.runsFor}, ${input.opponent} ${input.runsAgainst}`;
	const seed = `${input.opponent}|${input.runsFor}|${input.runsAgainst}|${input.moment}|${input.starter}`;
	const win = input.result === "W";
	const open = variant(seed, win ? [
		`${voice} had an answer.`,
		`${input.teamName} took care of business.`,
		`Put this one on the right side of the ledger.`
	] : [
		`${voice} came up short.`,
		`Not the night ${input.teamName} drew up.`,
		`File it. The series isn’t over because of one night.`
	]);
	const starterBit = input.starter ? input.innings ? `${input.starter} gave them ${input.innings} innings and set the tone.` : `${input.starter} took the ball.` : "The starter’s line is still blank — fill it in if you want the recap to carry the arm.";
	const momentBit = input.moment ? `The inning everybody will remember: ${input.moment}.` : win ? "No single swing is in the notes, so the story is the crooked number and a staff that didn’t blink." : "The key miss isn’t written down yet. Add it if you want the recap to sting in the right place.";
	const close = variant(seed + "c", win ? [
		`${score}. That’s a night you build a month on.`,
		`${score}. Bank it and get the starter his rest.`,
		`${score}. ${voice} sounds better at this hour.`
	] : [
		`${score}. Don’t let one loss rewrite the plan.`,
		`${score}. The turn comes back around.`,
		`${score}. Shake the at-bat, not the season.`
	]);
	const body = [
		open,
		starterBit,
		momentBit,
		input.how === "simmed" ? "Simmed night — trust the result, check the box, move the rotation." : input.how === "moment" ? "Played the moment that mattered and let the CPU have the rest." : "",
		close
	].filter(Boolean).join(" ");
	return {
		title: input.team === "BAL" ? `Birdland Breakdown · ${input.opponent}` : `${input.teamName} · ${input.opponent}`,
		body
	};
}
function applyTrade(c, offer) {
	const remove = new Set(offer.ourIds);
	const additions = offer.theirNames.map((n) => n.trim()).filter(Boolean).map((name) => ({
		id: `p_${Math.random().toString(36).slice(2, 10)}`,
		name,
		pos: "UTIL",
		secondary: "",
		bats: "R",
		throws: "R",
		age: 27,
		ovr: 74,
		pot: 76,
		level: "MLB",
		role: "bench",
		salary: 4,
		years: offer.theirControl === "rental" ? 1 : offer.theirControl === "mid" ? 3 : 5,
		arb: false,
		untouchable: false,
		devFocus: "Hold",
		arsenal: "",
		notes: `Came back from ${offer.partner}. Edit the attributes to match what you see in The Show.`
	}));
	const players = [...c.players.filter((p) => !remove.has(p.id)), ...additions];
	const keep = (id) => !remove.has(id);
	return {
		...c,
		players,
		lineupR: c.lineupR.filter((s) => keep(s.playerId)),
		lineupL: c.lineupL.filter((s) => keep(s.playerId)),
		rotation: c.rotation.filter(keep),
		pen: c.pen.filter((s) => keep(s.playerId)),
		offers: c.offers.map((o) => o.id === offer.id ? {
			...o,
			status: "accepted"
		} : o)
	};
}
function starterBoard(c) {
	const games = [...c.games ?? []].filter((g) => g.date).sort((a, b) => a.date.localeCompare(b.date));
	const anchor = games.length ? games[games.length - 1].date : "";
	return c.rotation.map((id) => findPlayer(c, id)).filter((p) => Boolean(p)).map((player) => {
		const starts = games.filter((g) => g.starter.trim().toLowerCase() === player.name.trim().toLowerCase());
		const last = starts.length ? starts[starts.length - 1].date : "";
		let rest = null;
		if (last && anchor) rest = Math.round((Date.parse(anchor) - Date.parse(last)) / 864e5);
		return {
			player,
			starts: starts.length,
			last,
			rest
		};
	});
}
function penBoard(c) {
	const recent = [...c.games ?? []].filter((g) => g.date).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 3);
	return c.pen.map((slot) => {
		const player = findPlayer(c, slot.playerId);
		const name = player?.name.toLowerCase() ?? "";
		return {
			slot,
			player,
			apps: name ? recent.filter((g) => g.relievers.toLowerCase().split(",").map((s) => s.trim()).includes(name)).length : 0,
			recent: recent.length
		};
	});
}
var fieldClass = "min-h-11 w-full rounded-lg border border-line bg-surface-2 px-3 py-2 text-base text-fg outline-none focus:border-orange";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block font-display text-xs uppercase tracking-widest text-muted",
			children: label
		}), children]
	});
}
function Btn({ children, onClick, tone = "primary", type = "button", disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		disabled,
		onClick,
		className: `inline-flex min-h-11 items-center justify-center rounded-lg px-4 font-display text-lg tracking-wide disabled:opacity-40 ${{
			primary: "bg-orange text-ink",
			ghost: "border border-line bg-transparent text-fg",
			quiet: "border border-line bg-surface-2 text-muted"
		}[tone]}`,
		children
	});
}
function ConfirmBtn({ label, onConfirm }) {
	const [armed, setArmed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "inline-flex min-h-11 items-center justify-center rounded-lg border border-line px-3 font-display text-base tracking-wide text-muted",
		onClick: () => {
			if (!armed) {
				setArmed(true);
				return;
			}
			onConfirm();
			setArmed(false);
		},
		children: armed ? "Confirm" : label
	});
}
function Panel({ kicker, title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-4 rounded-lg border border-line bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs uppercase tracking-widest text-orange",
					children: kicker
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl uppercase leading-none tracking-wide text-fg",
					children: title
				})]
			}), action]
		}), children]
	});
}
function Callout({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-4 border-l-4 border-orange bg-orange-dim px-4 py-3 text-sm leading-relaxed text-fg",
		children
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-surface-2 px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs uppercase tracking-widest text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-3xl leading-none tracking-wide text-fg tabular-nums",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs leading-snug text-muted",
				children: hint
			}) : null
		]
	});
}
function Empty({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children
	});
}
var ROLES = [
	"CL",
	"SU",
	"MR",
	"LVL",
	"LR",
	"OPN"
];
function ArmsDesk() {
	const { campaign: c, update } = useActive();
	const board = starterBoard(c);
	const next = [...board].sort((a, b) => (b.rest ?? 99) - (a.rest ?? 99))[0];
	const pens = penBoard(c);
	const starters = c.players.filter((p) => p.role === "rotation" || p.pos === "SP");
	const relievers = c.players.filter((p) => p.role === "bullpen" || p.pos === "RP");
	function moveRot(index, dir) {
		update((x) => {
			const rotation = [...x.rotation];
			const j = index + dir;
			if (j < 0 || j >= rotation.length) return x;
			const tmp = rotation[index];
			rotation[index] = rotation[j];
			rotation[j] = tmp;
			return {
				...x,
				rotation
			};
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "Rotations got longer and bullpen games are real. A sixth starter is a plan, not a failure. Opener lives in the pen roles. Rest is measured against the last dated game in your log — log the starter’s name exactly from the roster or the turn won’t see him." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Turn",
			title: next ? `Give the ball to ${next.player.name}` : "No rotation set",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-2",
				children: board.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-lg border border-line bg-surface-2 px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-2xl text-orange tabular-nums",
							children: i + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-display text-xl uppercase leading-none text-fg",
									children: row.player.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										row.player.throws,
										"HP · ",
										row.player.ovr,
										" OVR · ",
										row.starts,
										" logged start",
										row.starts === 1 ? "" : "s",
										row.rest == null ? " · hasn’t started in the log" : ` · ${row.rest} days since last start`
									]
								}),
								row.player.arsenal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-faint",
									children: row.player.arsenal
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 px-2 text-sm text-muted",
								onClick: () => moveRot(i, -1),
								children: "Up"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 px-2 text-sm text-muted",
								onClick: () => moveRot(i, 1),
								children: "Down"
							})]
						})
					]
				}, row.player.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 block text-sm text-muted",
				children: ["Add to the turn", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: `${fieldClass} mt-1`,
					value: "",
					onChange: (e) => {
						const id = e.target.value;
						if (!id) return;
						update((x) => x.rotation.includes(id) ? x : {
							...x,
							rotation: [...x.rotation, id]
						});
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Pick an arm"
					}), starters.filter((p) => !c.rotation.includes(p.id)).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.id,
						children: p.name
					}, p.id))]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Pen",
			title: "Who’s fresh",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: pens.map(({ slot, player, apps }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid grid-cols-[1fr_6rem] items-center gap-2 rounded-lg border border-line px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-fg",
								children: player?.name ?? "Missing arm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: `text-xs ${apps >= 2 ? "text-orange" : "text-muted"}`,
								children: [
									apps,
									" appearance",
									apps === 1 ? "" : "s",
									" in the last 3 logged games",
									apps >= 2 ? " — sit him" : ""
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: slot.role,
							onChange: (e) => update((x) => ({
								...x,
								pen: x.pen.map((p) => p.playerId === slot.playerId ? {
									...p,
									role: e.target.value
								} : p)
							})),
							children: ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: r }, r))
						})]
					}, slot.playerId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm text-muted",
					children: ["Add a reliever", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: `${fieldClass} mt-1`,
						value: "",
						onChange: (e) => {
							const id = e.target.value;
							if (!id) return;
							update((x) => x.pen.some((p) => p.playerId === id) ? x : {
								...x,
								pen: [...x.pen, {
									playerId: id,
									role: "MR"
								}]
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Pick an arm"
						}), relievers.filter((p) => !c.pen.some((s) => s.playerId === p.id)).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.id,
							children: p.name
						}, p.id))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-faint",
					children: "CL closer · SU setup · MR middle · LVL lefty · LR long · OPN opener"
				})
			]
		})
	] });
}
var COUNTS = [
	"0-0",
	"1-0",
	"0-1",
	"2-0",
	"1-1",
	"0-2",
	"3-0",
	"2-1",
	"1-2",
	"3-1",
	"2-2",
	"3-2"
];
function lit(zone, call, bat) {
	const t = call.zone;
	if (typeof t === "number") return zone === t;
	if (t === "down") return zone >= 7;
	if (t === "up") return zone <= 3;
	const away = bat === "R" ? [
		3,
		6,
		9
	] : [
		1,
		4,
		7
	];
	const inn = bat === "R" ? [
		1,
		4,
		7
	] : [
		3,
		6,
		9
	];
	if (t === "away") return away.includes(zone);
	return inn.includes(zone);
}
function BatteryDesk() {
	const { campaign: c } = useActive();
	const arms = c.players.filter((p) => p.pos === "SP" || p.pos === "RP" || p.role === "rotation" || p.role === "bullpen");
	const [pitcherId, setPitcherId] = (0, import_react.useState)("");
	const [bats, setBats] = (0, import_react.useState)("R");
	const [throws, setThrows] = (0, import_react.useState)("R");
	const [count, setCount] = (0, import_react.useState)("1-1");
	const [profile, setProfile] = (0, import_react.useState)("power");
	const [runners, setRunners] = (0, import_react.useState)("empty");
	const [outs, setOuts] = (0, import_react.useState)(0);
	const [leverage, setLeverage] = (0, import_react.useState)("mid");
	const [arsenal, setArsenal] = (0, import_react.useState)([
		"FB",
		"SL",
		"CH"
	]);
	const [bearDown, setBearDown] = (0, import_react.useState)(false);
	const [call, setCall] = (0, import_react.useState)(null);
	const showBat = bats === "S" ? throws === "R" ? "L" : "R" : bats;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "A three-pitch sequence for the count you’re in. Bear Down is the The Show 26 command boost — spend it on the putaway, not a 0-0 strike. Catcher’s view on the zone." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		kicker: "Signs",
		title: "Call the pitch",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-muted",
						children: ["Our pitcher", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: `${fieldClass} mt-1`,
							value: pitcherId,
							onChange: (e) => {
								const id = e.target.value;
								setPitcherId(id);
								const p = arms.find((a) => a.id === id);
								if (!p) return;
								setThrows(p.throws === "L" ? "L" : "R");
								const tags = p.arsenal.split(/[^A-Za-z]+/).map((s) => s.toUpperCase()).filter((s) => ARSENAL_TAGS.includes(s));
								if (tags.length) setArsenal(tags);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Generic mix"
							}), arms.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: p.id,
								children: [
									p.name,
									" · ",
									p.throws,
									"HP"
								]
							}, p.id))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-muted",
						children: ["Batter bats", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: `${fieldClass} mt-1`,
							value: bats,
							onChange: (e) => setBats(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "R",
									children: "Right"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "L",
									children: "Left"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "S",
									children: "Switch"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-muted",
						children: ["Count", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: `${fieldClass} mt-1`,
							value: count,
							onChange: (e) => setCount(e.target.value),
							children: COUNTS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: n }, n))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-muted",
						children: ["Hitter", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: `${fieldClass} mt-1`,
							value: profile,
							onChange: (e) => setProfile(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "power",
									children: "Power"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "contact",
									children: "Contact"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "patient",
									children: "Patient"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "chase",
									children: "Free swinger"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "speed",
									children: "Speed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "cold",
									children: "Cold"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-muted",
						children: ["Runners", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: `${fieldClass} mt-1`,
							value: runners,
							onChange: (e) => setRunners(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "empty",
									children: "Empty"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "first",
									children: "First"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "scoring",
									children: "Scoring position"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "loaded",
									children: "Loaded"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-muted",
						children: ["Leverage", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: `${fieldClass} mt-1`,
							value: leverage,
							onChange: (e) => setLeverage(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "low",
									children: "Low"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "mid",
									children: "Medium"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "high",
									children: "High"
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-2",
				children: [
					0,
					1,
					2
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `min-h-11 rounded-lg px-3 font-display text-lg ${outs === n ? "bg-orange text-ink" : "border border-line text-muted"}`,
					onClick: () => setOuts(n),
					children: [n, " out"]
				}, n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "mb-1 font-display text-xs uppercase tracking-widest text-muted",
					children: "Arsenal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: ARSENAL_TAGS.map((tag) => {
						const on = arsenal.includes(tag);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `min-h-11 rounded-lg border px-3 font-display text-lg ${on ? "border-orange bg-orange-dim text-orange" : "border-line text-muted"}`,
							onClick: () => setArsenal(on ? arsenal.filter((t) => t !== tag) : [...arsenal, tag]),
							children: tag
						}, tag);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 flex min-h-11 items-center gap-2 text-sm text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: bearDown,
					onChange: (e) => setBearDown(e.target.checked)
				}), "Bear Down is available"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => setCall(callPitch({
						bats,
						throws,
						count,
						profile,
						runners,
						outs,
						leverage,
						arsenal,
						bearDown
					})),
					children: "Call the pitch"
				})
			}),
			call ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4 sm:grid-cols-[12rem_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-1",
					children: [
						1,
						2,
						3,
						4,
						5,
						6,
						7,
						8,
						9
					].map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `flex aspect-square items-center justify-center rounded-md border font-display text-lg ${lit(z, call, showBat) ? "border-orange bg-orange text-ink" : "border-line text-faint"}`,
						children: z
					}, z))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-center text-xs text-muted",
					children: ["Catcher view · ", showBat === "R" ? "RHB" : "LHB"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl uppercase leading-none text-orange",
						children: call.pitch
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-fg",
						children: call.loc
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: call.why
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 list-decimal pl-4 text-sm text-fg",
						children: call.sequence.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: s }, s))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-fg",
						children: call.running
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-orange",
						children: call.bear
					})
				] })]
			}) : null
		]
	})] });
}
function BreakdownDesk() {
	const { campaign: c, update } = useActive();
	const last = orderedGames(c.games).slice(-1)[0];
	const [opponent, setOpponent] = (0, import_react.useState)(last?.opponent || c.nextOpponent || "");
	const [rf, setRf] = (0, import_react.useState)(last?.runsFor ?? 0);
	const [ra, setRa] = (0, import_react.useState)(last?.runsAgainst ?? 0);
	const [result, setResult] = (0, import_react.useState)(last?.result ?? "W");
	const [starter, setStarter] = (0, import_react.useState)(last?.starter ?? "");
	const [innings, setInnings] = (0, import_react.useState)(last?.innings ?? "");
	const [moment, setMoment] = (0, import_react.useState)(last?.moment ?? "");
	const [how, setHow] = (0, import_react.useState)(last?.how ?? "played");
	const [preview, setPreview] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: c.team === "BAL" ? "Birdland Breakdown. Punchy, three or four beats, no headline voiceover. It writes from the facts you give it — your words, not a robot box score." : "A short recap in the same voice. It writes from the facts you type. Save the ones worth keeping." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Copy",
			title: "Write the night",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Opponent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: opponent,
								onChange: (e) => setOpponent(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Result",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: result,
								onChange: (e) => setResult(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "W",
									children: "Win"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "L",
									children: "Loss"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Runs for",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "number",
								value: rf,
								onChange: (e) => setRf(Number(e.target.value) || 0)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Runs against",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "number",
								value: ra,
								onChange: (e) => setRa(Number(e.target.value) || 0)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Starter",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: starter,
								onChange: (e) => setStarter(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Innings",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: innings,
								onChange: (e) => setInnings(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Key moment",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} mt-3 min-h-20`,
						value: moment,
						onChange: (e) => setMoment(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "How it was played",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: `${fieldClass} mt-3`,
						value: how,
						onChange: (e) => setHow(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "played",
								children: "Played it"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "moment",
								children: "Key moment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "simmed",
								children: "Simmed"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						disabled: !opponent.trim(),
						onClick: () => setPreview(writeRecap({
							team: c.team,
							teamName: c.teamName,
							opponent: opponent.trim(),
							runsFor: rf,
							runsAgainst: ra,
							result,
							starter,
							innings,
							moment,
							how
						})),
						children: "Generate recap"
					}), last ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "quiet",
						onClick: () => {
							setOpponent(last.opponent);
							setRf(last.runsFor);
							setRa(last.runsAgainst);
							setResult(last.result);
							setStarter(last.starter);
							setInnings(last.innings);
							setMoment(last.moment);
							setHow(last.how);
						},
						children: "Use last game"
					}) : null]
				}),
				preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-lg border border-line bg-surface-2 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl uppercase tracking-wide text-orange",
							children: preview.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-fg",
							children: preview.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								tone: "ghost",
								onClick: () => update((x) => ({
									...x,
									recaps: [{
										id: uid("rc"),
										created: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
										title: preview.title,
										body: preview.body
									}, ...x.recaps]
								})),
								children: "Save recap"
							})
						})
					]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Tape",
			title: "Saved",
			children: [c.recaps.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Nothing saved. Generate one after a night worth remembering." }) : null, c.recaps.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "border-t border-line py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-lg uppercase text-fg",
						children: [r.title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 font-sans text-xs normal-case text-muted",
							children: r.created
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-muted",
						children: r.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmBtn, {
						label: "Delete",
						onConfirm: () => update((x) => ({
							...x,
							recaps: x.recaps.filter((row) => row.id !== r.id)
						}))
					})
				]
			}, r.id))]
		})
	] });
}
function Clubhouse() {
	const { campaign: c, update } = useActive();
	const rec = displayRecord(c);
	const runs = runTotals(c);
	const pace = paceWins(rec.w, rec.gp);
	const py = pythagWins(runs.rf, runs.ra, rec.gp || c.games.length);
	const l10 = last10(c);
	const pay = payroll(c.players);
	const room = c.budget - pay;
	const nextArm = [...starterBoard(c)].sort((a, b) => (b.rest ?? 99) - (a.rest ?? 99))[0];
	const tired = penBoard(c).filter((p) => p.apps >= 2 && p.player);
	const pending = c.offers.filter((o) => o.status === "pending" || o.status === "rumor");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "The Show 26 franchise desk. Trades are not instant — offers sit, rumors lie, division rivals don’t help you, and contenders buy now while rebuilders buy years. Ratings here are your planning numbers. Match them to the attribute screen." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Pace",
					value: pace == null ? "—" : String(pace),
					hint: rec.gp ? `${rec.gp} games counted` : "Log a game or set a manual record"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Streak",
					value: streakLabel(c),
					hint: "From the game log"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Last 10",
					value: l10.n ? `${l10.w}–${l10.l}` : "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Run diff",
					value: c.games.length ? `${runs.rf - runs.ra > 0 ? "+" : ""}${runs.rf - runs.ra}` : "—",
					hint: c.games.length ? `${runs.rf} scored, ${runs.ra} allowed in the log` : "Logged games only"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Pythag",
					value: py == null ? "—" : String(py),
					hint: "162-game pace from logged runs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Room",
					value: money(room),
					hint: `${money(pay)} on the books of ${money(c.budget)}`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Front office",
			title: c.strategy === "rebuild" ? "Tear it down clean" : c.strategy === "retool" ? "Win without emptying the farm" : "October is the job",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Plan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: c.strategy,
							onChange: (e) => update((x) => ({
								...x,
								strategy: e.target.value
							})),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "contend",
									children: "Contend"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "retool",
									children: "Retool"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "rebuild",
									children: "Rebuild"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Difficulty",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: c.difficulty,
							onChange: (e) => update((x) => ({
								...x,
								difficulty: e.target.value
							})),
							children: [
								"Beginner",
								"Veteran",
								"All-Star",
								"Hall of Fame",
								"Legend"
							].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "How you play",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: c.participation,
							onChange: (e) => update((x) => ({
								...x,
								participation: e.target.value
							})),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Play every game" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Key moments" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Sim the grind" })
							]
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Memo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${fieldClass} mt-3 min-h-24`,
					value: c.memo,
					onChange: (e) => update((x) => ({
						...x,
						memo: e.target.value
					}))
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Next",
			title: c.nextOpponent ? `vs ${c.nextOpponent}` : "No series set",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-3 text-sm text-muted",
					children: [
						c.nextWhere === "home" ? "Home" : "Away",
						c.nextGames ? ` · ${c.nextGames} games` : "",
						nextArm ? ` · Ball to ${nextArm.player.name}` : "",
						nextArm?.rest != null ? ` (${nextArm.rest} days off the last logged start)` : ""
					]
				}),
				c.nextNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-fg",
					children: c.nextNote
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Opponent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: c.nextOpponent,
								onChange: (e) => update((x) => ({
									...x,
									nextOpponent: e.target.value
								}))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Site",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: c.nextWhere,
								onChange: (e) => update((x) => ({
									...x,
									nextWhere: e.target.value
								})),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "home",
									children: "Home"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "away",
									children: "Away"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Games",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "number",
								min: 1,
								max: 7,
								value: c.nextGames,
								onChange: (e) => update((x) => ({
									...x,
									nextGames: Number(e.target.value) || 1
								}))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Series note",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: c.nextNote,
								onChange: (e) => update((x) => ({
									...x,
									nextNote: e.target.value
								}))
							})
						})
					]
				}),
				tired.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-orange",
					children: [
						"Tired arms in the last three logged games: ",
						tired.map((t) => t.player.name).join(", "),
						". Give them the night."
					]
				}) : null,
				pending.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						pending.length,
						" offer",
						pending.length === 1 ? "" : "s",
						" still sitting in the trade hub. Don’t let them rot."
					]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			kicker: "Owner sheet",
			title: "Goals",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: c.goals.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-3 text-sm text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: g.done,
						onChange: () => update((x) => ({
							...x,
							goals: x.goals.map((item) => item.id === g.id ? {
								...item,
								done: !item.done
							} : item)
						}))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: g.done ? "text-muted line-through" : "",
						children: g.label
					})]
				}) }, g.id))
			})
		})
	] });
}
function LedgerDesk() {
	const { campaign: c, update } = useActive();
	const pay = payroll(c.players);
	const room = c.budget - pay;
	const rows = [...c.players].filter((p) => p.level === "MLB" || p.level === "IL").sort((a, b) => a.years - b.years || b.salary - a.salary);
	const extensions = c.players.filter((p) => p.age <= 26 && p.pot >= 80 && p.years <= 5 && p.years >= 2 && p.level !== "IL");
	const walk = rows.filter((p) => p.years <= 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "Lock the young stars before arbitration writes the check for you. A one-year rental is fine when you’re contending. It is a bad habit when you’re not." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Payroll",
					value: money(pay),
					hint: "MLB and IL"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Budget",
					value: money(c.budget),
					hint: "Your number, not the game’s"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Room",
					value: money(room),
					hint: room < 0 ? "You’re over the number you set." : "Left to spend"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			kicker: "Books",
			title: "Set the number",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm text-muted",
				children: ["Budget in millions", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: `${fieldClass} mt-1 max-w-40`,
					type: "number",
					value: c.budget,
					onChange: (e) => update((x) => ({
						...x,
						budget: Number(e.target.value) || 0
					}))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Extend",
			title: "Do it before the price jumps",
			children: [extensions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nobody fits the window: 26 or younger, 80-plus potential, two to five years left."
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: extensions.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-t border-line py-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg",
					children: p.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [
						" ",
						"· ",
						p.ovr,
						"/",
						p.pot,
						" · age ",
						p.age,
						" · ",
						p.years,
						" years · ",
						money(p.salary),
						p.untouchable ? " · already untouchable" : ""
					]
				})]
			}, p.id)) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Walk year",
			title: "Control runs out",
			children: [walk.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nobody is on a one-year deal."
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: walk.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-baseline justify-between gap-3 border-t border-line py-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg",
					children: p.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [
						p.pos,
						" · ",
						money(p.salary),
						p.arb ? " · arb" : ""
					]
				})]
			}, p.id)) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			kicker: "Sheet",
			title: "Everyone on the books",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "font-display text-xs uppercase tracking-widest text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-2 font-medium",
								children: "Player"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-2 font-medium",
								children: "Yrs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-2 font-medium",
								children: "AAV"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Tag"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 pr-2 text-fg",
								children: [p.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted",
									children: [
										p.pos,
										" · ",
										p.level
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-2 tabular-nums",
								children: p.years
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-2 tabular-nums",
								children: money(p.salary)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-xs text-muted",
								children: p.arb ? "Arb" : p.years <= 1 ? "Walk" : p.years >= 5 ? "Control" : "—"
							})
						]
					}, p.id)) })]
				})
			})
		})
	] });
}
var SPOTS = [
	"C",
	"1B",
	"2B",
	"3B",
	"SS",
	"LF",
	"CF",
	"RF",
	"DH"
];
function move(list, index, dir) {
	const next = list.map((s) => ({ ...s }));
	const j = index + dir;
	if (j < 0 || j >= next.length) return list;
	const tmp = next[index];
	next[index] = next[j];
	next[j] = tmp;
	return next;
}
function setHitter(list, index, playerId) {
	const next = list.map((s) => ({ ...s }));
	const other = next.findIndex((s, i) => s.playerId === playerId && i !== index);
	if (other >= 0) next[other].playerId = next[index].playerId;
	next[index].playerId = playerId;
	return next;
}
function Card({ title, slots, onChange }) {
	const { campaign: c } = useActive();
	const pool = c.players.filter((p) => p.level === "MLB" && !isPitcher(p));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		kicker: "Card",
		title,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex flex-col gap-2",
			children: slots.map((slot, i) => {
				const p = findPlayer(c, slot.playerId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[2rem_1fr_5rem] items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-2xl text-orange tabular-nums",
							children: i + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: slot.playerId,
							onChange: (e) => onChange(setHitter(slots, i, e.target.value)),
							children: [pool.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: h.id,
								children: [
									h.name,
									" · ",
									h.bats,
									" · ",
									h.ovr
								]
							}, h.id)), p && !pool.some((h) => h.id === p.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: slot.pos,
							onChange: (e) => onChange(slots.map((s, idx) => idx === i ? {
								...s,
								pos: e.target.value
							} : s)),
							children: SPOTS.map((pos) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: pos }, pos))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "col-span-3 flex gap-2 pl-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 px-2 text-sm text-muted",
									onClick: () => onChange(move(slots, i, -1)),
									children: "Up"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 px-2 text-sm text-muted",
									onClick: () => onChange(move(slots, i, 1)),
									children: "Down"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "self-center text-xs text-faint",
									children: p ? `${p.pos}${p.secondary ? ` / ${p.secondary}` : ""}` : "Open spot"
								})
							]
						})
					]
				}, `${title}-${i}`);
			})
		}), slots.length < 9 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-3 min-h-11 font-display text-lg text-orange",
			onClick: () => {
				const used = new Set(slots.map((s) => s.playerId));
				const next = mlbHitters(c).find((p) => !used.has(p.id));
				if (!next) return;
				onChange([...slots, {
					playerId: next.id,
					pos: SPOTS[slots.length] ?? "DH"
				}]);
			},
			children: "Add a spot"
		}) : null]
	});
}
function LineupDesk() {
	const { campaign: c, update } = useActive();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "The Show 26 stopped auto-stacking pure speed in the 1-hole. The two-hole is a contact, on-base bat. Build two cards — right-handed pitching and left-handed pitching — and use the secondary positions so the bench isn’t decorative." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-0 lg:grid-cols-2 lg:gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			title: "Versus RHP",
			slots: c.lineupR,
			onChange: (lineupR) => update((x) => ({
				...x,
				lineupR
			}))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			title: "Versus LHP",
			slots: c.lineupL,
			onChange: (lineupL) => update((x) => ({
				...x,
				lineupL
			}))
		})]
	})] });
}
function today() {
	const d = /* @__PURE__ */ new Date();
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${m}-${day}`;
}
function blankGame(opponent = "") {
	return {
		id: uid("g"),
		date: today(),
		opponent,
		home: true,
		result: "W",
		runsFor: 0,
		runsAgainst: 0,
		starter: "",
		oppStarter: "",
		innings: "",
		pitches: "",
		relievers: "",
		moment: "",
		notes: "",
		how: "played"
	};
}
function LogDesk() {
	const { campaign: c, update } = useActive();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)(() => blankGame(c.nextOpponent));
	const games = orderedGames(c.games).slice().reverse();
	const pitchers = c.players.filter((p) => p.pos === "SP" || p.pos === "RP" || p.role === "rotation" || p.role === "bullpen");
	const pen = c.pen.map((s) => c.players.find((p) => p.id === s.playerId)).filter((p) => Boolean(p));
	function save() {
		if (!draft.opponent.trim()) return;
		update((x) => {
			const exists = x.games.some((g) => g.id === draft.id);
			return {
				...x,
				games: exists ? x.games.map((g) => g.id === draft.id ? draft : g) : [...x.games, draft]
			};
		});
		setEditing(null);
		setDraft(blankGame(c.nextOpponent));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		c.participation === "Key moments" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "Worth taking the controller: a one-run game from the 7th on, an ace against an ace, a division rival, and any debut you actually care about. Sim the rest and log the line so the rotation still turns." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "Log the games you want the desk to remember. Rest, bullpen fatigue, pace, and recaps all read this list." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Box",
			title: editing ? "Edit the line" : "Log a game",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "date",
								value: draft.date,
								onChange: (e) => setDraft({
									...draft,
									date: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Opponent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: draft.opponent,
								onChange: (e) => setDraft({
									...draft,
									opponent: e.target.value
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Pick a club"
								}), otherClubs(c.team).map((club) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: club.name }, club.abbr))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Result",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: draft.result,
								onChange: (e) => setDraft({
									...draft,
									result: e.target.value
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "W",
									children: "Win"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "L",
									children: "Loss"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Site",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: draft.home ? "home" : "away",
								onChange: (e) => setDraft({
									...draft,
									home: e.target.value === "home"
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "home",
									children: "Home"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "away",
									children: "Away"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Runs for",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "number",
								value: draft.runsFor,
								onChange: (e) => setDraft({
									...draft,
									runsFor: Number(e.target.value) || 0
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Runs against",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "number",
								value: draft.runsAgainst,
								onChange: (e) => setDraft({
									...draft,
									runsAgainst: Number(e.target.value) || 0
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Our starter",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: draft.starter,
								onChange: (e) => setDraft({
									...draft,
									starter: e.target.value
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "—"
								}), pitchers.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: p.name }, p.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Their starter",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: draft.oppStarter,
								onChange: (e) => setDraft({
									...draft,
									oppStarter: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Innings",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: draft.innings,
								placeholder: "6.0",
								onChange: (e) => setDraft({
									...draft,
									innings: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Pitches",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: draft.pitches,
								placeholder: "94",
								onChange: (e) => setDraft({
									...draft,
									pitches: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "How",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: draft.how,
								onChange: (e) => setDraft({
									...draft,
									how: e.target.value
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "played",
										children: "Played it"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "moment",
										children: "Key moment"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "simmed",
										children: "Simmed"
									})
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-1 font-display text-xs uppercase tracking-widest text-muted",
						children: "Bullpen used"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: pen.map((p) => {
							const names = draft.relievers.split(",").map((s) => s.trim()).filter(Boolean);
							const on = names.some((n) => n.toLowerCase() === p.name.toLowerCase());
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `min-h-11 rounded-lg border px-3 text-sm ${on ? "border-orange bg-orange-dim text-orange" : "border-line text-muted"}`,
								onClick: () => {
									const next = on ? names.filter((n) => n.toLowerCase() !== p.name.toLowerCase()) : [...names, p.name];
									setDraft({
										...draft,
										relievers: next.join(", ")
									});
								},
								children: p.name
							}, p.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Key moment",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: draft.moment,
							placeholder: "Rutschman, 3-run shot, 6th",
							onChange: (e) => setDraft({
								...draft,
								moment: e.target.value
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${fieldClass} min-h-20`,
							value: draft.notes,
							onChange: (e) => setDraft({
								...draft,
								notes: e.target.value
							})
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: save,
						disabled: !draft.opponent,
						children: editing ? "Save changes" : "Add to the log"
					}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "quiet",
						onClick: () => {
							setEditing(null);
							setDraft(blankGame(c.nextOpponent));
						},
						children: "Cancel"
					}) : null]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			kicker: "Book",
			title: "Results",
			children: games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No games yet. The record on the scorebug stays 0–0 until you log one, unless you set it by hand on the season desk." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: games.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "border-t border-line py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `flex size-8 shrink-0 items-center justify-center rounded-md font-display text-lg ${g.result === "W" ? "bg-orange-dim text-orange" : "bg-surface-2 text-muted"}`,
							children: g.result
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-xl uppercase leading-none tracking-wide text-fg",
									children: [
										g.home ? "vs" : "at",
										" ",
										g.opponent,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 font-sans text-xs normal-case tracking-normal text-muted",
											children: g.date
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										g.runsFor,
										"–",
										g.runsAgainst,
										g.starter ? ` · ${g.starter}` : "",
										g.innings ? ` · ${g.innings} IP` : "",
										g.how === "simmed" ? " · sim" : g.how === "moment" ? " · moment" : ""
									]
								}),
								g.moment ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-fg",
									children: g.moment
								}) : null,
								g.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: g.notes
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 flex-col gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 px-2 text-sm text-orange",
								onClick: () => {
									setEditing(g.id);
									setDraft(g);
								},
								children: "Edit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmBtn, {
								label: "Delete",
								onConfirm: () => update((x) => ({
									...x,
									games: x.games.filter((row) => row.id !== g.id)
								}))
							})]
						})
					]
				})
			}, g.id)) })
		})
	] });
}
function PipelineDesk() {
	const { campaign: c, update } = useActive();
	const [note, setNote] = (0, import_react.useState)("");
	const [focus, setFocus] = (0, import_react.useState)(DEV_FOCUSES[0]);
	const [who, setWho] = (0, import_react.useState)("");
	const [round, setRound] = (0, import_react.useState)("1");
	const [pickName, setPickName] = (0, import_react.useState)("");
	const [pickPos, setPickPos] = (0, import_react.useState)("SS");
	const [pickNote, setPickNote] = (0, import_react.useState)("");
	const kids = c.players.filter((p) => p.role === "prospect" || p.level === "AAA" || p.level === "AA" || p.pot - p.ovr >= 8).sort((a, b) => b.pot - a.pot || a.age - b.age);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "Development is the quiet half of a franchise. Log what you’re training, not just the overall. The draft board is a scratch pad for the pool in your save — it does not sim the draft." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Farm",
			title: "Who’s coming",
			children: [kids.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No prospects tagged. Mark a player’s role as prospect, or give him a big gap between overall and potential." }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: kids.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-t border-line py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl uppercase leading-none text-fg",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-xl text-orange tabular-nums",
							children: [p.ovr, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: ["/", p.pot]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							p.pos,
							" · age ",
							p.age,
							" · ",
							p.level,
							" · ",
							p.years,
							" years · focus ",
							p.devFocus
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-2 block text-xs text-muted",
						children: ["Training focus", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: `${fieldClass} mt-1`,
							value: p.devFocus,
							onChange: (e) => update((x) => ({
								...x,
								players: x.players.map((row) => row.id === p.id ? {
									...row,
									devFocus: e.target.value
								} : row)
							})),
							children: DEV_FOCUSES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))
						})]
					}),
					p.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-fg",
						children: p.notes
					}) : null
				]
			}, p.id)) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Notes",
			title: "Development log",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Player",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: who,
							onChange: (e) => setWho(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Pick"
							}), c.players.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Focus",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: focus,
							onChange: (e) => setFocus(e.target.value),
							children: DEV_FOCUSES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "What changed",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} mt-3 min-h-20`,
						value: note,
						onChange: (e) => setNote(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						disabled: !who || !note.trim(),
						onClick: () => {
							const player = c.players.find((p) => p.id === who);
							update((x) => ({
								...x,
								devNotes: [{
									id: uid("d"),
									playerId: who,
									date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
									focus,
									note: note.trim()
								}, ...x.devNotes],
								players: player ? x.players.map((p) => p.id === who ? {
									...p,
									devFocus: focus
								} : p) : x.players
							}));
							setNote("");
						},
						children: "File the note"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4",
					children: [c.devNotes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No development notes yet." }) : null, c.devNotes.map((n) => {
						const p = c.players.find((row) => row.id === n.playerId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-t border-line py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-fg",
								children: [
									p?.name ?? "Released",
									" · ",
									n.focus,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 text-xs text-muted",
										children: n.date
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: n.note
							})]
						}, n.id);
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "July",
			title: "Draft board",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Round",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: round,
								onChange: (e) => setRound(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: pickName,
								onChange: (e) => setPickName(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Pos",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: pickPos,
								onChange: (e) => setPickPos(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Note",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: pickNote,
								onChange: (e) => setPickNote(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						disabled: !pickName.trim(),
						onClick: () => {
							update((x) => ({
								...x,
								draft: [...x.draft, {
									id: uid("dr"),
									round,
									name: pickName.trim(),
									pos: pickPos,
									note: pickNote.trim()
								}]
							}));
							setPickName("");
							setPickNote("");
						},
						children: "Add to the board"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3",
					children: [c.draft.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Board is empty. Park the names you’re circling before the draft opens." }) : null, c.draft.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 border-t border-line py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-fg",
							children: [
								"Rd ",
								d.round,
								" · ",
								d.name,
								" · ",
								d.pos
							]
						}), d.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: d.note
						}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmBtn, {
							label: "Cut",
							onConfirm: () => update((x) => ({
								...x,
								draft: x.draft.filter((row) => row.id !== d.id)
							}))
						})]
					}, d.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "International note",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} mt-3 min-h-20`,
						value: c.intlNote,
						onChange: (e) => update((x) => ({
							...x,
							intlNote: e.target.value
						}))
					})
				})
			]
		})
	] });
}
var POS = [
	"C",
	"1B",
	"2B",
	"3B",
	"SS",
	"LF",
	"CF",
	"RF",
	"OF",
	"DH",
	"UTIL",
	"IF",
	"SP",
	"RP"
];
function fresh() {
	return {
		id: uid("p"),
		name: "New player",
		pos: "UTIL",
		secondary: "",
		bats: "R",
		throws: "R",
		age: 25,
		ovr: 70,
		pot: 75,
		level: "MLB",
		role: "bench",
		salary: 1,
		years: 3,
		arb: false,
		untouchable: false,
		devFocus: "Hold",
		arsenal: "",
		notes: ""
	};
}
function RosterDesk() {
	const { campaign: c, update } = useActive();
	const [q, setQ] = (0, import_react.useState)("");
	const [band, setBand] = (0, import_react.useState)("all");
	const [sel, setSel] = (0, import_react.useState)(c.players[0]?.id ?? null);
	const rows = (0, import_react.useMemo)(() => {
		return c.players.filter((p) => {
			if (band === "mlb") return p.level === "MLB";
			if (band === "il") return p.level === "IL";
			if (band === "farm") return p.level === "AAA" || p.level === "AA" || p.role === "prospect";
			if (band === "arms") return p.pos === "SP" || p.pos === "RP";
			return true;
		}).filter((p) => p.name.toLowerCase().includes(q.trim().toLowerCase())).sort((a, b) => b.ovr - a.ovr);
	}, [
		c.players,
		q,
		band
	]);
	const player = c.players.find((p) => p.id === sel) ?? null;
	function patch(id, partial) {
		update((x) => ({
			...x,
			players: x.players.map((p) => p.id === id ? {
				...p,
				...partial
			} : p)
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		kicker: "26-man",
		title: "Roster",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			onClick: () => {
				const p = fresh();
				update((x) => ({
					...x,
					players: [...x.players, p]
				}));
				setSel(p.id);
			},
			children: "Add"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: "Overalls are planning numbers for your save, not official SDS attributes. Edit them to what you see on the player card."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: fieldClass,
				placeholder: "Search the roster",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex gap-2 overflow-x-auto",
				children: [
					["all", "All"],
					["mlb", "MLB"],
					["il", "IL"],
					["farm", "Farm"],
					["arms", "Arms"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `shrink-0 rounded-lg px-3 py-2 font-display text-lg ${band === id ? "bg-orange text-ink" : "text-muted"}`,
					onClick: () => setBand(id),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3",
				children: rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSel(p.id),
					className: `flex w-full min-h-11 items-center gap-3 border-t border-line py-2 text-left ${sel === p.id ? "text-orange" : "text-fg"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-10 font-display text-xl tabular-nums",
							children: p.ovr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate",
								children: p.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted",
								children: [
									p.pos,
									p.secondary ? `/${p.secondary}` : "",
									" · ",
									p.bats,
									"/",
									p.throws,
									" · ",
									p.level,
									p.untouchable ? " · untouchable" : ""
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: [p.years, "y"]
						})
					]
				}) }, p.id))
			})
		]
	}), player ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		kicker: "Card",
		title: player.name,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: player.name,
							onChange: (e) => patch(player.id, { name: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Position",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: player.pos,
							onChange: (e) => patch(player.id, { pos: e.target.value }),
							children: POS.map((pos) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: pos }, pos))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: player.secondary,
							onChange: (e) => patch(player.id, { secondary: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bats",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: player.bats,
							onChange: (e) => patch(player.id, { bats: e.target.value }),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "L",
									children: "Left"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "R",
									children: "Right"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "S",
									children: "Switch"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Throws",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: player.throws,
							onChange: (e) => patch(player.id, { throws: e.target.value }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "L",
								children: "Left"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "R",
								children: "Right"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Age",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "number",
							value: player.age,
							onChange: (e) => patch(player.id, { age: Number(e.target.value) || 0 })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Overall",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "number",
							value: player.ovr,
							onChange: (e) => patch(player.id, { ovr: Number(e.target.value) || 0 })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Potential",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "number",
							value: player.pot,
							onChange: (e) => patch(player.id, { pot: Number(e.target.value) || 0 })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Level",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: player.level,
							onChange: (e) => patch(player.id, { level: e.target.value }),
							children: [
								"MLB",
								"IL",
								"AAA",
								"AA"
							].map((lv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: lv }, lv))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Role",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: player.role,
							onChange: (e) => patch(player.id, { role: e.target.value }),
							children: [
								"lineup",
								"bench",
								"rotation",
								"bullpen",
								"prospect",
								"il"
							].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: r }, r))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Salary ($M)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "number",
							step: "0.1",
							value: player.salary,
							onChange: (e) => patch(player.id, { salary: Number(e.target.value) || 0 })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Years of control",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "number",
							value: player.years,
							onChange: (e) => patch(player.id, { years: Number(e.target.value) || 0 })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Arsenal tags",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: player.arsenal,
							placeholder: "FB, SL, CH",
							onChange: (e) => patch(player.id, { arsenal: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Dev focus",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: player.devFocus,
							onChange: (e) => patch(player.id, { devFocus: e.target.value })
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-2 text-sm text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: player.arb,
						onChange: (e) => patch(player.id, { arb: e.target.checked })
					}), "Arbitration year"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-2 text-sm text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: player.untouchable,
						onChange: (e) => patch(player.id, { untouchable: e.target.checked })
					}), "Untouchable"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${fieldClass} mt-3 min-h-24`,
					value: player.notes,
					onChange: (e) => patch(player.id, { notes: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-muted",
				children: [
					money(player.salary),
					" · ",
					player.years,
					" year",
					player.years === 1 ? "" : "s",
					" of control",
					player.arb ? " · arb" : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmBtn, {
					label: "Remove player",
					onConfirm: () => update((x) => ({
						...x,
						players: x.players.filter((p) => p.id !== player.id),
						lineupR: x.lineupR.filter((s) => s.playerId !== player.id),
						lineupL: x.lineupL.filter((s) => s.playerId !== player.id),
						rotation: x.rotation.filter((id) => id !== player.id),
						pen: x.pen.filter((s) => s.playerId !== player.id)
					}))
				})
			})
		]
	}) : null] });
}
var blank = () => ({
	id: uid("s"),
	team: "",
	starter: "",
	threats: "",
	weak: "",
	bullpen: "",
	attack: ""
});
function ScoutDesk() {
	const { campaign: c, update } = useActive();
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(blank);
	function patch(id, partial) {
		update((x) => ({
			...x,
			reports: x.reports.map((r) => r.id === id ? {
				...r,
				...partial
			} : r)
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "These are attack cards, not a stats dump. Write what the pitcher actually throws, who beats you, and which inning the bullpen gets thin. The Yankees, Rays, and Red Sox cards came in from the ACE8 scouting notes — edit them if your save has moved on." }),
		c.reports.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Report",
			title: r.team || "Untitled",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Club",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: r.team,
							onChange: (e) => patch(r.id, { team: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Starter",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${fieldClass} min-h-20`,
							value: r.starter,
							onChange: (e) => patch(r.id, { starter: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Top threats",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${fieldClass} min-h-20`,
							value: r.threats,
							onChange: (e) => patch(r.id, { threats: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Where they’re soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${fieldClass} min-h-20`,
							value: r.weak,
							onChange: (e) => patch(r.id, { weak: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bullpen",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${fieldClass} min-h-20`,
							value: r.bullpen,
							onChange: (e) => patch(r.id, { bullpen: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Attack plan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${fieldClass} min-h-20`,
							value: r.attack,
							onChange: (e) => patch(r.id, { attack: e.target.value })
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmBtn, {
					label: "Delete report",
					onConfirm: () => update((x) => ({
						...x,
						reports: x.reports.filter((row) => row.id !== r.id)
					}))
				})
			})]
		}, r.id)),
		adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "New",
			title: "Blank card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Club",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: draft.team,
					onChange: (e) => setDraft({
						...draft,
						team: e.target.value
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					disabled: !draft.team.trim(),
					onClick: () => {
						update((x) => ({
							...x,
							reports: [...x.reports, draft]
						}));
						setDraft(blank());
						setAdding(false);
					},
					children: "Save card"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					tone: "quiet",
					onClick: () => setAdding(false),
					children: "Cancel"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			onClick: () => setAdding(true),
			children: "New scouting card"
		})
	] });
}
function SeasonDesk() {
	const { campaign: c, update } = useActive();
	const rec = displayRecord(c);
	const logged = loggedRecord(c);
	const sorted = [...c.standings.map((s) => s.abbr === c.team ? {
		...s,
		w: rec.w,
		l: rec.l
	} : s)].sort((a, b) => {
		const pa = a.w + a.l ? a.w / (a.w + a.l) : 0;
		return (b.w + b.l ? b.w / (b.w + b.l) : 0) - pa || b.w - a.w;
	});
	const leader = sorted[0];
	const months = monthSplits(c);
	const max = Math.max(1, ...months.map((m) => Math.max(m.w, m.l)));
	const recent = orderedGames(c.games).slice(-8).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "Your row follows the game log unless you flip manual record — useful when you sim a month and only play the moments. Rival rows are yours to update from the standings screen in the game." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: c.teamName,
			title: "Division",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mb-3 flex min-h-11 items-center gap-2 text-sm text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: c.manualRecord,
						onChange: (e) => update((x) => ({
							...x,
							manualRecord: e.target.checked,
							manualW: logged.w,
							manualL: logged.l
						}))
					}), "I’m not logging every sim. Use a manual record."]
				}),
				c.manualRecord ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-muted",
						children: ["Wins", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "mt-1 block w-24 rounded-lg border border-line bg-surface-2 px-3 py-2 text-base text-fg",
							type: "number",
							value: c.manualW,
							onChange: (e) => update((x) => ({
								...x,
								manualW: Number(e.target.value) || 0
							}))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-muted",
						children: ["Losses", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "mt-1 block w-24 rounded-lg border border-line bg-surface-2 px-3 py-2 text-base text-fg",
							type: "number",
							value: c.manualL,
							onChange: (e) => update((x) => ({
								...x,
								manualL: Number(e.target.value) || 0
							}))
						})]
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "font-display text-xs uppercase tracking-widest text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-2 font-medium",
									children: "Club"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-2 font-medium",
									children: "W"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-2 font-medium",
									children: "L"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: "GB"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: sorted.map((row) => {
							const gb = leader ? (leader.w - row.w + row.l - leader.l) / 2 : 0;
							const mine = row.abbr === c.team;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: `py-2 pr-2 ${mine ? "text-orange" : "text-fg"}`,
										children: row.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 pr-2 tabular-nums",
										children: mine && !c.manualRecord ? row.w : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: "w-16 rounded-md border border-line bg-surface-2 px-2 py-1 text-base text-fg",
											type: "number",
											value: mine ? c.manualW : row.w,
											onChange: (e) => {
												const w = Number(e.target.value) || 0;
												if (mine) update((x) => ({
													...x,
													manualW: w,
													manualRecord: true
												}));
												else update((x) => ({
													...x,
													standings: x.standings.map((s) => s.abbr === row.abbr ? {
														...s,
														w
													} : s)
												}));
											}
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 pr-2 tabular-nums",
										children: mine && !c.manualRecord ? row.l : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: "w-16 rounded-md border border-line bg-surface-2 px-2 py-1 text-base text-fg",
											type: "number",
											value: mine ? c.manualL : row.l,
											onChange: (e) => {
												const l = Number(e.target.value) || 0;
												if (mine) update((x) => ({
													...x,
													manualL: l,
													manualRecord: true
												}));
												else update((x) => ({
													...x,
													standings: x.standings.map((s) => s.abbr === row.abbr ? {
														...s,
														l
													} : s)
												}));
											}
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 tabular-nums text-muted",
										children: gb <= 0 ? "—" : gb.toFixed(1)
									})
								]
							}, row.abbr);
						}) })]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Logged",
			title: "Month by month",
			children: [months.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No dated games yet. The bars show up once the log has dates on it."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-36 items-end gap-2",
				children: months.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-full min-w-0 flex-1 flex-col justify-end",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-full items-end gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-1/2 rounded-sm bg-orange",
								style: { height: `${m.w / max * 100}%` }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-1/2 rounded-sm bg-line",
								style: { height: `${Math.max(4, m.l / max * 100)}%` }
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-center text-xs text-muted",
							children: m.month.slice(5) || m.month
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-center text-xs tabular-nums text-fg",
							children: [
								m.w,
								"–",
								m.l
							]
						})
					]
				}, m.month))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: "Orange is wins. The dull bar is losses."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			kicker: "Recent",
			title: "From the log",
			children: recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nothing logged. The game log is where results live."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: recent.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-baseline justify-between gap-3 border-t border-line py-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: g.result === "W" ? "font-display text-lg text-orange" : "font-display text-lg text-muted",
						children: g.result
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1 truncate text-fg",
						children: [
							g.home ? "vs" : "at",
							" ",
							g.opponent
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-muted",
						children: [
							g.runsFor,
							"–",
							g.runsAgainst
						]
					})
				]
			}, g.id)) })
		})
	] });
}
function emptyOffer(partner = "") {
	return {
		id: uid("o"),
		partner,
		status: "pending",
		ourIds: [
			"",
			"",
			"",
			""
		],
		theirNames: [
			"",
			"",
			"",
			""
		],
		theirControl: "mid",
		partnerStance: "contend",
		sameDivision: false,
		market: "mid",
		surplus: false,
		days: 0,
		note: ""
	};
}
function OfferForm({ offer, onChange }) {
	const { campaign: c } = useActive();
	const fit = tradeFit(c, {
		...offer,
		ourIds: offer.ourIds.filter(Boolean)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Partner",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: offer.partner,
						onChange: (e) => onChange({
							...offer,
							partner: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Pick"
						}), otherClubs(c.team).map((club) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: club.name }, club.abbr))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: offer.status,
						onChange: (e) => onChange({
							...offer,
							status: e.target.value
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "rumor",
								children: "Rumor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pending",
								children: "Pending"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "accepted",
								children: "Accepted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "rejected",
								children: "Rejected"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pulled",
								children: "Pulled"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Their stance",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: offer.partnerStance,
						onChange: (e) => onChange({
							...offer,
							partnerStance: e.target.value
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "contend",
								children: "Contending"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "retool",
								children: "Retooling"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "rebuild",
								children: "Rebuilding"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Control you’re asking for",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: offer.theirControl,
						onChange: (e) => onChange({
							...offer,
							theirControl: e.target.value
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "rental",
								children: "Rental"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "mid",
								children: "2–3 years"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "control",
								children: "4+ years"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Market",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: offer.market,
						onChange: (e) => onChange({
							...offer,
							market: e.target.value
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "small",
								children: "Small"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "mid",
								children: "Mid"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "large",
								children: "Large"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Days waiting",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						type: "number",
						min: 0,
						value: offer.days,
						onChange: (e) => onChange({
							...offer,
							days: Number(e.target.value) || 0
						})
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: offer.sameDivision,
					onChange: (e) => onChange({
						...offer,
						sameDivision: e.target.checked
					})
				}), "Division rival"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: offer.surplus,
					onChange: (e) => onChange({
						...offer,
						surplus: e.target.checked
					})
				}), "They have a surplus there"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 font-display text-xs uppercase tracking-widest text-muted",
				children: "We send (up to 4)"
			}), offer.ourIds.map((id, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: `${fieldClass} mb-2`,
				value: id,
				onChange: (e) => onChange({
					...offer,
					ourIds: offer.ourIds.map((v, idx) => idx === i ? e.target.value : v)
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "—"
				}), c.players.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: p.id,
					children: [
						p.untouchable ? "UNT · " : "",
						p.name,
						" · ",
						p.ovr,
						"/",
						p.pot
					]
				}, p.id))]
			}, i))] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 font-display text-xs uppercase tracking-widest text-muted",
				children: "We get (up to 4)"
			}), offer.theirNames.map((name, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: `${fieldClass} mb-2`,
				value: name,
				placeholder: "Their player",
				onChange: (e) => onChange({
					...offer,
					theirNames: offer.theirNames.map((v, idx) => idx === i ? e.target.value : v)
				})
			}, i))] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Your read",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: `${fieldClass} mt-3 min-h-16`,
				value: offer.note,
				onChange: (e) => onChange({
					...offer,
					note: e.target.value
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-lg border border-orange bg-orange-dim p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl uppercase leading-none text-orange",
					children: fit.verdict
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-display text-xl tabular-nums text-fg",
					children: [fit.score, " fit"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 list-disc pl-4 text-sm text-fg",
					children: fit.reasons.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: r }, r))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "Companion logic, not the SDS engine. It prices the factors The Show 26 actually uses."
				})
			]
		})
	] });
}
function TradeDesk() {
	const { campaign: c, update } = useActive();
	const [draft, setDraft] = (0, import_react.useState)(() => emptyOffer());
	const [rumor, setRumor] = (0, import_react.useState)("");
	const [trust, setTrust] = (0, import_react.useState)("smoke");
	const blocks = c.players.filter((p) => p.untouchable);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, { children: "Trade Hub rules in The Show 26: no instant yes, up to four players a side, untouchables barely move, division rivals lowball you, small markets fade big salaries, and a contender will not hand you six years of a star for a rental. Rumors can be noise. File the offer, then advance the days." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			kicker: "Blocked",
			title: "Untouchables",
			children: blocks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Nobody is blocked. Mark the two or three you will not move — a long list makes the tag meaningless." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-2",
				children: blocks.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "min-h-11 rounded-lg border border-orange px-3 text-sm text-orange",
					onClick: () => update((x) => ({
						...x,
						players: x.players.map((row) => row.id === p.id ? {
							...row,
							untouchable: false
						} : row)
					})),
					children: [p.name, " · release"]
				}) }, p.id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "New",
			title: "Build an offer",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfferForm, {
				offer: draft,
				onChange: setDraft
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					disabled: !draft.partner || !draft.ourIds.some(Boolean) || !draft.theirNames.some((n) => n.trim()),
					onClick: () => {
						update((x) => ({
							...x,
							offers: [{
								...draft,
								ourIds: draft.ourIds.filter(Boolean)
							}, ...x.offers]
						}));
						setDraft(emptyOffer());
					},
					children: "File the offer"
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Wire",
			title: "Rumors",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-[1fr_8rem]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: rumor,
						placeholder: "They’re listening on a starter",
						onChange: (e) => setRumor(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: trust,
						onChange: (e) => setTrust(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "smoke",
								children: "Smoke"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "likely",
								children: "Likely"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "noise",
								children: "Noise"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						disabled: !rumor.trim(),
						onClick: () => {
							update((x) => ({
								...x,
								rumors: [{
									id: uid("r"),
									text: rumor.trim(),
									trust
								}, ...x.rumors]
							}));
							setRumor("");
						},
						children: "Post rumor"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3",
					children: c.rumors.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 border-t border-line py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display uppercase tracking-wide text-orange",
								children: r.trust
							}),
							" · ",
							r.text
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmBtn, {
							label: "Drop",
							onConfirm: () => update((x) => ({
								...x,
								rumors: x.rumors.filter((row) => row.id !== r.id)
							}))
						})]
					}, r.id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Book",
			title: "Offers",
			children: [c.offers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Nothing filed. Build one above when you’re ready to wait on an answer." }) : null, c.offers.map((offer) => {
				const ours = offer.ourIds.map((id) => c.players.find((p) => p.id === id)?.name ?? "Gone").join(", ");
				const theirs = offer.theirNames.filter(Boolean).join(", ");
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "mb-4 border-t border-line pt-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-xl uppercase text-fg",
							children: [
								offer.partner,
								" · ",
								offer.status,
								" · day ",
								offer.days
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Send ",
								ours || "—",
								" · get ",
								theirs || "—"
							]
						}),
						offer.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-fg",
							children: offer.note
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									tone: "quiet",
									onClick: () => update((x) => ({
										...x,
										offers: x.offers.map((o) => o.id === offer.id ? {
											...o,
											days: o.days + 1
										} : o)
									})),
									children: "Advance a day"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									tone: "ghost",
									onClick: () => update((x) => applyTrade(x, offer)),
									disabled: !offer.theirNames.some((n) => n.trim()) || !offer.ourIds.length,
									children: "They said yes — apply"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmBtn, {
									label: "Pull",
									onConfirm: () => update((x) => ({
										...x,
										offers: x.offers.filter((o) => o.id !== offer.id)
									}))
								})
							]
						})
					]
				}, offer.id);
			})]
		})
	] });
}
var ICONS = {
	clubhouse: LayoutDashboard,
	season: CalendarRange,
	log: NotebookPen,
	lineups: Rows3,
	arms: CircleDot,
	roster: Users,
	pipeline: GitBranch,
	trades: ArrowLeftRight,
	scout: Binoculars,
	battery: Crosshair,
	ledger: Wallet,
	breakdown: Mic
};
function Opening() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col justify-between px-5 py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm uppercase tracking-widest text-orange",
				children: "ACE8 Sports · MLB The Show 26"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 max-w-xs font-display text-5xl uppercase leading-none text-fg",
				children: "Franchise Companion"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Opening the clubhouse…"
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-6xl leading-none text-orange tabular-nums",
			children: "0–0"
		})]
	});
}
function Shell() {
	const [desk, setDesk] = (0, import_react.useState)("clubhouse");
	const [openNew, setOpenNew] = (0, import_react.useState)(false);
	const campaigns = useFranchise((s) => s.campaigns);
	const activeId = useFranchise((s) => s.activeId);
	const setActive = useFranchise((s) => s.setActive);
	const campaign = campaigns.find((c) => c.id === activeId) ?? campaigns[0];
	const rec = campaign ? displayRecord(campaign) : {
		w: 0,
		l: 0
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen md:flex",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "sticky top-0 z-30 hidden h-screen w-52 shrink-0 flex-col overflow-y-auto border-r border-line bg-bg md:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 py-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs uppercase tracking-widest text-orange",
					children: "ACE8 · The Show 26"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl uppercase leading-none text-fg",
					children: "Franchise Companion"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex flex-col gap-0.5 px-2 pb-6",
				children: DESKS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
					id: d.id,
					label: d.label,
					active: desk === d.id,
					onClick: () => setDesk(d.id)
				}, d.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-bg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xs uppercase tracking-widest text-orange md:hidden",
								children: "ACE8 · The Show 26"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "sr-only",
										htmlFor: "camp",
										children: "Campaign"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: "camp",
										className: `${fieldClass} min-w-0 flex-1`,
										value: campaign?.id ?? "",
										onChange: (e) => setActive(e.target.value),
										children: campaigns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: c.id,
											children: c.name
										}, c.id))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex min-h-11 shrink-0 items-center font-display text-lg tracking-wide text-orange",
										onClick: () => setOpenNew((v) => !v),
										children: openNew ? "Close" : "New"
									})
								]
							}),
							campaign ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 truncate text-sm text-muted",
								children: [
									campaign.teamName,
									" · ",
									campaign.season,
									" · ",
									campaign.strategy
								]
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "shrink-0 rounded-lg border border-line bg-surface-2 px-3 py-1.5 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-3xl leading-none tracking-wide text-orange tabular-nums",
							children: [
								rec.w,
								"–",
								rec.l
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xs uppercase tracking-widest text-muted",
							children: "Record"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 overflow-x-auto px-3 pb-2 md:hidden",
					children: DESKS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setDesk(d.id),
						className: `shrink-0 rounded-lg px-3 py-2 font-display text-lg tracking-wide ${desk === d.id ? "bg-orange text-ink" : "text-muted"}`,
						children: d.label
					}, d.id))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-3xl px-4 py-4",
				children: [
					openNew && campaign ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewCampaign, { onDone: () => setOpenNew(false) }) : null,
					desk === "clubhouse" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clubhouse, {}) : null,
					desk === "season" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonDesk, {}) : null,
					desk === "log" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogDesk, {}) : null,
					desk === "lineups" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineupDesk, {}) : null,
					desk === "arms" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArmsDesk, {}) : null,
					desk === "roster" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RosterDesk, {}) : null,
					desk === "pipeline" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelineDesk, {}) : null,
					desk === "trades" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeDesk, {}) : null,
					desk === "scout" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoutDesk, {}) : null,
					desk === "battery" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatteryDesk, {}) : null,
					desk === "ledger" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerDesk, {}) : null,
					desk === "breakdown" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreakdownDesk, {}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 border-t border-line pt-4 text-center font-display text-xs uppercase tracking-widest text-faint",
						children: "ACE8 Franchise Companion · Single-player · Saved on this device"
					})
				]
			})]
		})]
	});
}
function NavBtn({ id, label, active, onClick }) {
	const Icon = ICONS[id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: `flex min-h-11 items-center gap-2 rounded-lg px-3 text-left font-display text-lg tracking-wide ${active ? "bg-orange-dim text-orange" : "text-muted"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4 shrink-0",
			"aria-hidden": true
		}), label]
	});
}
function NewCampaign({ onDone }) {
	const add = useFranchise((s) => s.addCampaign);
	const del = useFranchise((s) => s.deleteCampaign);
	const campaigns = useFranchise((s) => s.campaigns);
	const activeId = useFranchise((s) => s.activeId);
	const [name, setName] = (0, import_react.useState)("");
	const [team, setTeam] = (0, import_react.useState)("BAL");
	const [season, setSeason] = (0, import_react.useState)(2026);
	const [strategy, setStrategy] = (0, import_react.useState)("contend");
	const [difficulty, setDifficulty] = (0, import_react.useState)("Veteran");
	const [participation, setParticipation] = (0, import_react.useState)("Key moments");
	const [snap, setSnap] = (0, import_react.useState)(true);
	const [msg, setMsg] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		kicker: "Campaigns",
		title: "Start another save",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: name,
							placeholder: "Birdland '27",
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Club",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: team,
							onChange: (e) => setTeam(e.target.value),
							children: CLUBS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.abbr,
								children: c.name
							}, c.abbr))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Season",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "number",
							value: season,
							onChange: (e) => setSeason(Number(e.target.value) || 2026)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Plan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: strategy,
							onChange: (e) => setStrategy(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "contend",
									children: "Contend"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "retool",
									children: "Retool"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "rebuild",
									children: "Rebuild"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Difficulty",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: difficulty,
							onChange: (e) => setDifficulty(e.target.value),
							children: [
								"Beginner",
								"Veteran",
								"All-Star",
								"Hall of Fame",
								"Legend"
							].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "How you play",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: participation,
							onChange: (e) => setParticipation(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Play every game" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Key moments" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Sim the grind" })
							]
						})
					})
				]
			}),
			team === "BAL" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 flex min-h-11 items-center gap-2 text-sm text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: snap,
					onChange: (e) => setSnap(e.target.checked)
				}), "Load the Orioles 2026 snapshot"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Other clubs start as a blank 26-man. Rename every spot to match your save."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => {
						add(createCampaign({
							name,
							team,
							season,
							strategy,
							difficulty,
							participation,
							oriolesSnapshot: snap
						}));
						onDone();
					},
					children: "Create campaign"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					tone: "quiet",
					disabled: campaigns.length < 2,
					onClick: () => {
						del(activeId);
						onDone();
					},
					children: "Delete current"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "ghost",
						onClick: () => {
							const c = campaigns.find((x) => x.id === activeId);
							if (!c) return;
							const blob = new Blob([JSON.stringify({
								kind: "ace8-campaign",
								campaign: c
							}, null, 2)], { type: "application/json" });
							const url = URL.createObjectURL(blob);
							const a = document.createElement("a");
							a.href = url;
							a.download = `${c.name.replace(/\s+/g, "-").toLowerCase()}.json`;
							a.click();
							URL.revokeObjectURL(url);
						},
						children: "Export save"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex min-h-11 cursor-pointer items-center rounded-lg border border-line px-4 font-display text-lg tracking-wide text-fg",
						children: ["Import", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "application/json",
							className: "sr-only",
							onChange: async (e) => {
								const file = e.target.files?.[0];
								e.target.value = "";
								if (!file) return;
								try {
									const json = JSON.parse(await file.text());
									const raw = json.campaign ?? json;
									if (!isCampaign(raw)) {
										setMsg("That file isn’t an ACE8 campaign.");
										return;
									}
									add(normalizeCampaign(raw));
									setMsg("Imported.");
									onDone();
								} catch {
									setMsg("Couldn’t read that file.");
								}
							}
						})]
					}),
					msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: msg
					}) : null
				]
			})
		]
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const finish = () => setReady(true);
		const unsub = useFranchise.persist.onFinishHydration(finish);
		if (useFranchise.persist.hasHydrated()) finish();
		else useFranchise.persist.rehydrate();
		return () => {
			unsub();
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
//#endregion
export { Home as component };
