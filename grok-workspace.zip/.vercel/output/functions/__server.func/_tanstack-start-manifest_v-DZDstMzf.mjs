//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DZDstMzf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CmYwO_Au.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CmYwO_Au.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-TEwxF4Td.js"]
	}
} });
//#endregion
export { tsrStartManifest };
